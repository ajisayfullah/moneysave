<?php
// Koneksi ke database
$host = "localhost";
$user = "root";
$pass = "";
$db = "moneysave";

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Ambil data dari form
$email = $_POST['email'];
$password = $_POST['password'];

// Cek apakah email terdaftar
$stmt = $conn->prepare("SELECT password, nik FROM pendaftaran_rekening WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows == 1) {
    $stmt->bind_result($hashedPassword, $nik);
    $stmt->fetch();

    if ($password === $hashedPassword) {
        header("Location: ../MONEY_SAVE/beranda.php?nik=" . urlencode($nik));
        exit();
    } else {
        echo "<script>alert('Password salah!'); window.history.back();</script>";
    }
} else {
    echo "<script>alert('Email tidak ditemukan!'); window.history.back();</script>";
}

$stmt->close();
$conn->close();
