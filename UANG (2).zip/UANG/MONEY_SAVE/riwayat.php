<!DOCTYPE html>
<html>
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta charset="utf-8" />
    <link rel="stylesheet" href="view/css/bootstrap.min.css" />
    <link rel="stylesheet" href="view/style/style_riwayat.css" />
    <script src="view/js/bootstrap.min.js"></script>
  </head>
  <body>
    <div class="phone-frame">
      <div class="phone-screen">
        <div class="landing-menu">
          <div class="div">
            <div class="riwayat">
              <div class="div">
                <div class="overlap-group">
                  <div class="rectangle"></div>
                  <div class="text-wrapper">TopUp E-Wallet LinkAja</div>
                  <p class="p">02 : 93 AM | 0821-2121-****</p>
                  <div class="text-wrapper-2">Rp50.000</div>
                  <img class="logo-linkaja" src="img/logo-linkaja-8.png" />
                  <div class="rectangle-2"></div>
                  <a
                    href="#"
                    onclick="redirectTo('beranda.php'); return false;"
                  >
                    <img class="home" src="img/home_polos.png" />
                  </a>
                  <a
                    href="#"
                    onclick="redirectTo('profile_awal.php'); return false;"
                  >
                    <img class="img" src="img/profile.png" />
                  </a>
                  <div class="text-wrapper-3">Beranda</div>
                  <a
                    href="#"
                    onclick="redirectTo('riwayat.php'); return false;"
                  >
                    <img class="home-2" src="img/riwayat_putih.png" />
                  </a>
                  <div class="text-wrapper-4">Riwayat</div>
                  <div class="text-wrapper-5">Profile</div>
                  <div class="text-wrapper-6">Notifikasi</div>
                  <div class="ellipse"></div>
                  <a
                    href="#"
                    onclick="redirectTo('notifikasi.php'); return false;"
                  >
                    <img class="icon" src="img/notifikasi.png" />
                  </a>
                  <a
                    href="#"
                    onclick="redirectTo('scan_qr.php'); return false;"
                  >
                    <img class="icon-money-bills" src="img/money.png" />
                  </a>
                </div>
                <div class="ellipse-2"></div>
                <div class="overlap">
                  <!-- <div class="text-wrapper-7">🔎</div>
                  <div class="text-wrapper-8">Cari Transaksi disini yaa!</div> -->
                </div>
                <img class="logo-nama-removebg" src="img/money_save.png" />
                <img class="image" src="img/image-1.png" />
                <div class="frame">
                  <div class="frame-2">
                    <div class="group">
                      <div class="typcn-arrow-down-wrapper">
                        <img
                          class="typcn-arrow-down"
                          src="img/typcn-arrow-down.png"
                        />
                      </div>
                      <div class="frame-3">
                        <div class="text-wrapper-9">Tabungan masuk</div>
                        <div class="text-wrapper-10">12/02/2023 16:01:32</div>
                      </div>
                    </div>
                    <div class="text-wrapper-11">+Rp10.000</div>
                  </div>
                  <div class="frame-2">
                    <div class="group">
                      <div class="img-wrapper">
                        <img
                          class="typcn-arrow-down"
                          src="img/typcn-arrow-down.png"
                        />
                      </div>
                      <div class="frame-3">
                        <div class="text-wrapper-9">Tabungan Masuk</div>
                        <div class="text-wrapper-10">12/02/2023 16:01:32</div>
                      </div>
                    </div>
                    <div class="text-wrapper-11">+Rp200.000</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <script>
      const urlParams = new URLSearchParams(window.location.search);
      const nik = urlParams.get("nik");

      function redirectTo(targetPage) {
        if (nik) {
          window.location.href = targetPage + "?nik=" + encodeURIComponent(nik);
        } else {
          alert("NIK tidak ditemukan!");
          console.error("NIK parameter is missing");
          window.location.href = "beranda.php";
        }
      }
    </script>
  </body>
</html>
