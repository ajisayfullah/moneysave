<!DOCTYPE html>
<html>
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta charset="utf-8" />
    <link rel="stylesheet" href="view/css/bootstrap.min.css" />
    <link rel="stylesheet" href="view/style/style_settings.css">
    <script src="view/js/bootstrap.min.js"></script>
    <link
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css"
      rel="stylesheet"
    />
  </head>
  <body>
    <div class="phone-frame">
      <div class="phone-screen">
        <div class="landing-menu">
          <div class="div">
            <div class="settings">
              <div class="div">
                <div class="overlap-group">
                  <img class="logo-nama-removebg" src="img/money_save.png" />
                  <a
                    href="#"
                    onclick="redirectTo('profile_awal.php'); return false;"
                  >
                    <img class="arrow" src="img/kembali_putih.png" alt="Back" />
                  </a>
                </div>
                <div class="element-settings">
                  <button class="settings-button">
                    <i class="fas fa-bell" data-lang-key="notif"></i>
                    <span>Kelola Notifikasi</span>
                  </button>
                  <button class="settings-button" onclick="redirectTo('ubah_bahasa.php')">
                    <i class="fas fa-language"></i>
                    <span>Bahasa Aplikasi</span>
                  </button>
                  <button class="settings-button">
                    <i class="fas fa-trash-alt"></i>
                    <span>Hapus Akun</span>
                  </button>
                  <button class="settings-button">
                    <i class="fas fa-info-circle"></i>
                    <span>Tentang Aplikasi</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <script>
      // Ambil NIK dari URL saat ini
      const urlParams = new URLSearchParams(window.location.search);
      const nik = urlParams.get("nik");

      /**
       * Fungsi umum untuk redirect dengan parameter NIK
       * @param {string} targetPage - Halaman tujuan, contoh: 'profile_awal.html'
       */
      function redirectTo(targetPage) {
        if (nik) {
          // Redirect ke halaman tujuan dengan menyertakan NIK
          window.location.href = targetPage + "?nik=" + encodeURIComponent(nik);
        } else {
          // Alert jika NIK tidak ditemukan
          alert("NIK tidak ditemukan di URL!");
          console.error("NIK tidak tersedia.");

          // Arahkan ke beranda.php sebagai fallback
          window.location.href = "beranda.php";
        }
      }
    </script>
  </body>
</html>
