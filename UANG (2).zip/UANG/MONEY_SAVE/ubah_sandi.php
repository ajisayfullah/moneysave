<!DOCTYPE html>
<html lang="en">
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta charset="utf-8" />
    <title>Ubah Kata Sandi</title>
    <link rel="stylesheet" href="view/css/bootstrap.min.css" />
    <link rel="stylesheet" href="view/style/style_ubah_sandi.css" />
    <link
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css"
      rel="stylesheet"
    />
  </head>
  <body>
    <div class="phone-frame">
      <div class="ubah-kata-sandi">
        <div class="div">
          <div class="overlap-group">
            <img
              class="logo-nama-removebg"
              src="img/money_save.png"
              alt="Logo"
            />
            <a
              href="#"
              onclick="redirectTo('keamanan_akun.php'); return false;"
            >
              <img class="arrow" src="img/kembali_putih.png" alt="Back" />
            </a>
          </div>
          <form
            class="form-ubah-sandi"
            method="POST"
            action="ubah_sandi_proses.php?nik=<?php echo htmlspecialchars($_GET['nik'] ?? ''); ?>"
          >
            <h2>Ubah Kata Sandi</h2>
            <div class="form-group">
              <label for="old-password">Kata Sandi Lama</label>
              <input
                type="password"
                id="old-password"
                name="old-password"
                placeholder="Masukkan kata sandi lama"
                required
              />
            </div>
            <div class="form-group">
              <label for="new-password">Kata Sandi Baru</label>
              <input
                type="password"
                id="new-password"
                name="new-password"
                placeholder="Masukkan kata sandi baru"
                required
              />
            </div>
            <div class="form-group">
              <label for="confirm-password">Konfirmasi Kata Sandi Baru</label>
              <input
                type="password"
                id="confirm-password"
                name="confirm-password"
                placeholder="Konfirmasi kata sandi baru"
                required
              />
            </div>
            <button type="submit" class="btn-ubah-sandi">
              Simpan Perubahan
            </button>
            <div class="form-info">
              Pastikan kata sandi baru berbeda dengan sebelumnya.
            </div>
          </form>
        </div>
      </div>
    </div>
    <script>
      // Ambil parameter nik dari URL
      const urlParams = new URLSearchParams(window.location.search);
      const nik = urlParams.get("nik");

      // Fungsi untuk redirect ke halaman lain dengan membawa NIK
      function redirectTo(targetPage) {
        if (nik) {
          window.location.href = targetPage + "?nik=" + encodeURIComponent(nik);
        } else {
          alert("NIK tidak ditemukan di URL!");
          console.error("NIK parameter is missing in URL");
          window.location.href = "beranda.php";
        }
      }

      // Setelah halaman selesai dimuat
      window.addEventListener("DOMContentLoaded", function () {
        // Set action form ubah sandi agar mengirimkan NIK ke file PHP
        const form = document.querySelector(".form-ubah-sandi");
        if (form && nik) {
          form.action = "ubah_sandi_proses.php?nik=" + encodeURIComponent(nik);
        }
      });
    </script>
  </body>
</html>
