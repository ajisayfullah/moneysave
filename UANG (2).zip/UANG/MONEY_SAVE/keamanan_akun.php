<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Keamanan Akun</title>
    <link rel="stylesheet" href="view/css/bootstrap.min.css" />
    <link rel="stylesheet" href="view/style/style_keamanan_akun.css" />
    <link
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css"
      rel="stylesheet"
    />
  </head>
  <body>
    <div class="phone-frame">
      <div class="keamanan-akun">
        <div class="div">
          <div class="overlap-group">
            <a
              href="#"
              onclick="redirectTo('profile_awal.php'); return false;"
            >
              <img class="arrow" src="img/kembali_putih.png" alt="Back" />
            </a>
            <img
              class="logo-nama-removebg"
              src="img/money_save.png"
              alt="Logo"
            />
          </div>
          <div class="container">
            <div class="option" onclick="redirectTo('ubah_sandi.php')">
              <div class="option-content">
                <i class="fas fa-key option-icon"></i>
                <span class="option-text">Ubah Kata Sandi</span>
              </div>
              <i class="fas fa-chevron-right arrow-icon"></i>
            </div>
            <div class="option" onclick="redirectTo('2fa.php')">
              <div class="option-content">
                <i class="fas fa-shield-alt option-icon"></i>
                <span class="option-text">Aktifkan 2FA</span>
              </div>
              <i class="fas fa-chevron-right arrow-icon"></i>
            </div>
            <div class="option">
              <div class="option-content">
                <i class="fas fa-envelope option-icon"></i>
                <span class="option-text">Perbarui Email</span>
              </div>
              <i class="fas fa-chevron-right arrow-icon"></i>
            </div>
            <div class="option">
              <div class="option-content">
                <i class="fas fa-sign-out-alt option-icon"></i>
                <span class="option-text">Keluar dari Semua Perangkat</span>
              </div>
              <i class="fas fa-chevron-right arrow-icon"></i>
            </div>
          </div>
        </div>
      </div>
    </div>
    <script>
      const urlParams = new URLSearchParams(window.location.search);
      const nik = urlParams.get("nik");

      function redirectTo(targetPage) {
        if (nik) {
          window.location.href = targetPage + "?nik=" + encodeURIComponent(nik);
        } else {
          alert("NIK tidak ditemukan di URL!");
          console.error("NIK parameter is missing in URL");
          window.location.href = "beranda.php";
        }
      }
    </script>
  </body>
</html>
