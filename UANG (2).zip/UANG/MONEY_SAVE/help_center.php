<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Help Center</title>
    <link rel="stylesheet" href="view/css/bootstrap.min.css" />
    <link rel="stylesheet" href="view/style/style_help_center.css" />
    <link
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css"
      rel="stylesheet"
    />
  </head>
  <body>
    <div class="phone-frame">
      <div class="help-center">
        <div class="div">
          <div class="overlap-group">
            <a
              href="#"
              onclick="redirectTo('profile_awal.php'); return false;"
            >
              <img class="arrow" src="img/kembali_putih.png" alt="Back" />
            </a>
            <img
              class="logo-nama-removebg"
              src="img/money_save.png"
              alt="Logo"
            />
          </div>
          <div class="container">
            <div class="content">
              <h2>Frequently Asked Questions (FAQ)</h2>
              <div class="faq-item">
                <h3>1. Bagaimana cara membuat target tabungan?</h3>
                <p>
                  Anda dapat membuat target tabungan dengan masuk ke menu
                  "Tambah Target" dan mengisi detail seperti nama target,
                  nominal, dan tenggat waktu.
                </p>
              </div>
              <div class="faq-item">
                <h3>2. Apakah aplikasi ini aman digunakan?</h3>
                <p>
                  Ya, aplikasi ini dirancang untuk menjaga privasi dan keamanan
                  data Anda. Namun, kami menyarankan untuk tidak memasukkan
                  informasi sensitif.
                </p>
              </div>
              <div class="faq-item">
                <h3>3. Apakah aplikasi ini mendukung transaksi keuangan?</h3>
                <p>
                  Tidak, aplikasi ini hanya digunakan untuk pencatatan dan
                  perencanaan target tabungan. Tidak ada fitur transaksi
                  keuangan nyata.
                </p>
              </div>
              <div class="faq-item">
                <h3>4. Bagaimana cara mengubah kata sandi?</h3>
                <p>
                  Anda dapat mengubah kata sandi melalui menu "Keamanan Akun" di
                  pengaturan.
                </p>
              </div>
              <div class="faq-item">
                <h3>5. Bagaimana cara menghubungi tim dukungan?</h3>
                <p>
                  Anda dapat menghubungi kami melalui email di
                  support@money_save.com.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <script>
      // Ambil NIK dari URL saat ini
      const urlParams = new URLSearchParams(window.location.search);
      const nik = urlParams.get("nik");

      /**
       * Fungsi umum untuk redirect ke halaman tujuan dengan parameter NIK
       * @param {string} targetPage - Halaman tujuan (misalnya 'profile_awal.html')
       */
      function redirectTo(targetPage) {
        if (nik) {
          window.location.href = targetPage + "?nik=" + encodeURIComponent(nik);
        } else {
          alert("NIK tidak ditemukan di URL!");
          console.error("NIK parameter is missing in URL");
          window.location.href = "beranda.php";
        }
      }
    </script>
  </body>
</html>
