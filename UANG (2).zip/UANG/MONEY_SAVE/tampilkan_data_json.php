<?php
header("Content-Type: application/json");
require_once __DIR__ . '/config/koneksi.php';

$nik = $_GET['nik'] ?? '';
if (!$nik) {
    echo json_encode(['success' => false, 'message' => 'NIK tidak ditemukan']);
    exit;
}

$stmt = $koneksi->prepare("
  SELECT t.id AS target_id, t.tujuan, t.deadline, r.nama, r.amount
  FROM target t
  LEFT JOIN rincian_pengeluaran r ON t.id = r.target_id
  WHERE t.nik = ?
  ORDER BY t.id DESC
");

$stmt->bind_param("s", $nik);
$stmt->execute();
$result = $stmt->get_result();

$data = [];
$targets = [];

while ($row = $result->fetch_assoc()) {
    $tid = $row['target_id'];
    if (!isset($targets[$tid])) {
        $targets[$tid] = [
            'tujuan' => $row['tujuan'],
            'deadline' => $row['deadline'],
            'rincian' => []
        ];
    }
    if ($row['nama']) {
        $targets[$tid]['rincian'][] = ['nama' => $row['nama'], 'amount' => $row['amount']];
    }
}

$data = array_values($targets);

echo json_encode([
    'success' => true,
    'data' => $data
]);
