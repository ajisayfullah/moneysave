<!DOCTYPE html>
<html>
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta charset="utf-8" />
    <link rel="stylesheet" href="view/css/bootstrap.min.css" />
    <link rel="stylesheet" href="view/style/style_syarat_ketentuan.css">
    <script src="view/js/bootstrap.min.js"></script>
  </head>
  <body>
    <div class="phone-frame">
      <div class="phone-screen">
        <div class="landing-menu">
          <div class="div">
            <div class="syarat-ketentuan">
              <div class="div">
                <div class="overlap-group">
                  <img class="logo-nama-removebg" src="img/money_save.png" />
                  <a
                    href="#"
                    onclick="redirectTo('profile_awal.php'); return false;"
                  >
                    <img class="arrow" src="img/kembali_putih.png" alt="Back" />
                  </a>
                </div>
                <p class="element-tujuan-aplikasi">
                  <span class="text-wrapper">1. Tujuan Aplikasi<br /></span>
                  <span class="span"
                    >Aplikasi ini bertujuan sebagai alat bantu pencatatan dan
                    perencanaan target tabungan secara mandiri, khususnya bagi
                    pelajar.<br /><br
                  /></span>
                  <span class="text-wrapper"
                    >2. Tanpa Fitur Transaksi Keuangan Nyata<br
                  /></span>
                  <span class="span"
                    >Aplikasi tidak menyediakan fitur transfer uang, penarikan
                    dana, atau transaksi keuangan digital dalam bentuk apa pun.
                    Semua nominal bersifat simulasi atau catatan pribadi.<br /><br
                  /></span>
                  <span class="text-wrapper">3. Data yang Dicatat<br /></span>
                  <span class="span"
                    >Semua data target tabungan dan rincian pengeluaran yang
                    dimasukkan pengguna digunakan untuk kebutuhan pribadi dan
                    tidak dibagikan kepada pihak lain.<br /><br
                  /></span>
                  <span class="text-wrapper"
                    >4. Tanggung Jawab Pengguna<br
                  /></span>
                  <span class="span"
                    >Pengguna bertanggung jawab atas isi data yang dimasukkan,
                    termasuk target, nominal, dan tenggat waktu yang ditentukan
                    sendiri.<br /><br
                  /></span>
                  <span class="text-wrapper"
                    >5. Perubahan dan Pembaruan<br
                  /></span>
                  <span class="span"
                    >Kami dapat melakukan pembaruan fitur, tampilan, atau syarat
                    ketentuan sewaktu-waktu untuk meningkatkan kualitas
                    aplikasi.<br /><br
                  /></span>
                  <span class="text-wrapper-2"
                    >6. Privasi dan Keamanan<br
                  /></span>
                  <span class="span"
                    >Data pengguna disimpan dengan prinsip keamanan dan
                    kerahasiaan. Namun, kami menyarankan pengguna tidak
                    memasukkan informasi sensitif atau pribadi lainnya.</span
                  >
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <script>
      // Ambil NIK dari URL saat ini
      const urlParams = new URLSearchParams(window.location.search);
      const nik = urlParams.get("nik");

      /**
       * Fungsi umum untuk redirect ke halaman tujuan dengan parameter NIK
       * @param {string} targetPage - Halaman tujuan (misalnya 'profile_awal.html')
       */
      function redirectTo(targetPage) {
        if (nik) {
          window.location.href = targetPage + "?nik=" + encodeURIComponent(nik);
        } else {
          alert("NIK tidak ditemukan di URL!");
          console.error("NIK parameter is missing in URL");
          window.location.href = "beranda.php";
        }
      }
    </script>
  </body>
</html>
