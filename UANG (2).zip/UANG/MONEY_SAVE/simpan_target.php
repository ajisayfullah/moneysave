<?php
header('Content-Type: application/json');
require_once __DIR__ . '/config/koneksi.php';

// Ambil data JSON
$data = json_decode(file_get_contents('php://input'), true);

$nik = $koneksi->real_escape_string($data['nik'] ?? '');
$tujuan = $koneksi->real_escape_string($data['tujuan'] ?? '');
$deadline = $koneksi->real_escape_string($data['deadline'] ?? '');
$rincian = $data['rincian'] ?? [];

if (empty($nik) || empty($tujuan) || empty($deadline)) {
  echo json_encode(['success' => false, 'message' => 'Data tidak lengkap']);
  exit;
}

try {
  // Simpan ke tabel target
  $stmt = $koneksi->prepare("INSERT INTO target (nik, tujuan, deadline) VALUES (?, ?, ?)");
  $stmt->bind_param("sss", $nik, $tujuan, $deadline);
  if (!$stmt->execute()) throw new Exception("Gagal menyimpan target: " . $stmt->error);

  $target_id = $stmt->insert_id;
  $stmt->close();

  // Simpan rincian_pengeluaran beserta nik
  $stmt_rincian = $koneksi->prepare("INSERT INTO rincian_pengeluaran (target_id, nik, nama, amount) VALUES (?, ?, ?, ?)");
  foreach ($rincian as $item) {
    $nama = $koneksi->real_escape_string($item['nama'] ?? '');
    $amount = floatval($item['amount'] ?? 0);
    if (!empty($nama) && $amount > 0) {
      $stmt_rincian->bind_param("isss", $target_id, $nik, $nama, $amount);
      if (!$stmt_rincian->execute()) {
        throw new Exception("Gagal menyimpan rincian '$nama': " . $stmt_rincian->error);
      }
    }
  }

  $stmt_rincian->close();
  echo json_encode([
    'success' => true,
    'message' => 'Target dan rincian berhasil disimpan',
    'target_id' => $target_id
  ]);
} catch (Exception $e) {
  echo json_encode([
    'success' => false,
    'message' => $e->getMessage()
  ]);
}

$koneksi->close();
