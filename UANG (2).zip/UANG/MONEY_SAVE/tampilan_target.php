<?php
require_once __DIR__ . '/config/koneksi.php';

// Ambil NIK dari URL
$nik = $_GET['nik'] ?? '';

if (empty($nik)) {
    echo "<p>NIK tidak ditemukan di URL</p>";
    exit;
}

// Query untuk mengambil tujuan, nama, dan amount berdasarkan NIK
$query = "
    SELECT t.tujuan, r.nama, r.amount 
    FROM target t
    LEFT JOIN rincian_pengeluaran r ON t.id = r.target_id
    WHERE t.nik = ?
    ORDER BY t.id DESC
";

$stmt = $koneksi->prepare($query);
$stmt->bind_param("s", $nik);
$stmt->execute();
$result = $stmt->get_result();

$data = [];

while ($row = $result->fetch_assoc()) {
    $data[] = [
        'tujuan' => $row['tujuan'],
        'nama' => $row['nama'],
        'amount' => $row['amount']
    ];
}

$stmt->close();
$koneksi->close();

if (!empty($data)) {
    // Tampilkan dalam bentuk HTML
    echo "<h3>Target & Rincian Pengeluaran</h3>";
    echo "<ul>";

    $currentTujuan = "";
    foreach ($data as $item) {
        if ($currentTujuan !== $item['tujuan']) {
            if ($currentTujuan !== "") echo "</ul><br/>";
            echo "<li><strong>{$item['tujuan']}</strong></li>";
            echo "<ul>";
            $currentTujuan = $item['tujuan'];
        }

        if ($item['nama']) {
            echo "<li>{$item['nama']} - Rp " . number_format($item['amount'], 0, ',', '.') . "</li>";
        }
    }

    echo "</ul>";
} else {
    echo "<p>Tidak ada data untuk NIK ini.</p>";
}
