<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Aktifkan 2FA</title>
    <link rel="stylesheet" href="view/css/bootstrap.min.css" />
    <link rel="stylesheet" href="view/style/style_2fa.css" />
    <link
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css"
      rel="stylesheet"
    />
  </head>
  <body>
    <div class="phone-frame">
      <div class="aktifkan-2fa">
        <div class="div">
          <div class="overlap-group">
            <img class="logo-nama-removebg" src="img/money_save.png" alt="Logo" />
            <a href="#" onclick="redirectTo('keamanan_akun.php'); return false;">
            <img class="arrow" src="img/kembali_putih.png" alt="Back" />
          </a>
            <img
              class="logo-nama-removebg"
              src="img/money_save.png"
              alt="Logo"
            />
          </div>
          <form class="form-2fa">
            <h2>Aktifkan 2FA</h2>
            <div class="form-group">
              <label for="email">Email untuk Verifikasi</label>
              <input
                type="email"
                id="email"
                name="email"
                placeholder="Masukkan email Anda"
                required
              />
            </div>
            <div class="form-group">
              <label for="kode">Kode Verifikasi</label>
              <input
                type="text"
                id="kode"
                name="kode"
                placeholder="Masukkan kode verifikasi"
                required
              />
            </div>
            <button type="submit" class="btn-2fa">Aktifkan 2FA</button>
            <div class="form-info">
              Kode verifikasi akan dikirim ke email Anda.
            </div>
          </form>
        </div>
      </div>
    </div>
    <script>
      const urlParams = new URLSearchParams(window.location.search);
      const nik = urlParams.get("nik");

      function redirectTo(targetPage) {
        if (nik) {
          window.location.href = targetPage + "?nik=" + encodeURIComponent(nik);
        } else {
          alert("NIK tidak ditemukan di URL!");
          console.error("NIK parameter is missing in URL");
          window.location.href = "beranda.php";
        }
      }
    </script>
  </body>
</html>
