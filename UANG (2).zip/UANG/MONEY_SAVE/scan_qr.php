<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Scan QR 2FA</title>
    <link rel="stylesheet" href="view/css/bootstrap.min.css" />
    <link rel="stylesheet" href="view/style/style_scan_qr.css" />
    <link
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css"
      rel="stylesheet"
    />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script>
  </head>
  <body>
    <div class="phone-frame">
      <div class="scan-qr">
        <div class="div">
          <div class="overlap-group">
            <a href="#" onclick="redirectTo('beranda.php'); return false;">
              <img class="arrow" src="img/kembali_putih.png" alt="Back" />
            </a>
            <img
              class="logo-nama-removebg"
              src="img/money_save.png"
              alt="Logo"
            />
          </div>
          <div class="qr-content">
            <h2>Scan QR 2FA</h2>
            <div class="qr-image">
              <div id="qrcode"></div>
            </div>
            <div class="qr-info">
              Scan QR ini menggunakan aplikasi autentikator (Google
              Authenticator, Authy, dll) untuk mengaktifkan 2FA pada akun Anda.
            </div>
            <button class="btn-selesai" onclick="redirectTo('beranda.php')">Selesai</button>
          </div>
        </div>
      </div>
    </div>
    <script>
      // Membuat string random
      function randomString(length) {
        const chars =
          "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
        let result = "";
        for (let i = 0; i < length; i++) {
          result += chars.charAt(Math.floor(Math.random() * chars.length));
        }
        return result;
      }
      // Generate QR random
      new QRCode(document.getElementById("qrcode"), {
        text: randomString(16),
        width: 150,
        height: 150,
      });

      const urlParams = new URLSearchParams(window.location.search);
      const nik = urlParams.get("nik");

      function redirectTo(targetPage) {
        if (nik) {
          window.location.href = targetPage + "?nik=" + encodeURIComponent(nik);
        } else {
          alert("NIK tidak ditemukan!");
          console.error("NIK parameter is missing");
          window.location.href = "beranda.php";
        }
      }
    </script>
  </body>
</html>
