<!DOCTYPE html>
<html lang="en">
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta charset="utf-8" />
    <title>Ubah Bahasa</title>
    <link rel="stylesheet" href="view/css/bootstrap.min.css" />
    <link rel="stylesheet" href="view/style/style_ubah_bahasa.css" />
    <link
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css"
      rel="stylesheet"
    />
    <script src="view/js/lang.js"></script>
  </head>
  <body>
    <div class="phone-frame">
      <div class="ubah-bahasa">
        <div class="div">
          <div class="overlap-group">
            <img
              class="logo-nama-removebg"
              src="img/money_save.png"
              alt="Logo"
            />
            <a href="#" onclick="redirectTo('settings.php'); return false;">
              <img class="arrow" src="img/kembali_putih.png" alt="Back" />
            </a>
          </div>
          <form class="form-ubah-bahasa">
            <h2><span id="ubah_bahasa">Ubah Bahasa</span></h2>
            <div class="form-group">
              <label for="language" data-i18n="pilih_bahasa"
                >Pilih Bahasa</label
              >

              <select id="language" name="language" required>
                <option value="" disabled selected>Pilih bahasa</option>
                <option value="id">Indonesia</option>
                <option value="en">English</option>
                <option value="zh">China</option>
                <option value="ja">Jepang</option>
                <option value="ar">Arab</option>
                <option value="ko">Korea</option>
                <option value="th">Thailand</option>
              </select>
            </div>
            <button
              type="submit"
              class="btn-ubah-bahasa"
              data-i18n="simpan_perubahan"
              id="simpan"
            >
              Simpan Perubahan
            </button>
            <div class="form-info" data-i18n="info_bahasa">
              Bahasa aplikasi akan berubah sesuai pilihan Anda.
            </div>
          </form>
        </div>
      </div>
    </div>
    <script>
      const urlParams = new URLSearchParams(window.location.search);
      const nik = urlParams.get("nik");

      function redirectTo(targetPage) {
        if (nik) {
          window.location.href = targetPage + "?nik=" + encodeURIComponent(nik);
        } else {
          alert("NIK tidak ditemukan di URL!");
          console.error("NIK parameter is missing in URL");
          window.location.href = "beranda.php";
        }
      }

      const defaultLang = localStorage.getItem("lang") || "id";

      function loadLanguage(lang) {
        fetch(`lang/${lang}.json`)
          .then((res) => res.json())
          .then((translations) => {
            document.querySelectorAll("[data-i18n]").forEach((el) => {
              const key = el.getAttribute("data-i18n");
              if (translations[key]) {
                el.textContent = translations[key];
              }
            });
          });
      }

      // Set awal saat halaman dimuat
      loadLanguage(defaultLang);
      document.getElementById("language").value = defaultLang;

      // Simpan dan ubah bahasa
      document
        .querySelector(".form-ubah-bahasa")
        .addEventListener("submit", (e) => {
          e.preventDefault();
          const selectedLang = document.getElementById("language").value;
          localStorage.setItem("lang", selectedLang);
          loadLanguage(selectedLang);
        });
    </script>
  </body>
</html>
