<?php
require_once __DIR__ . '/config/koneksi.php';

// Ambil NIK dari URL
if (!isset($_GET['nik'])) {
    die("NIK tidak ditemukan.");
}
$nik = $_GET['nik'];

// Ambil data target
$sql = "
    SELECT t.id AS target_id, t.nominal, t.deadline, r.nama, r.amount
    FROM target t
    LEFT JOIN rincian_pengeluaran r ON t.id = r.target_id
    WHERE t.nik = ?
    ORDER BY t.id DESC
    LIMIT 1
";

$stmt = $koneksi->prepare($sql);
$stmt->bind_param("s", $nik);
$stmt->execute();
$result = $stmt->get_result();

$data = [];

while ($row = $result->fetch_assoc()) {
    if (!isset($data['target'])) {
        $data['target'] = [
            'id' => $row['target_id'],
            'nominal' => $row['nominal'],
            'deadline' => $row['deadline'],
            'rincian' => []
        ];
    }
    if ($row['nama']) {
        $data['target']['rincian'][] = [
            'nama' => $row['nama'],
            'amount' => $row['amount']
        ];
    }
}

$koneksi->close();
