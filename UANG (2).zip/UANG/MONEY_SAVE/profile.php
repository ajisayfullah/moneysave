<?php
// 1. Koneksi ke database
require_once __DIR__ . '/config/koneksi.php';

// 2. Ambil NIK dari URL
if (!isset($_GET['nik'])) {
  die("NIK tidak ditemukan.");
}
$nik = $_GET['nik'];

// 3. Query ke database
$sql = "SELECT * FROM daftar WHERE nik = ?";
$stmt = $koneksi->prepare($sql);
$stmt->bind_param("s", $nik);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
  die("Data tidak ditemukan untuk NIK ini.");
}

$data = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Profile</title>
  <link rel="stylesheet" href="view/css/bootstrap.min.css" />
  <link rel="stylesheet" href="view/style/style_profile.css">
  <link
    href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css"
    rel="stylesheet" />
</head>

<body>
  <div class="phone-frame">
    <div class="profile">
      <div class="div">
        <div class="overlap-group">
          <a href="#" onclick="goBackWithNIK(); return false;">
            <img class="arrow" src="img/kembali_putih.png" alt="Back" />
          </a>

          <img
            class="logo-nama-removebg"
            src="img/money_save.png"
            alt="Logo" />
        </div>
        <div class="container">
          <img
            class="profile-picture"
            src="img/profile_picture.png"
            alt="Profile Picture" />
          <div class="profile-title">My Profile</div>
          <div class="info-item">
            <i class="fas fa-user"></i>
            <div class="info-content">
              <span>Users</span>
              <span class="info-value"><?= htmlspecialchars($data['nama']) ?></span>
            </div>
          </div>
          <div class="info-item">
            <i class="fas fa-envelope"></i>
            <div class="info-content">
              <span>Email</span>
              <span class="info-value"><?= htmlspecialchars($data['email']) ?></span>
            </div>
          </div>
          <div class="info-item">
            <i class="fas fa-phone"></i>
            <div class="info-content">
              <span>Phone Number</span>
              <span class="info-value"><?= htmlspecialchars($data['no_hp']) ?></span>
            </div>
          </div>
          <div class="info-item">
            <i class="fas fa-calendar-alt"></i>
            <div class="info-content">
              <span>Tanggal Lahir</span>
              <span class="info-value"><?= htmlspecialchars($data['tgl_lahir']) ?></span>
            </div>
          </div>
          <div class="info-item">
            <i class="fas fa-venus-mars"></i>
            <div class="info-content">
              <span>Jenis Kelamin</span>
              <span class="info-value"><?= htmlspecialchars($data['jenis_kelamin']) ?></span>
            </div>
          </div>
          <div class="info-item">
            <i class="fas fa-map-marker-alt"></i>
            <div class="info-content">
              <span>Alamat</span>
              <span class="info-value"><?= htmlspecialchars($data['alamat']) ?></span>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <script>
    // Ambil NIK dari URL saat ini
    const urlParams = new URLSearchParams(window.location.search);
    const nik = urlParams.get("nik");

    // Fungsi untuk tombol kembali
    function goBackWithNIK() {
      if (nik) {
        // Arahkan ke profile_awal.html dengan NIK
        window.location.href = "profile_awal.html?nik=" + encodeURIComponent(nik);
      } else {
        alert("NIK tidak ditemukan di URL!");
        console.error("NIK tidak tersedia, tidak bisa kembali dengan parameter.");
        // Opsional: arahkan ke halaman default seperti beranda.php
        window.location.href = "beranda.php";
      }
    }

    const uploadInput = document.getElementById("uploadFotoInput");
    const profilePreview = document.getElementById("profilePreview");

    uploadInput.addEventListener("change", function() {
      if (this.files && this.files[0]) {
        const reader = new FileReader();
        reader.onload = function(e) {
          profilePreview.src = e.target.result;
        };
        reader.readAsDataURL(this.files[0]);
      }
    });
  </script>
</body>

</html>