<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Pembaruan Email</title>
    <link rel="stylesheet" href="view/css/bootstrap.min.css" />
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet" />
    <style>
      @import url("https://cdnjs.cloudflare.com/ajax/libs/meyer-reset/2.0/reset.min.css");
      * {
        -webkit-font-smoothing: antialiased;
        box-sizing: border-box;
      }
      html, body {
        margin: 0px;
        height: 100%;
        background-color: #f0f0f0;
      }
      .phone-frame {
        background-color: #dcdcdc;
        padding: 30px 12px;
        border-radius: 40px;
        box-shadow: 0 0 0 10px #888;
        display: flex;
        justify-content: center;
        align-items: center;
        min-height: 100vh;
      }
      .pembaruan-email {
        background-color: #dcdcdc;
        display: flex;
        flex-direction: row;
        justify-content: center;
        width: 100%;
      }
      .pembaruan-email .div {
        background-color: #ffffff;
        width: 360px;
        height: 800px;
        position: relative;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
      }
      .pembaruan-email .overlap-group {
        position: absolute;
        width: 360px;
        height: 89px;
        top: 0;
        left: 0;
        background-color: #e16417;
      }
      .pembaruan-email .logo-nama-removebg {
        position: absolute;
        width: 100px;
        height: 67px;
        top: 12px;
        left: 238px;
        object-fit: cover;
      }
      .pembaruan-email .arrow {
        position: absolute;
        width: 32px;
        height: 22px;
        top: 34px;
        left: 26px;
        cursor: pointer;
      }
      .form-email {
        position: absolute;
        width: 302px;
        top: 119px;
        left: 31px;
        display: flex;
        flex-direction: column;
        gap: 18px;
        font-family: "Poppins-Regular", Helvetica, Arial, sans-serif;
      }
      .form-email h2 {
        font-size: 18px;
        color: #e16417;
        text-align: center;
        margin-bottom: 10px;
        font-weight: bold;
      }
      .form-group {
        display: flex;
        flex-direction: column;
        gap: 6px;
      }
      .form-group label {
        font-size: 14px;
        color: #333;
        font-weight: 500;
      }
      .form-group input {
        padding: 8px 12px;
        border: 1px solid #ddd;
        border-radius: 6px;
        font-size: 14px;
        outline: none;
        transition: border-color 0.2s;
      }
      .form-group input:focus {
        border-color: #e16417;
      }
      .btn-email {
        background-color: #e16417;
        color: #fff;
        border: none;
        border-radius: 6px;
        padding: 10px 0;
        font-size: 15px;
        font-weight: 600;
        cursor: pointer;
        margin-top: 10px;
        transition: background 0.2s;
      }
      .btn-email:hover {
        background-color: #c95010;
      }
      .form-info {
        font-size: 13px;
        color: #888;
        text-align: center;
        margin-top: 5px;
      }
    </style>
  </head>
  <body>
    <div class="phone-frame">
      <div class="pembaruan-email">
        <div class="div">
          <div class="overlap-group">
            <img class="arrow" src="img/kembali_putih.png" alt="Back" />
            <img class="logo-nama-removebg" src="img/money_save.png" alt="Logo" />
          </div>
          <form class="form-email">
            <h2>Pembaruan Email</h2>
            <div class="form-group">
              <label for="email-lama">Email Lama</label>
              <input type="email" id="email-lama" name="email-lama" placeholder="Masukkan email lama" required />
            </div>
            <div class="form-group">
              <label for="email-baru">Email Baru</label>
              <input type="email" id="email-baru" name="email-baru" placeholder="Masukkan email baru" required />
            </div>
            <div class="form-group">
              <label for="kode-verifikasi">Kode Verifikasi</label>
              <input type="text" id="kode-verifikasi" name="kode-verifikasi" placeholder="Masukkan kode verifikasi" required />
            </div>
            <button type="submit" class="btn-email">Simpan Perubahan</button>
            <div class="form-info">Kode verifikasi akan dikirim ke email baru Anda.</div>
          </form>
        </div>
      </div>
    </div>
  </body>
</html>