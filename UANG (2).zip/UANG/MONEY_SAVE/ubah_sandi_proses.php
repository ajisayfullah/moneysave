<?php
require_once __DIR__ . '/config/koneksi.php';

$nik = $_GET['nik'] ?? '';
$old_password = $_POST['old-password'];
$new_password = $_POST['new-password'];
$confirm_password = $_POST['confirm-password'];

// Validasi input
if (!$nik || !$old_password || !$new_password || !$confirm_password) {
    echo "<script>alert('Semua kolom harus diisi.'); window.history.back();</script>";
    exit;
}

if ($new_password !== $confirm_password) {
    echo "<script>alert('Konfirmasi kata sandi tidak cocok.'); window.history.back();</script>";
    exit;
}

// Ambil password lama dari database
$sql = "SELECT password FROM daftar WHERE nik = ?";
$stmt = $koneksi->prepare($sql);
$stmt->bind_param("s", $nik);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo "<script>alert('NIK tidak ditemukan.'); window.history.back();</script>";
    exit;
}

$row = $result->fetch_assoc();
$stored_password = $row['password'];

// Karena password tidak di-hash
if ($old_password !== $stored_password) {
    echo "<script>alert('Kata sandi lama salah.'); window.history.back();</script>";
    exit;
}

// Update password baru
$update_sql = "UPDATE daftar SET password = ? WHERE nik = ?";
$update_stmt = $koneksi->prepare($update_sql);
$update_stmt->bind_param("ss", $new_password, $nik);

if ($update_stmt->execute()) {
    // Redirect ke halaman keamanan akun jika berhasil
    header("Location: keamanan_akun.php?nik=" . urlencode($nik));
    exit;
} else {
    echo "<script>alert('Gagal mengubah kata sandi. Silakan coba lagi.'); window.history.back();</script>";
    exit;
}

$koneksi->close();
