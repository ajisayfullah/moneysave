<?php
// ...bisa tambahkan PHP di sini jika perlu...
?>
<!DOCTYPE html>
<html>
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta charset="utf-8" />
    <link rel="stylesheet" href="view/css/bootstrap.min.css" />
    <link rel="stylesheet" href="view/style/style_notifikasi.css" />
    <script src="view/js/bootstrap.min.js"></script>
  </head>
  <body>
    <div class="phone-frame">
      <div class="phone-screen">
        <div class="landing-menu">
          <div class="div">
            <div class="notifikasi">
              <div class="div">
                <div class="overlap">
                  <div class="details">
                    <img class="home-indicator" src="img/home_indicator.png" />
                    <div class="overlap-group">
                      <div class="today">
                        <div class="overlap-2">
                          <div class="new-notification">
                            <div class="overlap-3">
                              <div class="rectangle"></div>
                              <div class="group">
                                <div class="overlap-group-2">
                                  <div class="rectangle-2"></div>
                                  <div class="tabler-discount">
                                    <img class="img" src="img/discount.png" />
                                  </div>
                                  <div class="ellipse"></div>
                                </div>
                              </div>
                              <div class="group-2">
                                <div class="overlap-4">
                                  <div class="group-3"></div>
                                  <div class="text-wrapper">15 Menit</div>
                                </div>
                                <div class="text-wrapper-2">Tabungan Masuk</div>
                                <div class="tabungan-masuk">
                                  Tabungan Masuk Rp20.000<br />12/02/2023
                                  16:01:32
                                </div>
                              </div>
                            </div>
                          </div>
                          <img class="images-removebg" src="img/sampah.png" />
                        </div>
                        <div class="text-wrapper-3">Hari ini</div>
                      </div>
                      <img class="vector" src="img/vector_line.png" />
                      <img class="vector-2" src="img/vector_line.png" />
                    </div>
                    <div class="last-day">
                      <div class="group-4">
                        <div class="group-5">
                          <div class="overlap-group-wrapper">
                            <div class="div-wrapper">
                              <div class="text-wrapper-4">NOV10</div>
                            </div>
                          </div>
                          <div class="group-6">
                            <div class="text-wrapper-5">OVO</div>
                            <div class="text-wrapper-6">3:40 PM</div>
                            <div class="tag">
                              <div class="text-wrapper-7">Promo</div>
                            </div>
                          </div>
                        </div>
                        <div class="group-7">
                          <div class="overlap-group-wrapper">
                            <div class="div-wrapper">
                              <div class="text-wrapper-4">NOV10</div>
                            </div>
                          </div>
                          <div class="group-6">
                            <div class="text-wrapper-5">OVO</div>
                            <div class="text-wrapper-6">3:40 PM</div>
                            <div class="tag">
                              <div class="text-wrapper-7">Promo</div>
                            </div>
                          </div>
                        </div>
                        <div class="group-8">
                          <div class="group-9">
                            <div class="group-wrapper">
                              <div class="group-10">
                                <div class="overlap-group-3">
                                  <img
                                    class="group-11"
                                    src="img/group-131.png"
                                  />
                                  <img class="vector-3" src="img/vector.svg" />
                                </div>
                              </div>
                            </div>
                            <img class="intersect" src="img/intersect.svg" />
                          </div>
                          <div class="group-6">
                            <div class="text-wrapper-8">
                              30% Black Friday Deal
                            </div>
                            <div class="text-wrapper-6">3:40 PM</div>
                            <div class="tag">
                              <div class="text-wrapper-7">Promo</div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="rectangle-3"></div>
                  <a
                    href="#"
                    onclick="redirectTo('beranda.php'); return false;"
                  >
                    <img class="home" src="img/home_polos.png" />
                  </a>
                  <a
                    href="#"
                    onclick="redirectTo('profile_awal.php'); return false;"
                  >
                    <img class="home-2" src="img/profile.png" />
                  </a>
                  <div class="text-wrapper-9">Beranda</div>
                  <a
                    href="#"
                    onclick="redirectTo('riwayat.php'); return false;"
                  >
                    <img class="home-3" src="img/riwayat.png" />
                  </a>
                  <div class="text-wrapper-10">Riwayat</div>
                  <div class="text-wrapper-11">Profile</div>
                  <div class="text-wrapper-12">Notifikasi</div>
                  <div class="ellipse-2"></div>
                  <a
                    href="#"
                    onclick="redirectTo('notifikasi.php'); return false;"
                  >
                    <img class="icon" src="img/notif_isi.png" />
                  </a>
                  <a
                    href="#"
                    onclick="redirectTo('scan_qr.php'); return false;"
                  >
                    <img class="icon-money-bills" src="img/money.png" />
                  </a>
                </div>
                <div class="ellipse-3"></div>
                <div class="overlap-5">
                  <!-- <div class="text-wrapper-13">🔎</div>
                  <div class="text-wrapper-14">Cari Transaksi disini yaa!</div> -->
                </div>
                <img class="logo-nama-removebg" src="img/money_save.png" />
                <img class="arrow" src="img/Arrow-2.png" />
                <img class="image" src="img/image-1.png" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <script>
      const urlParams = new URLSearchParams(window.location.search);
      const nik = urlParams.get("nik");

      function redirectTo(targetPage) {
        if (nik) {
          // Arahkan ke halaman tujuan dengan NIK
          window.location.href = targetPage + "?nik=" + encodeURIComponent(nik);
        } else {
          alert("NIK tidak ditemukan!");
          console.error("NIK parameter is missing");
          // Arahkan ke beranda.php sebagai fallback
          window.location.href = "beranda.php";
        }
      }
    </script>
  </body>
</html>
