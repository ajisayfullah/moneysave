<!DOCTYPE html>
<html>
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta charset="utf-8" />
    <link rel="stylesheet" href="view/css/bootstrap.min.css" />
    <link rel="stylesheet" href="view/style/style_profile_awal.css" />
    <script src="view/js/bootstrap.min.js"></script>
  </head>
  <body>
    <div class="phone-frame">
      <div class="phone-screen">
        <div class="landing-menu">
          <div class="div">
            <div class="menu-lengkap">
              <div class="div">
                <img class="logo-nama-removebg" src="img/money_save.png" />
                <div class="ellipse"></div>
                <img class="profile-picture" src="img/profile_picture.png" />
                <div class="overlap">
                  <div class="rectangle"></div>
                  <div class="text-wrapper">Beranda</div>
                  <a
                    href="#"
                    onclick="redirectTo('riwayat.php'); return false;"
                  >
                    <img class="home" src="img/riwayat_polos.png" />
                  </a>
                  <a
                    href="#"
                    onclick="redirectTo('profile_awal.php'); return false;"
                  >
                    <img class="white-user-icon" src="img/profile_isi.png" />
                  </a>
                  <div
                    class="kelaur"
                    onclick="window.location.href='../moneysave/landing_menu.html'"
                    style="cursor: pointer"
                  >
                    <div class="overlap-group">
                      <div class="arrow-icon"></div>
                      <div class="help-center">Keluar</div>
                    </div>
                  </div>
                  <div class="text-wrapper-2">Riwayat</div>
                  <div class="text-wrapper-3">Profile</div>
                  <div class="text-wrapper-4">Notifikasi</div>
                  <div class="ellipse-2"></div>
                  <a
                    href="#"
                    onclick="redirectTo('notifikasi.php'); return false;"
                  >
                    <img
                      class="icon"
                      src="img/notif_polos.png"
                      alt="Notifikasi"
                    />
                  </a>
                  <a
                    href="#"
                    onclick="redirectTo('beranda.php'); return false;"
                  >
                    <img class="img" src="img/home_polos.png" />
                  </a>
                  <a
                    href="#"
                    onclick="redirectTo('scan_qr.php'); return false;"
                  >
                    <img class="icon-money-bills" src="img/money.png" />
                  </a>
                </div>
                <div class="my-info">
                  <div class="group">
                    <a
                      href="#"
                      onclick="redirectTo('profile.php'); return false;"
                      style="text-decoration: none; color: inherit"
                    >
                      <div class="overlap-group-2">
                        <div class="arrow-icon">
                          <img class="shape" src="img/arrow.png" />
                        </div>
                        <div class="text-wrapper-5">Informasi Profile</div>
                        <img class="profile-icon" src="img/profile_icon.png" />
                      </div>
                    </a>
                  </div>
                </div>
                <div class="settings">
                  <a
                    href="#"
                    onclick="redirectTo('keamanan_akun.php'); return false;"
                    style="text-decoration: none; color: inherit"
                  >
                    <div class="overlap-3">
                      <div class="arrow-icon">
                        <img class="shape" src="img/arrow.png" />
                      </div>
                      <div class="text-wrapper-5">Keamanan Akun</div>
                      <img class="icon-shield" src="img/guard_icon.png" />
                    </div>
                  </a>
                </div>

                <div class="overlap-group-wrapper">
                  <a
                    href="#"
                    onclick="redirectTo('settings.php'); return false;"
                    style="text-decoration: none; color: inherit"
                  >
                    <div class="overlap-4">
                      <div class="arrow-icon">
                        <img class="shape" src="img/arrow.png" />
                      </div>
                      <div class="text-wrapper-5">Settings</div>
                      <img class="settings-icon" src="img/settings_icon.png" />
                    </div>
                  </a>
                </div>

                <!-- Syarat & Ketentuan -->
                <div class="div-wrapper">
                  <a
                    href="#"
                    onclick="redirectTo('syarat_ketentuan.php'); return false;"
                    style="text-decoration: none; color: inherit"
                  >
                    <div class="overlap-5">
                      <div class="arrow-icon">
                        <img class="shape" src="img/arrow.png" />
                      </div>
                      <div class="text-wrapper-5">Syarat &amp; Ketentuaan</div>
                      <img
                        class="icon-comment-circle"
                        src="img/information_icon.png"
                      />
                    </div>
                  </a>
                </div>

                <!-- Help Center -->
                <div class="overlap-wrapper">
                  <a
                    href="#"
                    onclick="redirectTo('help_center.php'); return false;"
                    style="text-decoration: none; color: inherit"
                  >
                    <div class="overlap-2">
                      <div class="arrow-icon">
                        <img class="shape" src="img/arrow.png" />
                      </div>
                      <div class="text-wrapper-5">Help Center</div>
                      <img class="icon-information" src="img/help_icon.png" />
                    </div>
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <script>
      // Ambil parameter NIK dari URL saat ini
      const urlParams = new URLSearchParams(window.location.search);
      const nik = urlParams.get("nik");

      /**
       * Fungsi umum untuk redirect ke halaman tujuan dengan parameter NIK
       * @param {string} targetPage - Halaman tujuan (misalnya 'profile.php', 'settings.html')
       */
      function redirectTo(targetPage) {
        if (nik) {
          // Arahkan ke halaman tujuan dengan menyertakan NIK di query string
          window.location.href = targetPage + "?nik=" + encodeURIComponent(nik);
        } else {
          // Tampilkan alert jika NIK tidak ditemukan
          alert("NIK tidak ditemukan di URL!");
          console.error("NIK parameter is missing in URL");

          // Alihkan ke halaman utama sebagai fallback
          window.location.href = "beranda.php";
        }
      }
    </script>
  </body>
</html>
