<?php
// Koneksi ke database
$koneksi = new mysqli("localhost", "root", "", "moneysave");

// Cek koneksi
if ($koneksi->connect_error) {
  die("Koneksi gagal: " . $koneksi->connect_error);
}

// Ambil nik dari GET
$nik = $_GET['nik'] ?? '';

// Ambil cabang dan no_rekening dari rekening_tabungan
$cabang = "Cabang Tidak Diketahui";
$no_rekening = "Belum Ada";
$stmt1 = $koneksi->prepare("SELECT cabang, no_rekening FROM rekening_tabungan WHERE nik = ?");
$stmt1->bind_param("s", $nik);
$stmt1->execute();
$result1 = $stmt1->get_result();
if ($result1 && $result1->num_rows > 0) {
  $row1 = $result1->fetch_assoc();
  $cabang = $row1['cabang'];
  $no_rekening = $row1['no_rekening'];
}
$stmt1->close();

// Ambil nama dan no_hp dari daftar
$nama_pemilik = "Pengguna";
$nama_ktp = "Nama tidak ditemukan";
$no_hp_format = "0000-0000-0000-****"; // default

$stmt2 = $koneksi->prepare("SELECT nama, no_hp FROM daftar WHERE nik = ?");
$stmt2->bind_param("s", $nik);
$stmt2->execute();
$result2 = $stmt2->get_result();

if ($result2 && $result2->num_rows > 0) {
  $row2 = $result2->fetch_assoc();
  $nama_pemilik = $row2['nama'];
  $nama_ktp = $row2['nama'];
  $no_hp = preg_replace('/[^0-9]/', '', $row2['no_hp']); // hanya ambil angka
  if (strlen($no_hp) >= 12) {
    $no_hp_format = substr($no_hp, 0, 4) . '-' .
      substr($no_hp, 4, 4) . '-' .
      substr($no_hp, 8, 4);
  }
}
$stmt2->close();

$setoran = "********"; // default
$stmt3 = $koneksi->prepare("SELECT setoran FROM daftar WHERE nik = ?");
$stmt3->bind_param("s", $nik);
$stmt3->execute();
$result3 = $stmt3->get_result();

if ($result3 && $result3->num_rows > 0) {
  $row3 = $result3->fetch_assoc();
  $setoran = $row3['setoran'];
}
$stmt3->close();

// Hitung bunga 1%
$bunga = 0;
if (is_numeric($setoran)) {
  $bunga = $setoran * 0.01;
}

// Ambil data target dan rincian_pengeluaran
$data = ['target' => null];

$stmt4 = $koneksi->prepare("
    SELECT t.id AS target_id, t.tujuan, t.deadline, t.jumlah_target, t.nominal, r.nama, r.amount
    FROM target t
    LEFT JOIN rincian_pengeluaran r ON t.id = r.target_id
    WHERE t.nik = ?
    ORDER BY t.id DESC
    LIMIT 1
");
$stmt4->bind_param("s", $nik);
$stmt4->execute();
$result4 = $stmt4->get_result();

$targetData = [];

while ($row = $result4->fetch_assoc()) {
  if (!isset($targetData['tujuan'])) {
    $targetData = [
      'tujuan' => $row['tujuan'],
      'deadline' => $row['deadline'],
      'jumlah_target' => $row['jumlah_target'],
      'nominal' => $row['nominal'],
      'rincian' => []
    ];
  }
  if ($row['nama']) {
    $targetData['rincian'][] = [
      'nama' => $row['nama'],
      'amount' => $row['amount']
    ];
  }
}

if (!empty($targetData['tujuan'])) {
  $data['target'] = $targetData;
}
$stmt4->close();

// Tutup koneksi
$koneksi->close();
?>
<!DOCTYPE html>
<html>

<head>
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <meta charset="utf-8" />
  <link rel="stylesheet" href="view/css/bootstrap.min.css" />
  <link rel="stylesheet" href="view/style/style_beranda.css" />
  <script src="view/js/bootstrap.min.js"></script>
  <style>
    /* Tambahan agar progress bar dan rincian lebih mirip gambar */
    .target-card {
      margin-bottom: 18px;
      border-radius: 12px;
      border: 1px solid #e0e0e0;
      background: #fff;
      box-shadow: 0 2px 8px #0001;
      padding: 18px 18px 10px 18px;
      position: relative;
    }

    .target-card-header {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
    }

    .target-title {
      font-weight: bold;
      font-size: 1.08em;
      margin-bottom: 2px;
    }

    .target-deadline {
      font-size: 0.95em;
      color: #888;
      margin-bottom: 8px;
    }

    .target-nominal {
      font-weight: bold;
      font-size: 1.1em;
      color: #e16417;
      margin-bottom: 8px;
      text-align: right;
    }

    .progress-bar-wrap {
      background: #f1e7e2;
      border-radius: 8px;
      height: 7px;
      margin: 8px 0 8px 0;
      width: 100%;
      position: relative;
      overflow: hidden;
    }

    .progress-bar-inner {
      background: linear-gradient(90deg, #e16417 60%, #ffb47b 100%);
      height: 100%;
      border-radius: 8px;
      transition: width 0.5s;
    }

    .progress-labels {
      display: flex;
      justify-content: space-between;
      font-size: 0.95em;
      color: #e16417;
      margin-bottom: 6px;
      margin-top: -2px;
    }

    .rincian-list {
      margin-top: 8px;
      background: #f8f8f8;
      border-radius: 8px;
      padding: 10px 12px 6px 12px;
      font-size: 0.98em;
      display: none;
    }

    .rincian-list.show {
      display: block;
    }

    .toggle-arrow {
      width: 15px;
      height: 15px;
      cursor: pointer;
      margin-left: 8px;
      margin-top: 0px;
      transition: transform 0.2s;
    }

    .target-header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      max-width: 350px;
      margin: 32px auto 8px auto;
      padding: 0 8px;
    }

    .target-header .text-wrapper-13 {
      font-size: 1.1em;
      font-weight: bold;
      color: #222;
      margin: 0;
      padding: 0;
    }

    .target-header .overlap-group-2 {
      display: flex;
      align-items: center;
      gap: 8px;
      background: none;
      box-shadow: none;
      margin: 0;
      padding: 0;
    }

    .target-header .text-wrapper-14 {
      background: #e16417;
      color: #fff;
      border-radius: 6px;
      padding: 6px 16px;
      font-weight: 600;
      font-size: 1em;
      cursor: pointer;
      margin-right: 2px;
    }

    .target-header .download-removebg {
      width: 22px;
      height: 22px;
      margin-left: 2px;
    }
  </style>
</head>

<body>
  <div class="phone-frame">
    <div class="phone-screen">
      <div class="landing-menu">
        <div class="div">
          <div class="main-page">
            <div class="div">
              <!-- Header & Greeting -->
              <div class="overlap">
                <div class="overlap-group">
                  <img class="logo-nama-removebg" src="img/money_save.png" />
                  <div class="text-wrapper" id="greeting">
                    <!-- Akan diganti dengan JavaScript -->
                  </div>
                  <img class="line" src="img/vector_line.png" />
                </div>
                <img class="ellipse" src="img/foto.png" />
              </div>
              <div class="ellipse-2"></div>
              <!-- Card Saldo -->
              <div class="overlap-2" style="margin-top: 18px;">
                <img class="vector" src="img/vector_line.png" />
                <div class="text-wrapper-2"><?php echo htmlspecialchars($setoran); ?></div>
                <div class="text-wrapper-3"><?php echo htmlspecialchars($nama_ktp); ?></div>
                <div class="overlap-3">
                  <p class="p"><?php echo htmlspecialchars($cabang); ?> | <?php echo htmlspecialchars($no_hp_format); ?></p>
                </div>
                <div class="text-wrapper-4">Rp</div>
                <img class="fi-rr-copy" src="img/copy.png" />
                <div class="text-wrapper-5">Pendapatan Bunga</div>
                <div class="text-wrapper-6">Rp <?php echo number_format($bunga, 0, ',', '.'); ?></div>
                <div class="text-wrapper-7">7,00% p.a</div>
                <div class="text-wrapper-8">Suku Bunga</div>
              </div>
              <img class="img" src="img/vector_line.png" />
              <!-- Target Section: letakkan di sini, di dalam .main-page .div, setelah garis dan sebelum hotbar -->
              <div class="target-header" style="margin-top:350px;">
                <span class="text-wrapper-13">Target Menabung</span>
                <div class="overlap-group-2">
                  <div class="text-wrapper-14" onclick="openPopup()">Tambah Target</div>
                  <img class="download-removebg" src="img/tambah.png" onclick="openPopup()" />
                </div>
              </div>
              <div id="target-display" class="target-scrollbox" style="margin-top: 8px;">
                <p>Memuat data...</p>
              </div>
              <!-- Popup overlay hanya muncul saat tambah target -->
              <div class="popup-overlay" id="popup" style="display:none;">
                <div class="popup-content">
                  <span class="close-btn" onclick="closePopup()">×</span>
                  <h3 class="popup-title">Tambah Target</h3>
                  <form id="targetForm">
                    <input type="hidden" name="nik" value="<?= htmlspecialchars($nik); ?>">
                    <label for="tujuan" class="popup-label">Target</label>
                    <input
                      type="text"
                      id="tujuan"
                      name="tujuan"
                      class="form-control popup-input"
                      placeholder="Target" />
                    <label for="deadline" class="popup-label">Tenggat Waktu</label>
                    <div class="input-group">
                      <input
                        type="date"
                        id="deadline"
                        name="deadline"
                        class="form-control popup-input"
                        placeholder="Tenggat Waktu" />
                      <span class="input-group-text popup-calendar-icon">📅</span>
                    </div>
                    <h4 class="popup-subtitle">Rincian Pengeluaran</h4>
                    <div class="expense-details">
                      <div class="expense-row">
                        <input
                          type="text"
                          placeholder="Pengeluaran"
                          class="form-control expense-input" />
                        <input
                          type="text"
                          placeholder="000.000.000,00"
                          class="form-control expense-amount" />
                      </div>
                      <div class="expense-row">
                        <input
                          type="text"
                          placeholder="Pengeluaran"
                          class="form-control expense-input" />
                        <input
                          type="text"
                          placeholder="000.000.000,00"
                          class="form-control expense-amount" />
                      </div>
                    </div>
                    <div class="expense-row">
                      <input
                        type="text"
                        placeholder="Pengeluaran"
                        class="form-control expense-input" />
                      <input
                        type="text"
                        placeholder="000.000.000,00"
                        class="form-control expense-amount" />
                    </div>
                    <div class="expense-row">
                      <input
                        type="text"
                        placeholder="Pengeluaran"
                        class="form-control expense-input" />
                      <input
                        type="text"
                        placeholder="000.000.000,00"
                        class="form-control expense-amount" />
                    </div>
                    <div class="add-expense">
                      <span>Tambah Rincian Pengeluaran</span>
                      <button
                        type="button"
                        class="add-expense-btn">
                        +
                      </button>
                    </div>
                    <div class="popup-buttons">
                      <button
                        type="submit"
                        class="popup-save-btn">
                        Simpan
                      </button>
                      <button
                        type="button"
                        class="popup-cancel-btn"
                        onclick="closePopup()">
                        Batal
                      </button>
                    </div>
                  </form>
                </div>
              </div>
              <!-- Bottom Navigation (hotbar) -->
              <div class="overlap-4">
                <div class="rectangle"></div>
                <a href="beranda.php?nik=<?= urlencode($nik) ?>">
                  <img class="home" src="img/home.png" />
                </a>
                <a href="profile_awal.php?nik=<?= urlencode($nik) ?>">
                  <img class="home-2" src="img/profile.png" />
                </a>
                <div class="text-wrapper-9">Beranda</div>
                <a href="riwayat.php?nik=<?= urlencode($nik) ?>">
                  <img class="home-3" src="img/riwayat.png" />
                </a>
                <div class="text-wrapper-10">Riwayat</div>
                <div class="text-wrapper-11">Profile</div>
                <div class="text-wrapper-12">Notifikasi</div>
                <div class="ellipse-3"></div>
                <a href="notifikasi.php?nik=<?= urlencode($nik) ?>">
                  <img class="icon" src="img/notifikasi.png" />
                </a>
                <a href="scan_qr.php?nik=<?= urlencode($nik) ?>">
                  <img class="icon-money-bills" src="img/money.png" />
                </a>
              </div>
            <!-- ...existing code... -->
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- JavaScript -->
  <script>
    // Ambil NIK dari URL
    const urlParams = new URLSearchParams(window.location.search);
    const nik = urlParams.get('nik');

    // Format angka sebagai mata uang (IDR)
    function formatCurrency(value) {
      return new Intl.NumberFormat('id-ID').format(value);
    }

    // Ambil nilai numerik dari teks HTML
    const getNumberFromText = (selector) => {
      const text = document.querySelector(selector)?.innerText.replace(/[^\d]/g, "") || "0";
      return parseInt(text, 10) || 0;
    };

    // Hitung progress tabungan
    function updateProgress() {
      const collectedSavings = getNumberFromText(".text-wrapper-16");
      const totalTarget = getNumberFromText(".text-wrapper-17");
      const progressPercentage = totalTarget ? (collectedSavings / totalTarget) * 100 : 0;

      const progressBar = document.querySelector(".progress");
      const progressIndicator = document.querySelector(".progress-indicator");

      if (progressBar) progressBar.style.width = `${progressPercentage}%`;
      if (progressIndicator) progressIndicator.style.left = `calc(${progressPercentage}% - 6px)`;
    }

    // Ucapan selamat berdasarkan waktu
    function setGreeting(userName = "Pengguna") {
      const now = new Date();
      const jakartaTime = new Date(now.toLocaleString("en-US", {
        timeZone: "Asia/Jakarta"
      }));
      const hours = jakartaTime.getHours();

      let greeting = "",
        emoji = "";
      if (hours >= 4 && hours < 11) {
        greeting = "Selamat Pagi";
        emoji = "🌅";
      } else if (hours >= 11 && hours < 15) {
        greeting = "Selamat Siang";
        emoji = "🌞";
      } else if (hours >= 15 && hours < 18) {
        greeting = "Selamat Sore";
        emoji = "🌇";
      } else {
        greeting = "Selamat Malam";
        emoji = "🌑";
      }

      const greetingElement = document.getElementById("greeting");
      if (greetingElement) {
        greetingElement.innerText = `${greeting}, ${userName} ${emoji}`;
      }
    }

    // Buka popup tambah target
    function openPopup() {
      var popup = document.getElementById("popup");
      if (popup) {
        popup.style.display = "flex";
      }
    }

    // Tutup popup dan reset field
    function closePopup() {
      var popup = document.getElementById("popup");
      if (popup) {
        popup.style.display = "none";
      }
      const expenseDetails = document.querySelector('.expense-details');
      if (expenseDetails) {
        expenseDetails.innerHTML = `
        <div class="expense-row">
          <input type="text" placeholder="Pengeluaran" class="form-control popup-input expense-input" />
          <input type="text" placeholder="Rp 000.000.000,00" class="form-control popup-input expense-amount" />
        </div>
        <div class="expense-row">
          <input type="text" placeholder="Pengeluaran" class="form-control popup-input expense-input" />
          <input type="text" placeholder="Rp 000.000.000,00" class="form-control popup-input expense-amount" />
        </div>`;
      }
    }

    // Template baris rincian pengeluaran
    function getExpenseRowHTML() {
      return `
      <div class="expense-row">
        <input type="text" placeholder="Pengeluaran" class="form-control popup-input expense-input" />
        <input type="text" placeholder="Rp 000.000.000,00" class="form-control popup-input expense-amount" />
      </div>`;
    }

    // Format otomatis input mata uang saat ketik
    function formatCurrencyInput(input) {
      let value = input.value.replace(/[^\d]/g, '');
      if (value) {
        value = parseInt(value);
        input.value = formatCurrency(value);
      }
      return value;
    }

    // Event listener untuk format input
    document.addEventListener('input', function(e) {
      if (e.target.classList.contains('expense-amount')) {
        formatCurrencyInput(e.target);
      }
    });

    // Tambahkan baris rincian baru
    document.addEventListener('DOMContentLoaded', function() {
      document.querySelector('.add-expense-btn')?.addEventListener('click', function() {
        const container = document.querySelector('.expense-details');
        const row = document.createElement('div');
        row.className = 'expense-row';
        row.innerHTML = getExpenseRowHTML();
        container.appendChild(row);
      });
    });

    // Kirim form tambah target via AJAX
    document.getElementById('targetForm')?.addEventListener('submit', function(e) {
      e.preventDefault();

      const target = document.querySelector('#tujuan').value.trim();
      const deadline = document.querySelector('#deadline').value;
      const expenseRows = document.querySelectorAll('.expense-row');
      const rincian = [];

      expenseRows.forEach(row => {
        const nama = row.querySelector('.expense-input').value.trim();
        const amountStr = row.querySelector('.expense-amount').value.replace(/[^\d]/g, '');
        const amount = amountStr ? parseFloat(amountStr) : 0;

        if (nama && amount > 0) {
          rincian.push({
            nama,
            amount
          });
        }
      });

      if (!nik) {
        alert("NIK tidak ditemukan!");
        return;
      }

      if (!target || !deadline || isNaN(new Date(deadline))) {
        alert("Harap isi Target dan Tenggat Waktu dengan benar!");
        return;
      }

      fetch('simpan_target.php', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            nik,
            tujuan: target,
            deadline,
            rincian
          })
        })
        .then(res => res.json())
        .then(data => { // <-- perbaiki baris ini
          if (data.success) {
            alert("Data berhasil disimpan!");
            closePopup();
            loadTargetData(); // Refresh tampilan target
          } else {
            alert("Gagal menyimpan: " + (data.message || "Unknown error"));
          }
        })
        .catch(err => {
          console.error("Error:", err);
          alert("Terjadi kesalahan saat mengirim data.");
        });
    });

    // Load data target & rincian_pengeluaran
    async function loadTargetData() {
      if (!nik) return;

      try {
        const response = await fetch(`tampilkan_data_json.php?nik=${nik}`);
        const result = await response.json();

        const display = document.getElementById("target-display");
        display.innerHTML = "";

        if (!result.success || !result.data.length) {
          display.innerHTML = "<p style='color:#888;'>Belum ada target menabung.</p>";
          return;
        }

        // Ambil nominal setoran dari PHP (jumlah_setoran_pertama)
        const nominalSetoran = <?php echo is_numeric($setoran) ? (int)$setoran : 0; ?>;

        result.data.forEach(target => {
          // Hitung total rincian (jumlah target)
          const rincian = target.rincian || [];
          const totalRincian = rincian.reduce((sum, r) => sum + Number(r.amount), 0);

          // Format deadline
          let deadlineStr = "-";
          if (target.deadline) {
            const d = new Date(target.deadline);
            deadlineStr = d.toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' });
          }

          // Rincian list
          const rincianList = rincian.length
            ? rincian.map(r => `<li>${r.nama} <span style="float:right">Rp ${formatCurrency(r.amount)}</span></li>`).join("")
            : "<li><i>Tidak ada rincian</i></li>";

          // Card HTML
          const card = document.createElement("div");
          card.className = "target-card";
          card.innerHTML = `
            <div class="target-card-header">
              <div>
                <div class="target-title">${target.tujuan}</div>
                <div class="target-deadline">${deadlineStr}</div>
              </div>
              <div style="display:flex;align-items:center;">
                <div class="target-nominal">Rp ${formatCurrency(totalRincian)}</div>
                <img src="img/arrow_down.png" alt="Show" class="toggle-arrow" onclick="toggleRincian(this)">
              </div>
            </div>
            <div class="progress-labels">
              <span style="color:#e16417;">Rp ${formatCurrency(nominalSetoran)}</span>
              <span style="color:#e16417;">Rp ${formatCurrency(totalRincian)}</span>
            </div>
            <div class="progress-bar-wrap">
              <div class="progress-bar-inner" style="width:${totalRincian > 0 ? Math.round((nominalSetoran / totalRincian) * 100) : 0}%;"></div>
            </div>
            <div class="rincian-list">
              <ul style="list-style:none;padding-left:0;margin-bottom:0;">
                ${rincianList}
              </ul>
            </div>
          `;
          display.appendChild(card);
        });

      } catch (err) {
        console.error("Gagal mengambil data target:", err);
      }
    }

    // Toggle rincian pengeluaran
    function toggleRincian(arrow) {
      const rincianList = arrow.closest('.target-card').querySelector('.rincian-list');
      const isVisible = rincianList.classList.contains('show');
      rincianList.classList.toggle('show');
      arrow.style.transform = isVisible ? 'rotate(0deg)' : 'rotate(180deg)';
      arrow.src = isVisible ? 'img/arrow_down.png' : 'img/arrow_up.png';
    }

    // Jalankan fungsi saat DOM siap
    document.addEventListener("DOMContentLoaded", () => {
      const userName = "<?php echo $nama_pemilik; ?>";
      setGreeting(userName);
      updateProgress();

      if (nik) {
        loadTargetData();
      } else {
        document.getElementById("target-display").innerHTML = "<p>NIK tidak tersedia di URL.</p>";
      }
    });

    // Pastikan event listener dipasang setelah DOM siap
    document.addEventListener('DOMContentLoaded', function() {
      var btnTambah = document.getElementById('btnTambahTarget');
      var imgTambah = document.getElementById('imgTambahTarget');
      if (btnTambah) btnTambah.addEventListener('click', openPopup);
      if (imgTambah) imgTambah.addEventListener('click', openPopup);
      // ...existing code...
    });

    // ...existing code...
  </script>
</body>
</html>