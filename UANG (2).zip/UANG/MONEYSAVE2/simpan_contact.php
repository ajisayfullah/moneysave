<?php
$koneksi = new mysqli("localhost", "root", "", "moneysave");
if ($koneksi->connect_error) {
    die("Koneksi gagal: " . $koneksi->connect_error);
}

$nik = $_POST['nik'] ?? '';
$no_hp = $_POST['no_hp'] ?? '';
$email = $_POST['email'] ?? '';

if ($nik && $no_hp && $email) {
    $stmt = $koneksi->prepare("UPDATE pendaftaran_rekening SET no_hp = ?, email = ? WHERE nik = ?");
    $stmt->bind_param("sss", $no_hp, $email, $nik);
    if ($stmt->execute()) {
        // Redirect atau beri pesan sukses
        header("Location: smart_login.html?nik=" . urlencode($nik));
        exit;
    } else {
        echo "Error saat menyimpan data: " . $stmt->error;
    }
} else {
    echo "Data tidak lengkap!";
}
