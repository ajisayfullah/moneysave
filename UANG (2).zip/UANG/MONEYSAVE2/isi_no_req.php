<?php
$host = "localhost";
$user = "root";
$pass = "";
$db   = "moneysave";

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
  die("Koneksi gagal: " . $conn->connect_error);
}

$query = "SELECT no_rekening FROM pendaftaran_rekening ORDER BY id DESC LIMIT 1";
$result = $conn->query($query);
$row = $result->fetch_assoc();
$noRekening = $row ? $row['no_rekening'] : '';
?>

<!DOCTYPE html>
<html>

<head>
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <meta charset="utf-8" />
  <link rel="stylesheet" href="view/css/bootstrap.min.css" />
  <script src="view/js/bootstrap.min.js"></script>
</head>

<body>
  <style>
    @import url("https://cdnjs.cloudflare.com/ajax/libs/meyer-reset/2.0/reset.min.css");

    * {
      -webkit-font-smoothing: antialiased;
      box-sizing: border-box;
    }

    html,
    body {
      margin: 0px;
      height: 100%;
    }

    /* a blue color as a generic focus style */
    button:focus-visible {
      outline: 2px solid #4a90e2 !important;
      outline: -webkit-focus-ring-color auto 5px !important;
    }

    a {
      text-decoration: none;
    }

    .isi-nomor-rekening {
      background-color: #ffffff;
      display: flex;
      flex-direction: row;
      justify-content: center;
      width: 100%;
    }

    .isi-nomor-rekening .div {
      background-color: #ffffff;
      width: 360px;
      height: 800px;
      position: relative;
    }

    .isi-nomor-rekening .text-wrapper {
      position: absolute;
      top: 209px;
      left: 47px;
      font-family: "Alatsi-Regular", Helvetica;
      font-weight: 400;
      color: #e16417;
      font-size: 19px;
      letter-spacing: 0;
      line-height: normal;
    }

    .isi-nomor-rekening .masukkan-data-nomor {
      position: absolute;
      top: 241px;
      left: 47px;
      font-family: "Alatsi-Regular", Helvetica;
      font-weight: 400;
      color: #095f7b;
      font-size: 11px;
      letter-spacing: 0;
      line-height: normal;
    }

    .isi-nomor-rekening .logo-nama-removebg {
      position: absolute;
      width: 150px;
      height: 100px;
      top: 32px;
      left: 105px;
      object-fit: cover;
    }

    .isi-nomor-rekening .overlap-group {
      width: 266px;
      top: 726px;
      left: 47px;
      position: absolute;
      height: 40px;
      border-radius: 5px;
    }

    .isi-nomor-rekening .rectangle {
      position: absolute;
      width: 266px;
      height: 40px;
      top: 0;
      left: 0;
      background-color: #e16417;
      border-radius: 5px;
    }

    .isi-nomor-rekening .text-wrapper-2 {
      position: absolute;
      top: 8px;
      left: 65px;
      font-family: "Qualion-DemiBold", Helvetica;
      font-weight: 700;
      color: #ffffff;
      font-size: 13px;
      letter-spacing: 0;
      line-height: normal;
    }

    .isi-nomor-rekening .group {
      position: absolute;
      width: 264px;
      height: 45px;
      top: 673px;
      left: 49px;
    }

    .isi-nomor-rekening .OJK {
      position: absolute;
      width: 60px;
      height: 45px;
      top: 0;
      left: 0;
      object-fit: cover;
    }

    .isi-nomor-rekening .logo-lps {
      position: absolute;
      width: 60px;
      height: 36px;
      top: 7px;
      left: 102px;
      object-fit: cover;
    }

    .isi-nomor-rekening .logo-bun {
      position: absolute;
      width: 60px;
      height: 21px;
      top: 15px;
      left: 204px;
      object-fit: cover;
    }

    .isi-nomor-rekening .text-wrapper-3 {
      position: absolute;
      width: 210px;
      top: 289px;
      left: 48px;
      font-family: "Qualion-DemiBold", Helvetica;
      font-weight: 700;
      color: #095f7b;
      font-size: 12px;
      letter-spacing: 0;
      line-height: normal;
    }

    .isi-nomor-rekening .text-wrapper-4 {
      position: absolute;
      width: 210px;
      top: 360px;
      left: 48px;
      font-family: "Qualion-DemiBold", Helvetica;
      font-weight: 700;
      color: #095f7b;
      font-size: 12px;
      letter-spacing: 0;
      line-height: normal;
    }

    .isi-nomor-rekening .text-wrapper-5 {
      position: absolute;
      width: 210px;
      top: 431px;
      left: 48px;
      font-family: "Qualion-DemiBold", Helvetica;
      font-weight: 700;
      color: #095f7b;
      font-size: 12px;
      letter-spacing: 0;
      line-height: normal;
    }

    .isi-nomor-rekening .text-wrapper-6 {
      position: absolute;
      width: 210px;
      top: 502px;
      left: 48px;
      font-family: "Qualion-DemiBold", Helvetica;
      font-weight: 700;
      color: #095f7b;
      font-size: 12px;
      letter-spacing: 0;
      line-height: normal;
    }

    .isi-nomor-rekening .overlap {
      width: 285px;
      top: 313px;
      left: 48px;
      border: 1px solid;
      border-color: #095f7b;
      position: absolute;
      height: 40px;
      border-radius: 5px;
    }

    .isi-nomor-rekening .text-wrapper-7 {
      position: absolute;
      width: 184px;
      top: 10px;
      left: 18px;
      font-family: "Qualion-DemiBold", Helvetica;
      font-weight: 700;
      color: #095f7b;
      font-size: 10px;
      letter-spacing: 0;
      line-height: normal;
    }

    .isi-nomor-rekening .div-wrapper {
      width: 285px;
      top: 384px;
      left: 48px;
      border: 1px solid;
      border-color: #095f7b;
      position: absolute;
      height: 40px;
      border-radius: 5px;
    }

    .isi-nomor-rekening .overlap-2 {
      width: 285px;
      top: 455px;
      left: 48px;
      border: 1px solid;
      border-color: #095f7b;
      position: absolute;
      height: 40px;
      border-radius: 5px;
    }

    .isi-nomor-rekening .overlap-3 {
      width: 285px;
      top: 526px;
      left: 48px;
      border: 1px solid;
      border-color: #095f7b;
      position: absolute;
      height: 40px;
      border-radius: 5px;
    }

    .phone-frame {
      background-color: #dcdcdc;
      padding: 30px 12px;
      border-radius: 40px;
      box-shadow: 0 0 0 10px #888;
      display: flex;
      justify-content: center;
      align-items: center;
      min-height: 100vh;
    }
  </style>
  <div class="phone-frame">
    <div class="phone-screen">
      <div class="landing-menu">
        <div class="div">
          <div class="isi-nomor-rekening">
            <div class="div">
              <div class="text-wrapper">Isi Nomor Rekening</div>
              <p class="masukkan-data-nomor">
                Masukkan data nomor rekening kamu saat ini ya,<br />pastikan
                data sesuai dan valid
              </p>
              <img class="logo-nama-removebg" src="img/money_save.png" />
              <div class="group">
                <img class="OJK" src="img/OJK-1.png" />
                <img class="logo-lps" src="img/logo-lps-1.png" />
                <img class="logo-bun" src="img/logo-bun-1.png" />
              </div>
              <form id="form-rekening" method="post" action="proses_rekening.php">
                <div class="text-wrapper-3">Nomor Rekening</div>
                <div class="overlap">
                  <input
                    type="text"
                    value="<?php echo htmlspecialchars($noRekening); ?>"
                    readonly
                    name="no_rekening"
                    style="
                      width: 100%;
                      padding: 8px;
                      font-size: 16px;
                      border: 1px solid #ccc;
                      border-radius: 5px;
                      box-sizing: border-box;
                      outline: none;
                      box-shadow: none;
                      font-family: 'Qualion-DemiBold', Helvetica;
                    " />
                </div>
                <div class="text-wrapper-4">Nama Pemilik Rekening</div>
                <div class="div-wrapper">
                  <input
                    type="text"
                    name="nama_pemilik"
                    required
                    style="
                      width: 100%;
                      padding: 8px;
                      font-size: 16px;
                      border: 1px solid #ccc;
                      border-radius: 5px;
                      box-sizing: border-box;
                      outline: none;
                      box-shadow: none;
                      font-family: 'Qualion-DemiBold', Helvetica;
                    " />
                </div>
                <div class="text-wrapper-5">Cabang Pembuatan Rekening</div>
                <div class="overlap-2">
                  <input
                    type="text"
                    name="cabang"
                    required
                    style="
                      width: 100%;
                      padding: 8px;
                      font-size: 16px;
                      border: 1px solid #ccc;
                      border-radius: 5px;
                      box-sizing: border-box;
                      outline: none;
                      box-shadow: none;
                      font-family: 'Qualion-DemiBold', Helvetica;
                    " />
                </div>

                <div class="text-wrapper-6">Tanggal Pembuatan Rekening</div>
                <div class="overlap-3">
                  <input
                    type="date"
                    name="tgl_pembuatan"
                    required
                    style="
                      width: 100%;
                      padding: 8px;
                      font-size: 15px;
                      border: 1px solid #ccc;
                      border-radius: 5px;
                      box-sizing: border-box;
                      outline: none;
                      box-shadow: none;
                      font-family: 'Qualion-DemiBold', Helvetica;
                    " />
                </div>
                <div class="overlap-group" style="cursor: pointer">
                  <div class="rectangle"></div>
                  <button
                    type="submit"
                    class="text-wrapper-2"
                    style="background: none; border: none; color: white; cursor: pointer; ">
                    Lanjut Lengkapi Data
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <script>
    document.getElementById('form-rekening').addEventListener('submit', function(e) {
      e.preventDefault(); // cegah submit default karena pakai fetch

      const nama = document.querySelector('input[name="nama_pemilik"]').value;
      const cabang = document.querySelector('input[name="cabang"]').value;
      const tanggal = document.querySelector('input[name="tgl_pembuatan"]').value;

      if (!nama || !cabang || !tanggal) {
        alert('Harap lengkapi semua data yang diperlukan');
        return;
      }

      const today = new Date().toISOString().split('T')[0];
      if (tanggal > today) {
        alert('Tanggal pembuatan tidak boleh lebih dari hari ini');
        return;
      }

      const formData = new FormData();
      const noRekening = document.querySelector('input[name="no_rekening"]').value;
      formData.append('no_rekening', noRekening);
      formData.append('nama_pemilik', nama);
      formData.append('cabang', cabang);
      formData.append('tgl_pembuatan', tanggal);

      fetch('proses_rekening.php', {
          method: 'POST',
          body: formData
        })
        .then(response => response.json())
        .then(data => {
          if (data.success) {
            // Langsung redirect tanpa ubah tombol dan tanpa loading text
            window.location.href = 'validasi_data.php?nik=' + encodeURIComponent(data.nik);

          } else {
            alert(data.message || 'Gagal menyimpan data');
          }
        })
        .catch(error => {
          console.error('Error:', error);
          alert('Terjadi kesalahan saat menyimpan data');
        });
    });
  </script>
</body>

</html>