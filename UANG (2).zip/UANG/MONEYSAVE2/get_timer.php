<?php
header('Content-Type: application/json');

$host = "localhost";
$user = "root";
$pass = "";
$db = "moneysave";

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(['error' => 'Database connection failed']);
    exit;
}

if (!isset($_GET['nik'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Parameter nik diperlukan']);
    exit;
}

$nik = $conn->real_escape_string($_GET['nik']);

// Ambil timer_end dari tabel waktu
$sql = "SELECT timer_end FROM waktu WHERE nik = '$nik' LIMIT 1";
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    $row = $result->fetch_assoc();
    echo json_encode(['timer_end' => $row['timer_end']]);
} else {
    http_response_code(404);
    echo json_encode(['error' => 'Data waktu tidak ditemukan untuk NIK ini']);
}

$conn->close();
