<?php
header('Content-Type: application/json');

// Koneksi database
$conn = new mysqli('localhost', 'root', '', 'moneysave');
if ($conn->connect_error) {
    die(json_encode(['success' => false, 'message' => 'Koneksi database gagal']));
}

try {
    // Validasi input
    if (empty($_POST['nik'])) {
        throw new Exception("NIK tidak ditemukan");
    }

    if (empty($_POST['jenis_kelamin'])) {
        throw new Exception("Jenis kelamin harus dipilih");
    }

    $nik = $conn->real_escape_string($_POST['nik']);
    $jenis_kelamin = $conn->real_escape_string($_POST['jenis_kelamin']);

    // Validasi nilai jenis kelamin
    if (!in_array($jenis_kelamin, ['Laki-laki', 'Perempuan'])) {
        throw new Exception("Jenis kelamin tidak valid");
    }

    // Update hanya jenis kelamin
    $stmt = $conn->prepare("UPDATE pendaftaran_rekening SET jenis_kelamin = ? WHERE nik = ?");
    $stmt->bind_param("ss", $jenis_kelamin, $nik);

    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'message' => 'Data berhasil disimpan']);
    } else {
        throw new Exception("Gagal menyimpan data: " . $stmt->error);
    }

    $stmt->close();
    $conn->close();
} catch (Exception $e) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
