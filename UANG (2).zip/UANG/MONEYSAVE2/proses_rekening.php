<?php
header('Content-Type: application/json');

// Koneksi database
$host = "localhost";
$user = "root";
$pass = "";
$db   = "moneysave";

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    die(json_encode(['success' => false, 'message' => 'Koneksi database gagal']));
}

try {
    // Validasi input
    $required = ['no_rekening', 'nama_pemilik', 'cabang', 'tgl_pembuatan'];
    foreach ($required as $field) {
        if (empty($_POST[$field])) {
            throw new Exception("Field $field harus diisi");
        }
    }

    // Sanitasi input
    $noRekening = $conn->real_escape_string($_POST['no_rekening']);
    $nama       = $conn->real_escape_string($_POST['nama_pemilik']);
    $cabang     = $conn->real_escape_string($_POST['cabang']);
    $tanggal    = $conn->real_escape_string($_POST['tgl_pembuatan']);

    // Validasi tanggal
    $today = date('Y-m-d');
    if ($tanggal > $today) {
        throw new Exception("Tanggal tidak boleh lebih dari hari ini");
    }

    // Ambil nik dari pendaftaran_rekening berdasarkan no_rekening
    $stmtNik = $conn->prepare("SELECT nik FROM pendaftaran_rekening WHERE no_rekening = ?");
    if (!$stmtNik) {
        throw new Exception("Gagal menyiapkan statement untuk ambil nik: " . $conn->error);
    }
    $stmtNik->bind_param("s", $noRekening);
    $stmtNik->execute();
    $resultNik = $stmtNik->get_result();
    if ($resultNik->num_rows == 0) {
        throw new Exception("No rekening tidak ditemukan di pendaftaran_rekening");
    }
    $rowNik = $resultNik->fetch_assoc();
    $nik = $rowNik['nik'];
    $stmtNik->close();

    // Insert ke rekening_tabungan dengan nik
    $stmt = $conn->prepare("INSERT INTO rekening_tabungan 
        (nik, no_rekening, nama_pemilik, cabang, tgl_pembuatan, created_at) 
        VALUES (?, ?, ?, ?, ?, NOW())");
    if (!$stmt) {
        throw new Exception("Gagal menyiapkan statement insert rekening_tabungan: " . $conn->error);
    }

    $stmt->bind_param("sssss", $nik, $noRekening, $nama, $cabang, $tanggal);

    if ($stmt->execute()) {
        echo json_encode([
            'success' => true,
            'message' => 'Data berhasil disimpan',
            'no_rekening' => $noRekening,
            'nik' => $nik
        ]);
    } else {
        throw new Exception("Gagal menyimpan rekening_tabungan: " . $stmt->error);
    }

    $stmt->close();
    $conn->close();
} catch (Exception $e) {
    if (isset($conn)) $conn->close();
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
