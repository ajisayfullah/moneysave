<?php
$host = "localhost";
$user = "root";
$pass = "";
$db = "moneysave";

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
  die("Koneksi gagal: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $nik = $_POST['nik'];
  $jumlah_setor = $_POST['jumlah_setor'];

  $stmt = $conn->prepare("INSERT INTO transaksi_riwayat (nik, tipe_transaksi, deskripsi, jumlah, tanggal_waktu_transaksi, created_at) VALUES (?, 'masuk', 'Setoran Tabungan', ?, NOW(), NOW())");
  $stmt->bind_param("sd", $nik, $jumlah_setor);
  if ($stmt->execute()) {
    header("Location: input_setoran.php?success=1");
    exit;
  } else {
    echo "Gagal menyimpan setoran.";
  }
}
?>

<!DOCTYPE html>
<html lang="id">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Input Setoran Pengguna</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link rel="stylesheet" href="style/style_input_setoran.css">
  <script src="view/js/bootstrap.min.js"></script>
</head>

<body>
  <div class="sidebar">
    <a href="index.php">Dashboard</a>
    <a href="konfirmasi_setoran.php">Konfirmasi Setoran Pertama</a>
    <a href="input_setoran.php" class="active">Input Setoran Pengguna</a>
    <a href="manajemen_pengguna.php">Manajemen Pengguna</a>
  </div>

  <div class="main">
    <h2 class="mb-4">Input Setoran Pengguna</h2>

    <div class="container mt-5">
      <div class="row justify-content-center">
        <div class="col-md-6">
          <div class="input-group input-group-lg mb-3">
            <span class="input-group-text bg-transparent border-0"></span>
            <input type="text" class="form-control rounded-pill" placeholder="Cari nama atau nomor rekening..." aria-label="Search">
          </div>
        </div>
      </div>
    </div>

    <div class="container">
      <div class="row g-3">
        <?php
        $sql = "SELECT nik, nama, no_rekening FROM daftar";
        $result = $conn->query($sql);

        if ($result->num_rows > 0):
          while ($row = $result->fetch_assoc()):
        ?>
            <div class="col-md-6">
              <div class="card shadow-sm">
                <div class="card-body d-flex justify-content-between align-items-center">
                  <div>
                    <h5 class="card-title mb-1"><?= htmlspecialchars($row['nama']) ?></h5>
                    <small>No. Rekening: <?= htmlspecialchars($row['no_rekening']) ?></small>
                  </div>
                  <a href="detail_tabungan.php?nik=<?= htmlspecialchars($row['nik']) ?>"
                    class="btn btn-outline-info btn-sm">Tabungan</a>
                </div>
                <div class="card-footer">
                  <form class="row g-2 align-items-center" method="POST" action="input_setoran.php">
                    <input type="hidden" name="nik" value="<?= htmlspecialchars($row['nik']) ?>">
                    <div class="col-5">
                      <label for="jumlahSetor<?= $row['nik'] ?>" class="form-label mb-0">Jumlah Setoran</label>
                    </div>
                    <div class="col-5">
                      <input type="number" name="jumlah_setor" id="jumlahSetor<?= $row['nik'] ?>"
                        class="form-control form-control-sm" placeholder="Rp" required>
                    </div>
                    <div class="col-2 text-end">
                      <button type="submit" class="btn btn-success btn-sm">Simpan</button>
                    </div>
                  </form>
                </div>
              </div>
            </div>
        <?php
          endwhile;
        else:
          echo '<p>Tidak ada data pengguna.</p>';
        endif;
        ?>
      </div>
    </div>
  </div>
</body>

</html>