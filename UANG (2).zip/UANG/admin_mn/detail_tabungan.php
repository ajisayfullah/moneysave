<?php
$host = "localhost";
$user = "root";
$pass = "";
$db = "moneysave";

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Ambil NIK dari URL
if (!isset($_GET['nik']) || empty($_GET['nik'])) {
    die("NIK pengguna tidak ditemukan.");
}
$nik = $_GET['nik'];

// Ambil data pengguna dari database
$sql_user = "SELECT nama, no_rekening FROM daftar WHERE nik = ?";
$stmt_user = $conn->prepare($sql_user);
$stmt_user->bind_param("s", $nik);
$stmt_user->execute();
$result_user = $stmt_user->get_result();

if ($result_user->num_rows == 0) {
    die("Pengguna tidak ditemukan.");
}

$user = $result_user->fetch_assoc();

// Ambil riwayat setoran/penarikan
$sql_transaksi = "
    SELECT tipe_transaksi, deskripsi, jumlah, tanggal_waktu_transaksi 
    FROM transaksi_riwayat 
    WHERE nik = ?
    ORDER BY tanggal_waktu_transaksi DESC
";
$stmt_transaksi = $conn->prepare($sql_transaksi);
$stmt_transaksi->bind_param("s", $nik);
$stmt_transaksi->execute();
$result_transaksi = $stmt_transaksi->get_result();
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Riwayat Tabungan - <?= htmlspecialchars($user['nama']) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="style/style_input_setoran.css">
</head>

<body class="bg-light">
    <div class="sidebar">
        <a href="index.php">Dashboard</a>
        <a href="konfirmasi_setoran.php">Konfirmasi Setoran Pertama</a>
        <a href="input_setoran.php" class="active">Input Setoran Pengguna</a>
        <a href="manajemen_pengguna.php">Manajemen Pengguna</a>
    </div>

    <div class="container mt-5">
        <h2>Riwayat Tabungan</h2>
        <p>
            <strong>NIK:</strong> <?= htmlspecialchars($nik) ?><br>
            <strong>Nama:</strong> <?= htmlspecialchars($user['nama']) ?><br>
            <strong>No. Rekening:</strong> <?= htmlspecialchars($user['no_rekening']) ?>
        </p>

        <table class="table table-bordered table-striped">
            <thead class="table-dark">
                <tr>
                    <th>Tanggal</th>
                    <th>Keterangan</th>
                    <th>Nominal</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($result_transaksi->num_rows > 0): ?>
                    <?php while ($row = $result_transaksi->fetch_assoc()): ?>
                        <tr>
                            <td><?= date('d-m-Y H:i', strtotime($row['tanggal_waktu_transaksi'])) ?></td>
                            <td><?= htmlspecialchars($row['deskripsi']) ?> (<?= $row['tipe_transaksi'] ?>)</td>
                            <td class="text-end">Rp<?= number_format($row['jumlah'], 0, ',', '.') ?></td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="3" class="text-center">Belum ada transaksi.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>

        <a href="input_setoran.php" class="btn btn-secondary">Kembali</a>
    </div>
</body>

</html>