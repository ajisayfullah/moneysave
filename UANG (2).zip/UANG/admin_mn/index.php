<?php
$host = "localhost";
$user = "root";
$pass = "";
$db = "moneysave";
$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
  die("Koneksi gagal: " . $conn->connect_error);
}

// Total pengguna
$resUser = $conn->query("SELECT COUNT(*) as total FROM daftar");
$totalUser = $resUser ? $resUser->fetch_assoc()['total'] : 0;

// Setoran bulan ini
$resSetor = $conn->query("SELECT SUM(jumlah) as total FROM transaksi_riwayat WHERE tipe_transaksi='masuk' AND MONTH(tanggal_waktu_transaksi)=MONTH(CURDATE()) AND YEAR(tanggal_waktu_transaksi)=YEAR(CURDATE())");
$totalSetor = $resSetor ? $resSetor->fetch_assoc()['total'] : 0;

// Transaksi hari ini
$resTrans = $conn->query("SELECT COUNT(*) as total FROM transaksi_riwayat WHERE DATE(tanggal_waktu_transaksi)=CURDATE()");
$totalTrans = $resTrans ? $resTrans->fetch_assoc()['total'] : 0;
?>
<!DOCTYPE html>
<html lang="id">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Dashboard Admin</title>
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css"
      rel="stylesheet"
    />
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
      /* Reset font dan background */
      body {
        font-family: "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;
        background: #f5f7fa;
        margin: 0;
        display: flex;
        min-height: 100vh;
      }

      /* Sidebar modern */
      .sidebar {
        width: 220px;
        background: linear-gradient(135deg, #ff7e00, #ffb347);
        height: 100vh;
        position: fixed;
        padding-top: 2rem;
        box-shadow: 2px 0 10px rgb(0 0 0 / 0.1);
        display: flex;
        flex-direction: column;
        gap: 0.5rem;
      }

      .sidebar a {
        color: white;
        font-weight: 600;
        text-decoration: none;
        padding: 0.9rem 1.5rem;
        border-radius: 8px;
        transition: background-color 0.3s ease;
        font-size: 1rem;
        user-select: none;
      }

      .sidebar a:hover,
      .sidebar a.active {
        background-color: rgba(255, 255, 255, 0.3);
        box-shadow: 0 4px 8px rgb(255 126 0 / 0.5);
      }

      /* Konten utama */
      .main {
        margin-left: 220px;
        padding: 2rem 2.5rem;
        flex-grow: 1;
        min-height: 100vh;
      }

      .card {
        margin-bottom: 20px;
      }
      /* Responsif */
      @media (max-width: 768px) {
        body {
          flex-direction: column;
        }

        .sidebar {
          width: 100%;
          height: auto;
          position: relative;
          flex-direction: row;
          padding: 0.5rem 1rem;
          overflow-x: auto;
          gap: 1rem;
          box-shadow: none;
        }

        .sidebar a {
          padding: 0.6rem 1rem;
          font-size: 0.9rem;
          white-space: nowrap;
        }

        .main {
          margin-left: 0;
          padding: 1.5rem 1rem;
        }

        table thead th {
          font-size: 0.85rem;
          padding: 8px 10px;
        }

        tbody td {
          font-size: 0.85rem;
          padding: 8px 10px;
        }
      }
    </style>
  </head>
  <body>
    <div class="sidebar">
      <a href="index.php" class="active">Dashboard</a>
      <a href="konfirmasi_setoran.php">Konfirmasi Setoran Pertama</a>
      <a href="input_setoran.php">Input Setoran Pengguna</a>
      <a href="manajemen_pengguna.php">Manajemen Pengguna</a>
    </div>
    <div class="main">
      <h2>Dashboard Admin</h2>
      <div class="row">
        <div class="col-md-4">
          <div class="card text-white bg-success">
            <div class="card-body">
              <h5 class="card-title">Total Pengguna</h5>
              <p class="card-text"><?= number_format($totalUser, 0, ',', '.') ?></p>
            </div>
          </div>
        </div>
        <div class="col-md-4">
          <div class="card text-white bg-info">
            <div class="card-body">
              <h5 class="card-title">Setoran Bulan Ini</h5>
              <p class="card-text">Rp <?= number_format($totalSetor, 0, ',', '.') ?></p>
            </div>
          </div>
        </div>
        <div class="col-md-4">
          <div class="card text-white bg-warning">
            <div class="card-body">
              <h5 class="card-title">Transaksi Hari Ini</h5>
              <p class="card-text"><?= number_format($totalTrans, 0, ',', '.') ?> transaksi</p>
            </div>
          </div>
        </div>
      </div>

      <div class="mt-5">
        <h4>Grafik Statistik Tahunan</h4>
        <canvas id="statsChart" height="100"></canvas>
      </div>
    </div>

    <script>
      const ctx = document.getElementById("statsChart").getContext("2d");
      const statsChart = new Chart(ctx, {
        type: "line",
        data: {
          labels: [
            "Jan",
            "Feb",
            "Mar",
            "Apr",
            "Mei",
            "Jun",
            "Jul",
            "Agu",
            "Sep",
            "Okt",
            "Nov",
            "Des",
          ],
          datasets: [
            {
              label: "Total Pengguna",
              data: [
                100, 150, 180, 210, 240, 270, 300, 320, 340, 360, 380, 400,
              ],
              borderColor: "green",
              backgroundColor: "rgba(0,128,0,0.1)",
              tension: 0.4,
              fill: false,
            },
            {
              label: "Setoran Bulan Ini",
              data: [8, 12, 15, 10, 14, 18, 22, 25, 28, 30, 29, 31],
              borderColor: "blue",
              backgroundColor: "rgba(0,0,255,0.1)",
              tension: 0.4,
              fill: false,
            },
            {
              label: "Transaksi Hari Ini",
              data: [10, 15, 12, 20, 18, 24, 30, 27, 25, 20, 18, 16],
              borderColor: "orange",
              backgroundColor: "rgba(255,165,0,0.1)",
              tension: 0.4,
              fill: false,
            },
          ],
        },
        options: {
          responsive: true,
          plugins: {
            legend: {
              position: "top",
            },
            title: {
              display: false,
            },
          },
          scales: {
            y: {
              beginAtZero: true,
            },
          },
        },
      });
    </script>
  </body>
</html>
<?php $conn->close(); ?>
