<?php
// Koneksi ke database
$host = "localhost";
$user = "root";
$pass = "";
$db = "moneysave";

$conn = new mysqli($host, $user, $pass, $db);

// Cek koneksi
if ($conn->connect_error) {
  die("Koneksi gagal: " . $conn->connect_error);
}

// Ambil parameter NIK dari URL
if (isset($_GET['nik'])) {
  $nik = $_GET['nik'];

  // Query data pengguna berdasarkan NIK dari tabel daftar
  $sql = "SELECT * FROM daftar WHERE nik = ?";
  $stmt = $conn->prepare($sql);
  $stmt->bind_param("s", $nik);
  $stmt->execute();
  $result = $stmt->get_result();
  $data = $result->fetch_assoc();

  if (!$data) {
    die("Data tidak ditemukan.");
  }
} else {
  die("NIK tidak diberikan.");
}
?>

<!DOCTYPE html>
<html lang="id">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Detail Pengguna</title>
  <link rel="stylesheet" href="view/css/bootstrap.min.css">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="view/js/bootstrap.min.js"></script>
  <style>
    .card {
      margin-top: 50px;
      border-radius: 12px;
      box-shadow: 0 8px 20px rgba(0, 0, 0, 0.08);
    }

    .card-header {
      background-color: #ffb347;
      font-weight: bold;
      font-size: 1.2rem;
    }

    .btn-back {
      margin-top: 20px;
    }

    body {
      font-family: "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;
      background: #f5f7fa;
      margin: 0;
      display: flex;
      min-height: 100vh;
    }

    /* Sidebar modern */
    .sidebar {
      width: 220px;
      background: linear-gradient(135deg, #ff7e00, #ffb347);
      height: 100vh;
      position: fixed;
      padding-top: 2rem;
      box-shadow: 2px 0 10px rgb(0 0 0 / 0.1);
      display: flex;
      flex-direction: column;
      gap: 0.5rem;
    }

    .sidebar a {
      color: white;
      font-weight: 600;
      text-decoration: none;
      padding: 0.9rem 1.5rem;
      border-radius: 8px;
      transition: background-color 0.3s ease;
      font-size: 1rem;
      user-select: none;
    }

    .sidebar a:hover,
    .sidebar a.active {
      background-color: rgba(255, 255, 255, 0.3);
      box-shadow: 0 4px 8px rgb(255 126 0 / 0.5);
    }

    /* Konten utama */
    .main {
      margin-left: 220px;
      padding: 2rem 2.5rem;
      flex-grow: 1;
      min-height: 100vh;
    }

    .card {
      margin-bottom: 20px;
    }

    /* Responsif */
    @media (max-width: 768px) {
      body {
        flex-direction: column;
      }

      .sidebar {
        width: 100%;
        height: auto;
        position: relative;
        flex-direction: row;
        padding: 0.5rem 1rem;
        overflow-x: auto;
        gap: 1rem;
        box-shadow: none;
      }

      .sidebar a {
        padding: 0.6rem 1rem;
        font-size: 0.9rem;
        white-space: nowrap;
      }

      .main {
        margin-left: 0;
        padding: 1.5rem 1rem;
      }

      table thead th {
        font-size: 0.85rem;
        padding: 8px 10px;
      }

      tbody td {
        font-size: 0.85rem;
        padding: 8px 10px;
      }
    }
  </style>
</head>

<body>

  <div class="sidebar">
    <a href="index.php">Dashboard</a>
    <a href="konfirmasi_setoran.php">Konfirmasi Setoran Pertama</a>
    <a href="input_setoran.php">Input Setoran Pengguna</a>
    <a href="manajemen_pengguna.php" class="active">Manajemen Pengguna</a>
  </div>

  <div class="main">
    <div class="container">
      <a href="manajemen_pengguna.php" class="btn btn-secondary btn-back">← Kembali</a>

      <div class="card">
        <div class="card-header text-white" style="background-color: #ffb347;">
          Detail Pengguna
        </div>
        <div class="card-body">
          <table class="table table-borderless">
            <tr>
              <th>NIK</th>
              <td>: <?= htmlspecialchars($data['nik']) ?></td>
            </tr>
            <tr>
              <th>Nama Lengkap</th>
              <td>: <?= htmlspecialchars($data['nama']) ?></td>
            </tr>
            <tr>
              <th>No. Rekening</th>
              <td>: <?= htmlspecialchars($data['no_rekening']) ?></td>
            </tr>
            <tr>
              <th>No. HP</th>
              <td>: <?= htmlspecialchars($data['no_hp']) ?></td>
            </tr>
            <tr>
              <th>Tanggal Lahir</th>
              <td>: <?= htmlspecialchars($data['tgl_lahir']) ?></td>
            </tr>
            <tr>
              <th>Agama</th>
              <td>: <?= htmlspecialchars($data['agama']) ?></td>
            </tr>
            <tr>
              <th>Alamat</th>
              <td>: <?= htmlspecialchars($data['alamat']) ?></td>
            </tr>
            <tr>
              <th>Jumlah Tabungan</th>
              <td>: Rp <?= number_format($data['setoran'], 0, ',', '.') ?></td>
            </tr>
            <tr>
              <th>Tanggal Pendaftaran</th>
              <td>: <?= htmlspecialchars($data['tgl_daftar']) ?></td>
            </tr>
          </table>
        </div>
      </div>
    </div>
  </div>

</body>


</html>

<?php
$conn->close();
?>