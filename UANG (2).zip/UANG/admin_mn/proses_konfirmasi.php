<?php
session_start();

// Koneksi ke database
$host = 'localhost';
$user = 'root';
$password = '';
$dbname = 'moneysave';

$conn = new mysqli($host, $user, $password, $dbname);

if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Ambil parameter dari URL
$nik = $_GET['nik'] ?? null;
$action = $_GET['action'] ?? null;

if ($nik && $action) {
    if ($action === 'approve') {
        // Update status konfirmasi menjadi approved
        $updateStatus = $conn->prepare("UPDATE daftar SET status_konfirmasi = 'approved' WHERE nik = ?");
        $updateStatus->bind_param("s", $nik);
        $updateStatus->execute();
        $updateStatus->close();

        // Update status di tabel waktu jika ada
        $updateWaktu = $conn->prepare("UPDATE waktu SET status = 'completed' WHERE nik = ?");
        $updateWaktu->bind_param("s", $nik);
        $updateWaktu->execute();
        $updateWaktu->close();

        $_SESSION['message'] = "Pendaftaran dikonfirmasi.";
    } elseif ($action === 'reject') {
        // Update status menjadi rejected
        $stmt = $conn->prepare("UPDATE daftar SET status_konfirmasi = 'rejected' WHERE nik = ?");
        $stmt->bind_param("s", $nik);
        $stmt->execute();
        $stmt->close();

        $_SESSION['message'] = "Pendaftaran rekening ditolak.";
    }

    header("Location: konfirmasi_setoran.php");
    exit();
}

$conn->close();
header("Location: konfirmasi_setoran.php");
exit();
