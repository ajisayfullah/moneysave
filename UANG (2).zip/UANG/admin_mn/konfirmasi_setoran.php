<?php
// Koneksi ke database
$host = 'localhost';
$user = 'root';
$password = '';
$dbname = 'moneysave';

$conn = new mysqli($host, $user, $password, $dbname);

if ($conn->connect_error) {
  die("Koneksi gagal: " . $conn->connect_error);
}

// Query untuk mendapatkan data pendaftaran rekening dari tabel daftar
$query = "SELECT * FROM daftar WHERE status_konfirmasi = 'pending'";
$result = $conn->query($query);

if ($result === false) {
  die("Error dalam query: " . $conn->error);
}
?>

<!DOCTYPE html>
<html lang="id">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Konfirmasi Setoran Pertama</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
  <style>
    /* Reset font dan background */
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background: #f5f7fa;
      margin: 0;
      display: flex;
      min-height: 100vh;
    }

    /* Sidebar modern */
    .sidebar {
      width: 220px;
      background: linear-gradient(135deg, #ff7e00, #ffb347);
      height: 100vh;
      position: fixed;
      padding-top: 2rem;
      box-shadow: 2px 0 10px rgb(0 0 0 / 0.1);
      display: flex;
      flex-direction: column;
      gap: 0.5rem;
    }

    .sidebar a {
      color: white;
      font-weight: 600;
      text-decoration: none;
      padding: 0.9rem 1.5rem;
      border-radius: 8px;
      transition: background-color 0.3s ease;
      font-size: 1rem;
      user-select: none;
    }

    .sidebar a:hover,
    .sidebar a.active {
      background-color: rgba(255, 255, 255, 0.3);
      box-shadow: 0 4px 8px rgb(255 126 0 / 0.5);
    }

    /* Konten utama */
    .main {
      margin-left: 220px;
      padding: 2rem 2.5rem;
      flex-grow: 1;
      min-height: 100vh;
    }

    /* Judul */
    h2 {
      font-weight: 700;
      color: #333;
      margin-bottom: 1.5rem;
      letter-spacing: 0.03em;
    }

    /* Card pembungkus tabel */
    .card {
      background: white;
      border-radius: 12px;
      padding: 1.5rem;
      box-shadow: 0 8px 20px rgb(0 0 0 / 0.08);
      border: none;
    }

    /* Tabel modern */
    table {
      width: 100%;
      border-collapse: separate;
      border-spacing: 0 8px;
    }

    thead th {
      background-color: #ffb347;
      color: #333;
      font-weight: 700;
      padding: 12px 15px;
      border-radius: 12px 12px 0 0;
      text-align: left;
      letter-spacing: 0.02em;
      user-select: none;
    }

    tbody tr {
      background-color: white;
      box-shadow: 0 3px 8px rgb(0 0 0 / 0.05);
      border-radius: 12px;
      transition: transform 0.15s ease, box-shadow 0.15s ease;
    }

    tbody tr:hover {
      transform: translateY(-3px);
      box-shadow: 0 8px 24px rgb(0 0 0 / 0.12);
    }

    tbody td {
      padding: 12px 15px;
      vertical-align: middle;
      border-bottom: none !important;
      color: #555;
      font-size: 0.95rem;
    }

    /* Tombol aksi */
    .btn-sm {
      font-size: 0.85rem;
      padding: 0.35rem 0.7rem;
      border-radius: 6px;
      font-weight: 600;
      transition: background-color 0.3s ease;
      user-select: none;
    }

    .btn-success {
      background-color: #198754;
      border: none;
      box-shadow: 0 3px 6px rgb(25 135 84 / 0.4);
    }

    .btn-success:hover {
      background-color: #157347;
      box-shadow: 0 4px 12px rgb(21 115 71 / 0.7);
    }

    .btn-danger {
      background-color: #dc3545;
      border: none;
      box-shadow: 0 3px 6px rgb(220 53 69 / 0.4);
    }

    .btn-danger:hover {
      background-color: #b02a37;
      box-shadow: 0 4px 12px rgb(176 42 55 / 0.7);
    }

    /* Responsif */
    @media (max-width: 768px) {
      body {
        flex-direction: column;
      }

      .sidebar {
        width: 100%;
        height: auto;
        position: relative;
        flex-direction: row;
        padding: 0.5rem 1rem;
        overflow-x: auto;
        gap: 1rem;
        box-shadow: none;
      }

      .sidebar a {
        padding: 0.6rem 1rem;
        font-size: 0.9rem;
        white-space: nowrap;
      }

      .main {
        margin-left: 0;
        padding: 1.5rem 1rem;
      }

      table thead th {
        font-size: 0.85rem;
        padding: 8px 10px;
      }

      tbody td {
        font-size: 0.85rem;
        padding: 8px 10px;
      }
    }

    /* Pesan error */
    .error-message {
      background: #f8d7da;
      color: #842029;
      border-radius: 8px;
      padding: 1rem;
      margin-bottom: 1.5rem;
      border: 1px solid #f5c2c7;
      font-weight: 600;
    }

    /* Jika tidak ada data */
    .text-center {
      color: #777;
      font-style: italic;
      font-weight: 600;
      padding: 1.5rem 0;
    }
  </style>
</head>

<body>
  <nav class="sidebar" aria-label="Sidebar menu">
    <a href="index.php" class="">Dashboard</a>
    <a href="konfirmasi_setoran.php" class="active">Konfirmasi Setoran Pertama</a>
    <a href="input_setoran.php">Input Setoran Pengguna</a>
    <a href="manajemen_pengguna.php">Manajemen Pengguna</a>
  </nav>

  <main class="main" role="main">
    <h2>Konfirmasi Setoran Pertama</h2>

    <div class="card">
      <div class="table-responsive">
        <table>
          <thead>
            <tr>
              <th>Nama</th>
              <th>NIK</th>
              <th>No. Rekening</th>
              <th>Jumlah Setoran</th>
              <th>Tanggal Pendaftaran</th>
              <th>Aksi</th>
            </tr>
          </thead>
          <tbody>
            <?php if ($result && $result->num_rows > 0): ?>
              <?php while ($row = $result->fetch_assoc()): ?>
                <tr>
                  <td><?= htmlspecialchars($row['nama'] ?? '') ?></td>
                  <td><?= htmlspecialchars($row['nik'] ?? '') ?></td>
                  <td><?= htmlspecialchars($row['no_rekening'] ?? '') ?></td>
                  <td>Rp <?= number_format((float)($row['setoran'] ?? 10000), 0, ',', '.') ?></td>
                  <td><?= date('d/m/Y', strtotime($row['tgl_daftar'] ?? 'now')) ?></td>
                  <td>
                    <a href="proses_konfirmasi.php?nik=<?= urlencode($row['nik'] ?? '') ?>&action=approve" class="btn btn-success btn-sm" role="button" aria-label="Konfirmasi Setoran">Konfirmasi</a>
                    <a href="proses_konfirmasi.php?nik=<?= urlencode($row['nik'] ?? '') ?>&action=reject" class="btn btn-danger btn-sm" role="button" aria-label="Tolak Setoran">Tolak</a>
                  </td>
                </tr>
              <?php endwhile; ?>
            <?php else: ?>
              <tr>
                <td colspan="6" class="text-center">Tidak ada data pendaftaran yang perlu dikonfirmasi</td>
              </tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </main>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>

<?php
$conn->close();
?>