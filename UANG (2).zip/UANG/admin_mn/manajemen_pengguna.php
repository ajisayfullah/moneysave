<?php
// Koneksi ke database
$host = "localhost";
$user = "root";
$pass = "";
$db = "moneysave";

$conn = new mysqli($host, $user, $pass, $db);

// Cek koneksi
if ($conn->connect_error) {
  die("Koneksi gagal: " . $conn->connect_error);
}

// Ambil data dari tabel daftar
$sql = "SELECT nama, nik, no_rekening, setoran FROM daftar";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="id">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Manajemen Pengguna</title>
  <link
    href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css"
    rel="stylesheet" />
  <link rel="stylesheet" href="view/css/bootstrap.min.css" />
  <script src="view/js/bootstrap.min.js"></script>
  <style>
    /* Reset font dan background */
    body {
      font-family: "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;
      background: #f5f7fa;
      margin: 0;
      display: flex;
      min-height: 100vh;
    }

    /* Sidebar modern */
    .sidebar {
      width: 220px;
      background: linear-gradient(135deg, #ff7e00, #ffb347);
      height: 100vh;
      position: fixed;
      padding-top: 2rem;
      box-shadow: 2px 0 10px rgb(0 0 0 / 0.1);
      display: flex;
      flex-direction: column;
      gap: 0.5rem;
    }

    .sidebar a {
      color: white;
      font-weight: 600;
      text-decoration: none;
      padding: 0.9rem 1.5rem;
      border-radius: 8px;
      transition: background-color 0.3s ease;
      font-size: 1rem;
      user-select: none;
    }

    .sidebar a:hover,
    .sidebar a.active {
      background-color: rgba(255, 255, 255, 0.3);
      box-shadow: 0 4px 8px rgb(255 126 0 / 0.5);
    }

    /* Konten utama */
    .main {
      margin-left: 220px;
      padding: 2rem 2.5rem;
      flex-grow: 1;
      min-height: 100vh;
    }

    table {
      width: 100%;
      border-collapse: separate;
      border-spacing: 0 8px;
    }

    thead th {
      background-color: #ffb347;
      color: #333;
      font-weight: 700;
      padding: 12px 15px;
      border-radius: 12px 12px 0 0;
      text-align: left;
      letter-spacing: 0.02em;
      user-select: none;
    }

    tbody tr {
      background-color: white;
      box-shadow: 0 3px 8px rgb(0 0 0 / 0.05);
      border-radius: 12px;
      transition: transform 0.15s ease, box-shadow 0.15s ease;
    }

    tbody tr:hover {
      transform: translateY(-3px);
      box-shadow: 0 8px 24px rgb(0 0 0 / 0.12);
    }

    tbody td {
      padding: 12px 15px;
      vertical-align: middle;
      border-bottom: none !important;
      color: #555;
      font-size: 0.95rem;
    }

    .card {
      background: white;
      border-radius: 12px;
      padding: 1.5rem;
      box-shadow: 0 8px 20px rgb(0 0 0 / 0.08);
      border: none;
    }

    @media (max-width: 768px) {
      body {
        flex-direction: column;
      }

      .sidebar {
        width: 100%;
        height: auto;
        position: relative;
        flex-direction: row;
        padding: 0.5rem 1rem;
        overflow-x: auto;
        gap: 1rem;
        box-shadow: none;
      }

      .sidebar a {
        padding: 0.6rem 1rem;
        font-size: 0.9rem;
        white-space: nowrap;
      }

      .main {
        margin-left: 0;
        padding: 1.5rem 1rem;
      }

      .table thead th {
        font-weight: 600;
        color: #333;
        border-bottom: 2px solid #dee2e6;
      }

      .table tbody tr:hover {
        background-color: rgba(0, 0, 0, 0.03);
        transition: background-color 0.3s ease;
      }

      .card {
        border-radius: 12px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
      }

      tbody td {
        font-size: 0.85rem;
        padding: 8px 10px;
      }
    }
  </style>
</head>

<body>
  <div class="sidebar">
    <a href="index.php">Dashboard</a>
    <a href="konfirmasi_setoran.php">Konfirmasi Setoran Pertama</a>
    <a href="input_setoran.php">Input Setoran Pengguna</a>
    <a href="manajemen_pengguna.php" class="active">Manajemen Pengguna</a>
  </div>
  <main class="main" role="main">
    <h2 class="mb-4">Manajemen Pengguna</h2>

    <!-- Pencarian -->
    <div class="container mt-5">
      <div class="row justify-content-center">
        <div class="col-md-6">
          <div class="input-group input-group-lg mb-3">
            <span class="input-group-text bg-transparent border-0">
            </span>
            <input type="text" class="form-control rounded-pill" placeholder="Cari nama atau nomor rekening..." aria-label="Search">
          </div>
        </div>
      </div>
    </div>

    <!-- Tabel Data Pengguna -->
    <div class="card">
      <div class="table-responsive">
        <table>
          <thead>
            <tr>
              <th>No</th>
              <th>Nama</th>
              <th>NIK</th>
              <th>No. Rekening</th>
              <th>Jumlah Tabungan</th>
              <th>Aksi</th>
            </tr>
          </thead>
          <tbody>
            <?php
            if ($result->num_rows > 0) {
              $no = 1; // Mulai dari 1
              while ($row = $result->fetch_assoc()) {
                echo "<tr>
              <td class='fw-bold'>{$no}</td>
              <td>{$row['nama']}</td>
              <td>{$row['nik']}</td>
              <td><span class='text-primary fw-bold'>{$row['no_rekening']}</span></td>
              <td>Rp " . number_format($row['setoran'], 0, ',', '.') . "</td>
              <td>
                <a href='detail_pengguna.php?nik={$row['nik']}' class='btn btn-sm btn-outline-primary rounded-pill px-3'>Detail</a>
              </td>
            </tr>";
                $no++;
              }
            } else {
              echo "<tr><td colspan='6'>Tidak ada data pengguna.</td></tr>";
            }
            ?>
          </tbody>

        </table>
      </div>
    </div>
  </main>
</body>

</html>

<?php $conn->close(); ?>