<!DOCTYPE html>
<html>
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta charset="utf-8" />
    <link rel="stylesheet" href="view/css/bootstrap.min.css" />
    <script src="view/js/bootstrap.min.js"></script>
  </head>
  <body>
    <style>
        @import url("https://cdnjs.cloudflare.com/ajax/libs/meyer-reset/2.0/reset.min.css");
        * {
          -webkit-font-smoothing: antialiased;
          box-sizing: border-box;
        }
        html,
        body {
          margin: 0px;
          height: 100%;
        }
        /* a blue color as a generic focus style */
        button:focus-visible {
          outline: 2px solid #4a90e2 !important;
          outline: -webkit-focus-ring-color auto 5px !important;
        }
        a {
          text-decoration: none;
        }
        .buat-akun-punya {
          background-color: #ffffff;
          display: flex;
          flex-direction: row;
          justify-content: center;
          width: 100%;
        }
        
        .buat-akun-punya .div {
          background-color: #ffffff;
          width: 360px;
          height: 800px;
          position: relative;
        }
        
        .buat-akun-punya .text-wrapper {
          position: absolute;
          top: 209px;
          left: 47px;
          font-family: "Alatsi-Regular", Helvetica;
          font-weight: 400;
          color: #e16417;
          font-size: 19px;
          letter-spacing: 0;
          line-height: normal;
        }
        
        .buat-akun-punya .silahkan-lakukan {
          position: absolute;
          top: 241px;
          left: 47px;
          font-family: "Alatsi-Regular", Helvetica;
          font-weight: 400;
          color: #095f7b;
          font-size: 11px;
          letter-spacing: 0;
          line-height: normal;
        }
        
        .buat-akun-punya .logo-nama-removebg {
          position: absolute;
          width: 150px;
          height: 100px;
          top: 32px;
          left: 105px;
          object-fit: cover;
        }
        
        .buat-akun-punya .overlap-group {
          position: absolute;
          width: 268px;
          height: 262px;
          top: 284px;
          left: 48px;
          background-color: #ffffff;
          border-radius: 5px;
          border: 1px solid;
          border-color: #e16417;
          box-shadow: 0px 0px 4px 2px #e1641740;
        }
        
        .buat-akun-punya .overlap {
          position: absolute;
          width: 25px;
          height: 25px;
          top: 24px;
          left: 17px;
          background-color: #095f7b1a;
          border-radius: 12.5px;
        }
        
        .buat-akun-punya .text-wrapper-2 {
          position: absolute;
          top: 3px;
          left: 10px;
          font-family: "Alatsi-Regular", Helvetica;
          font-weight: 400;
          color: #095f7b;
          font-size: 11px;
          letter-spacing: 0;
          line-height: normal;
        }
        
        .buat-akun-punya .div-wrapper {
          position: absolute;
          width: 25px;
          height: 25px;
          top: 80px;
          left: 17px;
          background-color: #095f7b1a;
          border-radius: 12.5px;
        }
        
        .buat-akun-punya .overlap-2 {
          position: absolute;
          width: 25px;
          height: 25px;
          top: 145px;
          left: 17px;
          background-color: #095f7b1a;
          border-radius: 12.5px;
        }
        
        .buat-akun-punya .overlap-3 {
          position: absolute;
          width: 25px;
          height: 25px;
          top: 203px;
          left: 17px;
          background-color: #095f7b1a;
          border-radius: 12.5px;
        }
        
        .buat-akun-punya .text-wrapper-3 {
          position: absolute;
          top: 22px;
          left: 46px;
          font-family: "Alatsi-Regular", Helvetica;
          font-weight: 400;
          color: #e16417;
          font-size: 10px;
          letter-spacing: 0;
          line-height: normal;
        }
        
        .buat-akun-punya .text-wrapper-4 {
          position: absolute;
          top: 73px;
          left: 46px;
          font-family: "Alatsi-Regular", Helvetica;
          font-weight: 400;
          color: #e16417;
          font-size: 10px;
          letter-spacing: 0;
          line-height: normal;
        }
        
        .buat-akun-punya .text-wrapper-5 {
          position: absolute;
          top: 137px;
          left: 46px;
          font-family: "Alatsi-Regular", Helvetica;
          font-weight: 400;
          color: #e16417;
          font-size: 10px;
          letter-spacing: 0;
          line-height: normal;
        }
        
        .buat-akun-punya .p {
          position: absolute;
          top: 201px;
          left: 46px;
          font-family: "Alatsi-Regular", Helvetica;
          font-weight: 400;
          color: #e16417;
          font-size: 10px;
          letter-spacing: 0;
          line-height: normal;
        }
        
        .buat-akun-punya .text-wrapper-6 {
          position: absolute;
          top: 35px;
          left: 46px;
          font-family: "Alatsi-Regular", Helvetica;
          font-weight: 400;
          color: #095f7b;
          font-size: 8px;
          letter-spacing: 0;
          line-height: normal;
        }
        
        .buat-akun-punya .nanti-kamu-bakalan {
          position: absolute;
          top: 86px;
          left: 46px;
          font-family: "Alatsi-Regular", Helvetica;
          font-weight: 400;
          color: #095f7b;
          font-size: 8px;
          letter-spacing: 0;
          line-height: normal;
        }
        
        .buat-akun-punya .nanti-kami-akan {
          position: absolute;
          top: 150px;
          left: 46px;
          font-family: "Alatsi-Regular", Helvetica;
          font-weight: 400;
          color: #095f7b;
          font-size: 8px;
          letter-spacing: 0;
          line-height: normal;
        }
        
        .buat-akun-punya .text-wrapper-7 {
          position: absolute;
          top: 214px;
          left: 46px;
          font-family: "Alatsi-Regular", Helvetica;
          font-weight: 400;
          color: #095f7b;
          font-size: 8px;
          letter-spacing: 0;
          line-height: normal;
        }
        
        .buat-akun-punya .line {
          top: 53px;
          position: absolute;
          width: 236px;
          height: 9px;
          left: 13px;
          object-fit: cover;
        }
        
        .buat-akun-punya .img {
          top: 117px;
          position: absolute;
          width: 236px;
          height: 9px;
          left: 13px;
          object-fit: cover;
        }
        
        .buat-akun-punya .line-2 {
          top: 181px;
          position: absolute;
          width: 236px;
          height: 9px;
          left: 13px;
          object-fit: cover;
        }
        
        .buat-akun-punya .line-3 {
          top: 232px;
          position: absolute;
          width: 236px;
          height: 9px;
          left: 13px;
          object-fit: cover;
        }
        
        .buat-akun-punya .overlap-4 {
          position: absolute;
          width: 266px;
          height: 40px;
          top: 726px;
          left: 47px;
          border-radius: 5px;
        }
        
        .buat-akun-punya .rectangle {
          position: absolute;
          width: 266px;
          height: 40px;
          top: 0;
          left: 0;
          background-color: #e16417;
          border-radius: 5px;
        }
        
        .buat-akun-punya .text-wrapper-8 {
          position: absolute;
          top: 8px;
          left: 84px;
          font-family: "Qualion-DemiBold", Helvetica;
          font-weight: 700;
          color: #ffffff;
          font-size: 13px;
          letter-spacing: 0;
          line-height: normal;
        }
        
        .buat-akun-punya .group {
          position: absolute;
          width: 264px;
          height: 45px;
          top: 673px;
          left: 49px;
        }
        
        .buat-akun-punya .OJK {
          position: absolute;
          width: 60px;
          height: 45px;
          top: 0;
          left: 0;
          object-fit: cover;
        }
        
        .buat-akun-punya .logo-lps {
          position: absolute;
          width: 60px;
          height: 36px;
          top: 7px;
          left: 102px;
          object-fit: cover;
        }
        
        .buat-akun-punya .logo-bun {
          position: absolute;
          width: 60px;
          height: 21px;
          top: 15px;
          left: 204px;
          object-fit: cover;
        }
        
        .buat-akun-punya .fi-rr-thumbs-up {
          position: absolute;
          width: 20px;
          height: 20px;
          top: 561px;
          left: 49px;
          object-fit: cover;
        }
        
        .buat-akun-punya .semua-proses {
          position: absolute;
          width: 242px;
          top: 561px;
          left: 73px;
          font-family: "ABeeZee-Regular", Helvetica;
          font-weight: 400;
          color: #095f7b;
          font-size: 6.5px;
          letter-spacing: 0;
          line-height: normal;
        }
        
        .buat-akun-punya .span {
          font-family: "ABeeZee-Regular", Helvetica;
          font-weight: 400;
          color: #095f7b;
          font-size: 6.5px;
          letter-spacing: 0;
        }
        
        .buat-akun-punya .text-wrapper-9 {
          text-decoration: underline;
        }
        .phone-frame {
  background-color: #dcdcdc;
  padding: 30px 12px;
  border-radius: 40px;
  box-shadow: 0 0 0 10px #888;
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 100vh;
}
    </style>
    <div class="phone-frame">
      <div class="phone-screen">
        <div class="landing-menu">
          <div class="div">
            <div class="buat-akun-punya">
              <div class="div">
                <div class="text-wrapper">Langkah Langkah Bikin Akun</div>
                <p class="silahkan-lakukan">
                  Silahkan lakukan pendaftaran akun dengan mengikuti<br />langkah-langkah dibawah ini ya!
                </p>
                <img class="logo-nama-removebg" src="img/money_save.png" />
                <div class="overlap-group">
                  <div class="overlap"><div class="text-wrapper-2">1</div></div>
                  <div class="div-wrapper"><div class="text-wrapper-2">2</div></div>
                  <div class="overlap-2"><div class="text-wrapper-2">3</div></div>
                  <div class="overlap-3"><div class="text-wrapper-2">4</div></div>
                  <div class="text-wrapper-3">Siapkan Dokumen</div>
                  <div class="text-wrapper-4">Pengisian Data</div>
                  <div class="text-wrapper-5">Verifikasi Data</div>
                  <p class="p">Buat Akun Money Save Mobile</p>
                  <p class="text-wrapper-6">Siapkan E-KTP dan Nomor Rekening Ya!</p>
                  <p class="nanti-kamu-bakalan">
                    Nanti kamu bakalan isi formulir&nbsp;&nbsp;pendaftaran,<br />pastikan semua data valid ya!
                  </p>
                  <p class="nanti-kami-akan">
                    Nanti kami akan verifikasi data yang kamu kirim,<br />tenang data kamu 100% aman kok
                  </p>
                  <div class="text-wrapper-7">Buat Username dan Password</div>
                  <img class="line" src="img/line-9.png" />
                  <img class="img" src="img/line-10.svg" />
                  <img class="line-2" src="img/line-11.svg" />
                  <img class="line-3" src="img/line-12.svg" />
                </div>
                  <div class="overlap-4" style="cursor: pointer;">
                    <div class="rectangle" onclick="redirectToSelesai()">
                      <div class="text-wrapper-8">Mulai Sekarang</div>
                    </div>
                  </div>
                <div class="group">
                  <img class="OJK" src="img/OJK-1.png" />
                  <img class="logo-lps" src="img/logo-lps-1.png" />
                  <img class="logo-bun" src="img/logo-bun-1.png" />
                </div>
                <img class="fi-rr-thumbs-up" src="img/fi-rr-thumbs-up-1.png" />
                  <p class="semua-proses">
                    <span class="span"
                      >Semua proses dilakukan dalam aplikasi Money Save MOBILE BANKING, seluruh data customer aman dan dilindungi
                        enkripsi end-to-end!&nbsp;&nbsp;<br
                      /></span>
                    <span class="text-wrapper-9">Pelajari Selengkapnya</span>
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <script>
      const urlParams = new URLSearchParams(window.location.search);
      const nik = urlParams.get('nik');

      function redirectToSelesai() {
        if (nik) {
          window.location.href = 'persiapan_dokumen.php?nik=' + encodeURIComponent(nik);
        } else {
          alert('NIK tidak ditemukan!');
          console.error('NIK parameter is missing');
        }
      }
    </script>
  </body>
</html>