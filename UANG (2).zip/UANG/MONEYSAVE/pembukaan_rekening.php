<!DOCTYPE html>
<html>
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta charset="utf-8" />
    <link rel="stylesheet" href="view/css/bootstrap.min.css" />
    <script src="view/js/bootstrap.min.js"></script>
  </head>
  <body>
    <style>
        @import url("https://cdnjs.cloudflare.com/ajax/libs/meyer-reset/2.0/reset.min.css");
    * {
      -webkit-font-smoothing: antialiased;
      box-sizing: border-box;
    }
    html,
    body {
      margin: 0px;
      height: 100%;
    }
    /* a blue color as a generic focus style */
    button:focus-visible {
      outline: 2px solid #4a90e2 !important;
      outline: -webkit-focus-ring-color auto 5px !important;
    }
    a {
      text-decoration: none;
    }

    .pembukaan-rekening {
      background-color: #ffffff;
      display: flex;
      flex-direction: row;
      justify-content: center;
      width: 100%;
    }

    .pembukaan-rekening .div {
      background-color: #ffffff;
      width: 360px;
      height: 800px;
      position: relative;
    }

    .pembukaan-rekening .women-holding-phone {
      position: absolute;
      width: 210px;
      height: 210px;
      top: 210px;
      left: 75px;
      object-fit: cover;
    }

    .pembukaan-rekening .text-wrapper {
      position: absolute;
      top: 443px;
      left: 47px;
      font-family: "Alatsi-Regular", Helvetica;
      font-weight: 400;
      color: #e16417;
      font-size: 20px;
      letter-spacing: 0;
      line-height: normal;
    }

    .pembukaan-rekening .buka-rekening-money {
      position: absolute;
      top: 475px;
      left: 47px;
      font-family: "ABeeZee-Regular", Helvetica;
      font-weight: 400;
      color: #095f7b;
      font-size: 11px;
      letter-spacing: 0;
      line-height: normal;
    }

    .pembukaan-rekening .overlap-group {
      position: absolute;
      width: 266px;
      height: 50px;
      top: 670px;
      left: 47px;
      border-radius: 5px;
    }

    .pembukaan-rekening .rectangle {
      position: absolute;
      width: 266px;
      height: 50px;
      top: 0;
      left: 0;
      background-color: #e16417;
      border-radius: 5px;
      border: 1px solid;
    }

    .pembukaan-rekening .text-wrapper-2 {
      position: absolute;
      top: 16px;
      left: 49px;
      font-family: "ABeeZee-Regular", Helvetica;
      font-weight: 400;
      color: #ffffff;
      font-size: 13px;
      letter-spacing: 0;
      line-height: normal;
      white-space: nowrap;
    }

    .pembukaan-rekening .group {
      position: absolute;
      width: 264px;
      height: 45px;
      top: 608px;
      left: 48px;
    }

    .pembukaan-rekening .OJK {
      position: absolute;
      width: 60px;
      height: 45px;
      top: 0;
      left: 0;
      object-fit: cover;
    }

    .pembukaan-rekening .logo-lps {
      position: absolute;
      width: 60px;
      height: 36px;
      top: 7px;
      left: 102px;
      object-fit: cover;
    }

    .pembukaan-rekening .logo-bun {
      position: absolute;
      width: 60px;
      height: 21px;
      top: 15px;
      left: 204px;
      object-fit: cover;
    }

    .pembukaan-rekening .logo-nama-removebg {
      position: absolute;
      width: 150px;
      height: 100px;
      top: 32px;
      left: 105px;
      object-fit: cover;
    }
    .phone-frame {
      background-color: #dcdcdc;
      padding: 30px 12px;
      border-radius: 40px;
      box-shadow: 0 0 0 10px #888;
      display: flex;
      justify-content: center;
      align-items: center;
      min-height: 100vh;
    }
    </style>
    <div class="phone-frame">
      <div class="phone-screen">
        <div class="landing-menu">
          <div class="div">
    <div class="pembukaan-rekening">
      <div class="div">
        <img class="women-holding-phone" src="img/pembukaan_rekening.png" />
        <div class="text-wrapper">Buka Rekening💰</div>
        <p class="buka-rekening-money">
          Buka rekening Money Save tanpa perlu ribet ke cabang,<br />cukup siapkan dokumen yang diperlukan📄
        </p>
        <a href="pendaftaran_rekening.php" class="text-decoration-none">
          <div class="overlap-group" style="cursor: pointer;">
            <div class="rectangle"></div>
            <div class="text-wrapper-2">Buka Rekening Money Save</div>
          </div>
        </a>
        <div class="group">
          <img class="OJK" src="img/OJK-1.png" />
          <img class="logo-lps" src="img/logo-lps-1.png" />
          <img class="logo-bun" src="img/logo-bun-1.png" />
        </div>
        <img class="logo-nama-removebg" src="img/money_save.png" />
      </div>
    </div>
          </div>
        </div>
      </div>
    </div>
  </body>
</html>
