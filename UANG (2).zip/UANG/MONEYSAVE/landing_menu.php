<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link rel="stylesheet" href="view/css/bootstrap.min.css" />
    <script src="view/js/bootstrap.min.js"></script>
    <style>
      @import url("https://cdnjs.cloudflare.com/ajax/libs/meyer-reset/2.0/reset.min.css");
      * {
        -webkit-font-smoothing: antialiased;
        box-sizing: border-box;
      }
      html,
      body {
        margin: 0px;
        height: 100%;
      }
      button:focus-visible {
        outline: 2px solid #4a90e2 !important;
        outline: -webkit-focus-ring-color auto 5px !important;
      }
      a {
        text-decoration: none;
      }

      .landing-menu {
        background-color: #ffffff;
        display: flex;
        flex-direction: row;
        justify-content: center;
        width: 100%;
      }

      .landing-menu .div {
        background-color: #ffffff;
        width: 360px;
        height: 800px;
        position: relative;
      }

      .landing-menu .women-holding-phone {
        position: absolute;
        width: 210px;
        height: 210px;
        top: 210px;
        left: 75px;
        object-fit: cover;
      }

      .landing-menu .text-wrapper {
        position: absolute;
        top: 443px;
        left: 47px;
        font-family: "Actor-Regular", Helvetica;
        font-weight: 400;
        color: #e16417;
        font-size: 20px;
        white-space: nowrap;
      }

      .landing-menu .wujudkan-semua {
        position: absolute;
        top: 475px;
        left: 47px;
        font-family: "ABeeZee-Regular", Helvetica;
        font-weight: 400;
        color: #095f7b;
        font-size: 11px;
      }

      .landing-menu .overlap,
      .landing-menu .overlap-group {
        position: absolute;
        width: 266px;
        height: 50px;
        left: 47px;
        border-radius: 5px;
      }

      .landing-menu .overlap {
        top: 547px;
      }

      .landing-menu .rectangle {
        background-color: #e16417;
        width: 266px;
        height: 50px;
        border-radius: 5px;
      }

      .landing-menu .text-wrapper-2 {
        position: absolute;
        top: 14px;
        left: 74px;
        font-family: "Qualion-DemiBold", Helvetica;
        font-weight: 700;
        color: #ffffff;
        font-size: 13px;
      }

      .landing-menu .overlap-group {
        top: 607px;
        cursor: pointer;
      }

      .landing-menu .rectangle-2 {
        border: 1px solid #e16417;
        width: 266px;
        height: 50px;
        border-radius: 5px;
      }

      .landing-menu .text-wrapper-3 {
        position: absolute;
        top: 14px;
        left: 73px;
        font-family: "Qualion-DemiBold", Helvetica;
        font-weight: 700;
        color: #e16417;
        font-size: 13px;
        text-align: center;
      }

      .landing-menu .logo-nama-removebg {
        position: absolute;
        width: 150px;
        height: 100px;
        top: 32px;
        left: 105px;
        object-fit: cover;
      }

      /* POPUP STYLING */
      .popup-overlay {
        display: none;
        position: fixed;
        top: 0;
        left: 0;
        width: 100vw;
        height: 100vh;
        background: rgba(0, 0, 0, 0.5);
        justify-content: center;
        align-items: center;
        z-index: 1000;
      }

      .popup {
        background-color: #ffffff;
        border: 1px solid #095f7b;
        width: 360px;
        height: 260px;
        position: relative;
        padding: 20px;
      }

      .popup .line {
        width: 124px;
        height: 4px;
        position: absolute;
        top: 9px;
        left: 118px;
      }

      .popup .apakah-kamu-memiliki {
        position: absolute;
        top: 43px;
        left: 28px;
        font-family: "ABeeZee-Regular", Helvetica;
        color: #095f7b;
        font-size: 18px;
      }

      .popup .jika-belum-memiliki {
        position: absolute;
        top: 101px;
        left: 28px;
        font-family: "ABeeZee-Regular", Helvetica;
        font-size: 8px;
        width: 288px;
        color: #095f7b;
      }

      .popup .span {
        text-decoration: underline;
      }

      .popup .overlap-group {
        position: absolute;
        width: 305px;
        height: 50px;
        top: 140px;
        left: 28px;
        border-radius: 5px;
        background-color: #095f7b;
      }

      .popup .p {
        color: #ffffff;
        font-family: "Qualion-DemiBold", Helvetica;
        font-size: 13px;
        font-weight: 700;
        text-align: center;
        padding-top: 14px;
      }

      .popup .text-wrapper-2 {
        position: absolute;
        top: 210px;
        left: 77px;
        font-family: "Alatsi-Regular", Helvetica;
        font-size: 13px;
        color: #095f7b;
      }

      .close-btn {
        position: absolute;
        top: 5px;
        right: 10px;
        cursor: pointer;
        font-size: 18px;
        color: #095f7b;
      }

      /* Phone Frame */
      .phone-frame {
        background-color: #dcdcdc;
        padding: 40px 20px;
        border-radius: 50px;
        box-shadow: 0 0 0 15px #888;
        display: flex;
        justify-content: center;
        align-items: center;
        min-height: 100vh;
      }
    </style>
  </head>
  <body>
    <div class="phone-frame">
      <div class="phone-screen">
        <div class="landing-menu">
          <div class="div">
            <img class="women-holding-phone" src="img/landing_menu.png" />
            <div class="text-wrapper">Money Save SuperApp</div>
            <p class="wujudkan-semua">
              Wujudkan semua keinginanmu #GakPakeNanti dan<br />nikmati segala
              kemudahan Money Save MOBILE BANKING
            </p>

            <a href="../MONEYSAVE3/smart_login.php" class="text-decoration-none">
              <div class="overlap">
                <div class="rectangle"></div>
                <div class="text-wrapper-2">Sudah Punya Akun</div>
              </div>
            </a>

            <div class="overlap-group" onclick="showPopup()">
              <div class="rectangle-2"></div>
              <div class="text-wrapper-3">Belum Punya Akun</div>
            </div>

            <img class="logo-nama-removebg" src="img/money_save.png" />
          </div>
        </div>
      </div>
    </div>

    <!-- POPUP -->
    <div class="popup-overlay" id="popup">
      <div class="popup">
        <div class="close-btn" onclick="hidePopup()">x</div>
        <img class="line" src="img/line-1.svg" />
        <p class="apakah-kamu-memiliki">
          Apakah Kamu Memiliki Rekening<br />Money Save Yang Sedang Aktif?
        </p>
        <p class="jika-belum-memiliki">
          Jika belum memiliki rekening Money Save aktif kamu bisa buka rekening
          via aplikasi lho! klik
          <span class="span">Belum punya Rekening.</span> 100% Gratis dan tanpa
          ribet
        </p>
        <div
          class="overlap-group d-flex justify-content-center align-items-center"
          style="height: 50px; background-color: #095f7b; border-radius: 8px"
        >
          <a
            href="../MONEYSAVE2/buat_akun.php"
            class="text-white fw-bold text-decoration-none"
            >Saya Punya Rekening BNI Aktif</a
          >
        </div>
        <a href="pembukaan_rekening.php" class="text-wrapper-2"
          >Belum, Saya Ingin Buka Rekening</a
        >
      </div>
    </div>

    <script>
      function showPopup() {
        document.getElementById("popup").style.display = "flex";
      }

      function hidePopup() {
        document.getElementById("popup").style.display = "none";
      }
    </script>
  </body>
</html>
