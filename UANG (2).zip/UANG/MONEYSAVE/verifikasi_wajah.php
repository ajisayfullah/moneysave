<!DOCTYPE html>
<html>
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta charset="utf-8" />
    <link rel="stylesheet" href="view/css/bootstrap.min.css" />
    <script src="view/js/bootstrap.min.js"></script>
  </head>
  <body>
    <style>
      @import url("https://cdnjs.cloudflare.com/ajax/libs/meyer-reset/2.0/reset.min.css");
      * {
        -webkit-font-smoothing: antialiased;
        box-sizing: border-box;
      }
      html,
      body {
        margin: 0px;
        height: 100%;
      }
      /* a blue color as a generic focus style */
      button:focus-visible {
        outline: 2px solid #4a90e2 !important;
        outline: -webkit-focus-ring-color auto 5px !important;
      }
      a {
        text-decoration: none;
      }
      .verifikasi-wajah {
        background-color: #ffffff;
        display: flex;
        flex-direction: row;
        justify-content: center;
        width: 100%;
      }

      .verifikasi-wajah .div {
        background-color: #ffffff;
        width: 360px;
        height: 800px;
        position: relative;
      }

      .verifikasi-wajah .text-wrapper {
        position: absolute;
        top: 209px;
        left: 47px;
        font-family: "Alatsi-Regular", Helvetica;
        font-weight: 400;
        color: #e16417;
        font-size: 19px;
        letter-spacing: 0;
        line-height: normal;
      }

      .verifikasi-wajah .text-wrapper-2 {
        position: absolute;
        top: 434px;
        left: 47px;
        font-family: "Qualion-DemiBold", Helvetica;
        font-weight: 700;
        color: #095f7b;
        font-size: 16px;
        letter-spacing: 0;
        line-height: normal;
      }

      .verifikasi-wajah .ambil-gambar-selfie {
        position: absolute;
        top: 241px;
        left: 47px;
        font-family: "Alatsi-Regular", Helvetica;
        font-weight: 400;
        color: #095f7b;
        font-size: 11px;
        letter-spacing: 0;
        line-height: normal;
      }

      .verifikasi-wajah .logo-nama-removebg {
        position: absolute;
        width: 150px;
        height: 100px;
        top: 32px;
        left: 105px;
        object-fit: cover;
      }

      .verifikasi-wajah .overlap-group {
        position: absolute;
        width: 266px;
        height: 40px;
        top: 726px;
        left: 47px;
        border-radius: 5px;
      }

      .verifikasi-wajah .rectangle {
        position: absolute;
        width: 266px;
        height: 40px;
        top: 0;
        left: 0;
        background-color: #e16417;
        border-radius: 5px;
      }

      .verifikasi-wajah .text-wrapper-3 {
        position: absolute;
        top: 10px;
        left: 97px;
        font-family: "Qualion-DemiBold", Helvetica;
        font-weight: 700;
        color: #ffffff;
        font-size: 13px;
        letter-spacing: 0;
        line-height: normal;
      }

      .verifikasi-wajah .group {
        position: absolute;
        width: 264px;
        height: 45px;
        top: 673px;
        left: 49px;
      }

      .verifikasi-wajah .OJK {
        position: absolute;
        width: 60px;
        height: 45px;
        top: 0;
        left: 0;
        object-fit: cover;
      }

      .verifikasi-wajah .logo-lps {
        position: absolute;
        width: 60px;
        height: 36px;
        top: 7px;
        left: 102px;
        object-fit: cover;
      }

      .verifikasi-wajah .logo-bun {
        position: absolute;
        width: 60px;
        height: 21px;
        top: 15px;
        left: 204px;
        object-fit: cover;
      }

      .verifikasi-wajah .smartselect {
        position: absolute;
        width: 262px;
        height: 82px;
        top: 294px;
        left: 49px;
        object-fit: cover;
      }

      .verifikasi-wajah .overlap {
        position: absolute;
        width: 68px;
        height: 20px;
        top: 391px;
        left: 75px;
        background-color: #e16417;
        border-radius: 61px;
      }

      .verifikasi-wajah .text-wrapper-4 {
        position: absolute;
        top: 4px;
        left: 20px;
        font-family: "Alatsi-Regular", Helvetica;
        font-weight: 400;
        color: #ffffff;
        font-size: 10px;
        letter-spacing: 0;
        line-height: normal;
      }

      .verifikasi-wajah .div-wrapper {
        position: absolute;
        width: 68px;
        height: 20px;
        top: 391px;
        left: 218px;
        background-color: #095f7b;
        border-radius: 61px;
      }

      .verifikasi-wajah .foto-harus-diambil {
        position: absolute;
        width: 265px;
        top: 467px;
        left: 48px;
        font-family: "Alatsi-Regular", Helvetica;
        font-weight: 400;
        color: #252525;
        font-size: 10px;
        letter-spacing: 0;
        line-height: normal;
      }
      .phone-frame {
        background-color: #dcdcdc;
        padding: 30px 12px;
        border-radius: 40px;
        box-shadow: 0 0 0 10px #888;
        display: flex;
        justify-content: center;
        align-items: center;
        min-height: 100vh;
      }
    </style>
    <div class="phone-frame">
      <div class="phone-screen">
        <div class="landing-menu">
          <div class="div">
            <div class="verifikasi-wajah">
              <div class="div">
                <div class="text-wrapper">Verifikasi Wajah Yuk</div>
                <div class="text-wrapper-2">Perhatikan Ketentuannya ya!</div>
                <p class="ambil-gambar-selfie">
                  Ambil gambar selfie anda menghadap kamera, <br />ikuti
                  petunjuk dibawah ya!
                </p>
                <img class="logo-nama-removebg" src="img/money_save.png" />
                <div class="overlap-group" onclick="redirectToSelesai()">
                  <div class="rectangle"></div>
                  <div class="text-wrapper-3" style="color: white; cursor: pointer;">
                    Ambil Foto
                  </div>
                </div>
                <div class="group">
                  <img class="OJK" src="img/OJK-1.png" />
                  <img class="logo-lps" src="img/logo-lps-1.png" />
                  <img class="logo-bun" src="img/logo-bun-1.png" />
                </div>
                <img class="smartselect" src="img/foto_wajah.png" />
                <div class="overlap">
                  <div class="text-wrapper-4">Benar</div>
                </div>
                <div class="div-wrapper">
                  <div class="text-wrapper-4">Salah</div>
                </div>
                <p class="foto-harus-diambil">
                  Foto harus diambil secara langsung, bukan dari gambar atau
                  lainnya<br />Pastikan wajah menghadap tegak ke kamera dan foto
                  tidak buram<br />Posisikan wajah kedalam frame supaya dapat
                  terbaca otomatis<br />Carilah ruang dengan pencahayaan yang
                  baik dan terang, kualitas gambar mempengaruhi proses
                  verifikasi kamu ya!
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <script>
      const urlParams = new URLSearchParams(window.location.search);
      const nik = urlParams.get("nik");

      function redirectToSelesai() {
        if (nik) {
          window.location.href =
            "kamera_wajah.php?nik=" + encodeURIComponent(nik);
        } else {
          alert("NIK tidak ditemukan!");
          console.error("NIK parameter is missing");
        }
      }
    </script>
  </body>
</html>
