<?php
header('Content-Type: application/json');

// Database configuration
$host = 'localhost';
$user = 'root';
$password = '';
$dbname = 'moneysave';

// Create connection
$conn = new mysqli($host, $user, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die(json_encode(['success' => false, 'message' => 'Koneksi database gagal']));
}

// Get NIK from POST data
$nik = $_POST['nik'] ?? null;
if (!$nik) {
    echo json_encode(['success' => false, 'message' => 'NIK tidak valid']);
    exit;
}

// File upload handling
$uploadDir = 'uploads/ktp/';
if (!file_exists($uploadDir)) {
    mkdir($uploadDir, 0777, true);
}

$fileName = 'ktp_' . $nik . '_' . time() . '.png';
$filePath = $uploadDir . $fileName;

// Move uploaded file
if (move_uploaded_file($_FILES['kartu']['tmp_name'], $filePath)) {
    // Insert into database
    $stmt = $conn->prepare("INSERT INTO foto (nik, kartu, status) VALUES (?, ?, 'pending')");
    $stmt->bind_param("ss", $nik, $filePath);

    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'message' => 'Foto KTP berhasil disimpan']);
    } else {
        // Delete the uploaded file if DB insert fails
        unlink($filePath);
        echo json_encode(['success' => false, 'message' => 'Gagal menyimpan ke database']);
    }
    $stmt->close();
} else {
    echo json_encode(['success' => false, 'message' => 'Gagal mengunggah file']);
}

$conn->close();
