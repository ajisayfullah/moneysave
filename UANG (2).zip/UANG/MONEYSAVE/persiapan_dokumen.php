<!DOCTYPE html>
<html>
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta charset="utf-8" />
    <link rel="stylesheet" href="view/css/bootstrap.min.css" />
    <script src="view/js/bootstrap.min.js"></script>
  </head>
  <body>
    <style>
      @import url("https://cdnjs.cloudflare.com/ajax/libs/meyer-reset/2.0/reset.min.css");
      * {
        -webkit-font-smoothing: antialiased;
        box-sizing: border-box;
      }
      html,
      body {
        margin: 0px;
        height: 100%;
      }
      /* a blue color as a generic focus style */
      button:focus-visible {
        outline: 2px solid #4a90e2 !important;
        outline: -webkit-focus-ring-color auto 5px !important;
      }
      a {
        text-decoration: none;
      }

      .upload-dokumen {
        background-color: #ffffff;
        display: flex;
        flex-direction: row;
        justify-content: center;
        width: 100%;
      }

      .upload-dokumen .div {
        background-color: #ffffff;
        width: 360px;
        height: 800px;
        position: relative;
      }

      .upload-dokumen .women-holding-phone {
        position: absolute;
        width: 210px;
        height: 210px;
        top: 210px;
        left: 75px;
        object-fit: cover;
      }

      .upload-dokumen .text-wrapper {
        position: absolute;
        top: 443px;
        left: 47px;
        font-family: "Alatsi-Regular", Helvetica;
        font-weight: 400;
        color: #e16417;
        font-size: 20px;
        letter-spacing: 0;
        line-height: normal;
      }

      .upload-dokumen .siapkan-dokumen-yang {
        position: absolute;
        top: 475px;
        left: 47px;
        font-family: "Alatsi-Regular", Helvetica;
        font-weight: 400;
        color: #095f7b;
        font-size: 11px;
        letter-spacing: 0;
        line-height: normal;
      }

      .upload-dokumen .logo-nama-removebg {
        position: absolute;
        width: 150px;
        height: 100px;
        top: 32px;
        left: 105px;
        object-fit: cover;
      }

      .upload-dokumen .dokumen-upload {
        top: 530px;
        position: absolute;
        width: 20px;
        height: 20px;
        left: 75px;
        object-fit: cover;
      }

      .upload-dokumen .text-wrapper-2 {
        position: absolute;
        top: 531px;
        left: 106px;
        font-family: "Alatsi-Regular", Helvetica;
        font-weight: 400;
        color: #095f7b;
        font-size: 11px;
        letter-spacing: 0;
        line-height: normal;
      }

      .upload-dokumen .img {
        top: 580px;
        position: absolute;
        width: 20px;
        height: 20px;
        left: 75px;
        object-fit: cover;
      }

      .upload-dokumen .text-wrapper-3 {
        position: absolute;
        top: 581px;
        left: 106px;
        font-family: "Alatsi-Regular", Helvetica;
        font-weight: 400;
        color: #095f7b;
        font-size: 11px;
        letter-spacing: 0;
        line-height: normal;
      }

      .upload-dokumen .dokumen-upload-2 {
        top: 630px;
        position: absolute;
        width: 20px;
        height: 20px;
        left: 75px;
        object-fit: cover;
      }

      .upload-dokumen .text-wrapper-4 {
        position: absolute;
        top: 631px;
        left: 106px;
        font-family: "Alatsi-Regular", Helvetica;
        font-weight: 400;
        color: #095f7b;
        font-size: 11px;
        letter-spacing: 0;
        line-height: normal;
      }

      .upload-dokumen .overlap-group {
        position: absolute;
        width: 266px;
        height: 40px;
        top: 726px;
        left: 46px;
        border-radius: 5px;
      }

      .upload-dokumen .rectangle {
        position: absolute;
        width: 266px;
        height: 40px;
        top: 0;
        left: 0;
        background-color: #e16417;
        border-radius: 5px;
      }

      .upload-dokumen .text-wrapper-5 {
        position: absolute;
        top: 9px;
        left: 87px;
        font-family: "Qualion-DemiBold", Helvetica;
        font-weight: 700;
        color: #ffffff;
        font-size: 13px;
        letter-spacing: 0;
        line-height: normal;
      }

      .upload-dokumen .group {
        position: absolute;
        width: 264px;
        height: 45px;
        top: 673px;
        left: 47px;
      }

      .upload-dokumen .OJK {
        position: absolute;
        width: 60px;
        height: 45px;
        top: 0;
        left: 0;
        object-fit: cover;
      }

      .upload-dokumen .logo-lps {
        position: absolute;
        width: 60px;
        height: 36px;
        top: 7px;
        left: 102px;
        object-fit: cover;
      }

      .upload-dokumen .logo-bun {
        position: absolute;
        width: 60px;
        height: 21px;
        top: 15px;
        left: 204px;
        object-fit: cover;
      }

      .upload-dokumen .vector {
        top: 566px;
        position: absolute;
        width: 265px;
        height: 1px;
        left: 50px;
        object-fit: cover;
      }

      .upload-dokumen .vector-2 {
        top: 616px;
        position: absolute;
        width: 265px;
        height: 1px;
        left: 50px;
        object-fit: cover;
      }
      .phone-frame {
        background-color: #dcdcdc;
        padding: 30px 12px;
        border-radius: 40px;
        box-shadow: 0 0 0 10px #888;
        display: flex;
        justify-content: center;
        align-items: center;
        min-height: 100vh;
      }
    </style>
    <div class="phone-frame">
      <div class="phone-screen">
        <div class="landing-menu">
          <div class="div">
            <div class="upload-dokumen">
              <div class="div">
                <img
                  class="women-holding-phone"
                  src="img/persiapan_dokumen.png"
                />
                <div class="text-wrapper">Siapkan Dokumen</div>
                <p class="siapkan-dokumen-yang">
                  Siapkan dokumen yang diperlukan dibawah ya!<br />pastikan
                  dokumen asli dan berlaku
                </p>
                <img class="logo-nama-removebg" src="img/money_save.png" />
                <img class="dokumen-upload" src="img/dokumen.png" />
                <div class="text-wrapper-2">KTP Elektronik</div>
                <img class="img" src="img/dokumen.png" />
                <div class="text-wrapper-3">Kartu Keluarga</div>
                <img class="dokumen-upload-2" src="img/dokumen.png" />
                <div class="text-wrapper-4">NPWP (opsional)</div>
                  <div class="overlap-group" style="cursor: pointer">
                    <div class="rectangle" onclick="redirectToSelesai()">
                      <div class="text-wrapper-5">Lanjut Isi Data</div>
                    </div>
                  </div>
                <div class="group">
                  <img class="OJK" src="img/OJK-1.png" />
                  <img class="logo-lps" src="img/logo-lps-1.png" />
                  <img class="logo-bun" src="img/logo-bun-1.png" />
                </div>
                <img class="vector" src="img/vector-9.png" />
                <img class="vector-2" src="img/vector-9.png" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <script>
      const urlParams = new URLSearchParams(window.location.search);
      const nik = urlParams.get("nik");

      function redirectToSelesai() {
        if (nik) {
          window.location.href =
            "foto_ktp.php?nik=" + encodeURIComponent(nik);
        } else {
          alert("NIK tidak ditemukan!");
          console.error("NIK parameter is missing");
        }
      }
    </script>
  </body>
</html>
