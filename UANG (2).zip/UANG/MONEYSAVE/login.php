<!DOCTYPE html>
<html>
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta charset="utf-8" />
    <link rel="stylesheet" href="view/css/bootstrap.min.css" />
    <script src="view/js/bootstrap.min.js"></script>
  </head>
  <body>
    <style>
      @import url("https://cdnjs.cloudflare.com/ajax/libs/meyer-reset/2.0/reset.min.css");
      * {
        -webkit-font-smoothing: antialiased;
        box-sizing: border-box;
      }
      html,
      body {
        margin: 0px;
        height: 100%;
      }
      /* a blue color as a generic focus style */
      button:focus-visible {
        outline: 2px solid #4a90e2 !important;
        outline: -webkit-focus-ring-color auto 5px !important;
      }
      a {
        text-decoration: none;
      }
      .login-page {
        background-color: #ffffff;
        display: flex;
        flex-direction: row;
        justify-content: center;
        width: 100%;
      }

      .login-page .div {
        background-color: #ffffff;
        width: 360px;
        height: 800px;
        position: relative;
      }

      .login-page .women-holding-phone {
        position: absolute;
        width: 210px;
        height: 210px;
        top: 210px;
        left: 75px;
        object-fit: cover;
      }

      .login-page .text-wrapper {
        position: absolute;
        top: 443px;
        left: 47px;
        font-family: "ABeeZee-Italic", Helvetica;
        font-weight: 400;
        font-style: italic;
        color: #e16417;
        font-size: 20px;
        letter-spacing: 0;
        line-height: normal;
        white-space: nowrap;
      }

      .login-page .sekarang-kamu-udah {
        position: absolute;
        top: 475px;
        left: 47px;
        font-family: "Alatsi-Regular", Helvetica;
        font-weight: 400;
        color: #095f7b;
        font-size: 11px;
        letter-spacing: 0;
        line-height: normal;
      }

      .login-page .logo-nama-removebg {
        position: absolute;
        width: 150px;
        height: 100px;
        top: 32px;
        left: 105px;
        object-fit: cover;
      }

      .login-page .text-wrapper-2 {
        position: absolute;
        top: 519px;
        left: 49px;
        font-family: "ABeeZee-Regular", Helvetica;
        font-weight: 400;
        color: #095f7b;
        font-size: 15px;
        letter-spacing: 0;
        line-height: normal;
        white-space: nowrap;
      }

      .login-page .text-wrapper-3 {
        position: absolute;
        top: 589px;
        left: 49px;
        font-family: "ABeeZee-Regular", Helvetica;
        font-weight: 400;
        color: #095f7b;
        font-size: 15px;
        letter-spacing: 0;
        line-height: normal;
        white-space: nowrap;
      }

      .login-page .overlap-group {
        position: absolute;
        width: 268px;
        height: 42px;
        top: 543px;
        left: 48px;
        background-color: #ffffff;
        border-radius: 5px;
        border: 1px solid;
        border-color: #095f7b;
      }

      .login-page .text-wrapper-4 {
        position: absolute;
        top: 11px;
        left: 28px;
        font-family: "ABeeZee-Regular", Helvetica;
        font-weight: 400;
        color: #777777;
        font-size: 10px;
        letter-spacing: 0;
        line-height: normal;
        white-space: nowrap;
      }

      .login-page .overlap {
        position: absolute;
        width: 268px;
        height: 42px;
        top: 613px;
        left: 48px;
        background-color: #ffffff;
        border-radius: 5px;
        border: 1px solid;
        border-color: #095f7b;
      }

      .login-page .overlap-2 {
        position: absolute;
        width: 266px;
        height: 57px;
        top: 726px;
        left: 47px;
      }

      .login-page .text-wrapper-5 {
        position: absolute;
        top: 36px;
        left: 87px;
        font-family: "Qualion-DemiBold", Helvetica;
        font-weight: 700;
        color: #ffffff;
        font-size: 13px;
        letter-spacing: 0;
        line-height: normal;
      }

      .login-page .rectangle {
        position: absolute;
        width: 266px;
        height: 40px;
        top: 0;
        left: 0;
        background-color: #e16417;
        border-radius: 5px;
      }

      .login-page .text-wrapper-6 {
        position: absolute;
        top: 8px;
        left: 116px;
        font-family: "Qualion-DemiBold", Helvetica;
        font-weight: 700;
        color: #ffffff;
        font-size: 13px;
        letter-spacing: 0;
        line-height: normal;
      }

      .login-page .group {
        position: absolute;
        width: 264px;
        height: 45px;
        top: 673px;
        left: 49px;
      }

      .login-page .OJK {
        position: absolute;
        width: 60px;
        height: 45px;
        top: 0;
        left: 0;
        object-fit: cover;
      }

      .login-page .logo-lps {
        position: absolute;
        width: 60px;
        height: 36px;
        top: 7px;
        left: 102px;
        object-fit: cover;
      }

      .login-page .logo-bun {
        position: absolute;
        width: 60px;
        height: 21px;
        top: 15px;
        left: 204px;
        object-fit: cover;
      }
      .phone-frame {
        background-color: #dcdcdc;
        padding: 30px 12px;
        border-radius: 40px;
        box-shadow: 0 0 0 10px #888;
        display: flex;
        justify-content: center;
        align-items: center;
        min-height: 100vh;
      }
    </style>
    <div class="phone-frame">
      <div class="phone-screen">
        <div class="landing-menu">
          <div class="div">
            <div class="login-page">
              <div class="div">
                <img class="women-holding-phone" src="img/login.png" />
                <div class="text-wrapper">Sign-Up Money Save MOBILE</div>
                <p class="sekarang-kamu-udah">
                  Sekarang kamu udah bisa nikmatin semua fiturnya,<br />aktifkan
                  smart login di settings ya🔔
                </p>
                <img class="logo-nama-removebg" src="img/money_save.png" />
                <form action="set_password.php" method="post">
                  <div class="text-wrapper-2">Email</div>
                    <div class="overlap-group">
                      <input
                        type="email"
                        name="email"
                        id="email"
                        style="
                          width: 100%;
                          padding: 8px;
                          font-size: 16px;
                          border: 1px solid #ccc;
                          border-radius: 5px;
                          box-sizing: border-box;
                          outline: none;
                          box-shadow: none;
                        "
                        onfocus="this.style.outline='none'; this.style.boxShadow='none';"
                        onblur="this.style.outline=''; this.style.boxShadow='';"
                      />
                    </div>
                    <div class="text-wrapper-3">Password</div>
                    <div class="overlap">
                      <input
                        type="password"
                        name="password"
                        id="password"
                        style="
                          width: 100%;
                          padding: 8px;
                          font-size: 16px;
                          border: 1px solid #ccc;
                          border-radius: 5px;
                          box-sizing: border-box;
                          outline: none;
                          box-shadow: none;
                        "
                        onfocus="this.style.outline='none'; this.style.boxShadow='none';"
                        onblur="this.style.outline=''; this.style.boxShadow='';"
                      />
                    </div>
                    <div class="overlap-2" style="cursor: pointer">
                      <button type="submit" class="rectangle" style="border: none;  background-color: #e16417; border-radius: 5px; color: white; font-weight: bold; font-size: 13px;">
                        Sign-Up
                      </button>
                    </div>


                    <div class="group">
                      <img class="OJK" src="img/OJK-1.png" />
                      <img class="logo-lps" src="img/logo-lps-1.png" />
                      <img class="logo-bun" src="img/logo-bun-1.png" />
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </body>
</html>
