<?php
$host = "localhost";
$user = "root";
$pass = "";
$db   = "moneysave";

// Koneksi
$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

$email = $_POST['email'];
$password = $_POST['password'];

$sql = "SELECT * FROM daftar WHERE email = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $data = $result->fetch_assoc();
    $nik = $data['nik'];

    // Tanpa hash, langsung simpan password
    $update = "UPDATE daftar SET password = ? WHERE email = ?";
    $stmt2 = $conn->prepare($update);
    $stmt2->bind_param("ss", $password, $email);

    if ($stmt2->execute()) {
        $encodedNik = urlencode($nik);
        echo "<script>
            alert('Password berhasil disimpan!');
            window.location.href = 'beranda.php?nik={$encodedNik}';
        </script>";
    } else {
        echo "<script>alert('Gagal menyimpan password.'); history.back();</script>";
    }
} else {
    echo "<script>alert('Email tidak ditemukan!'); history.back();</script>";
}

$conn->close();
