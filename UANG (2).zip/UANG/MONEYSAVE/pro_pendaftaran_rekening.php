<?php
// Koneksi ke database
$host = "localhost";
$user = "root";
$pass = "";
$db = "moneysave";

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}
date_default_timezone_set("Asia/Jakarta");

// Fungsi generate nomor rekening acak 9 digit
function generateNoRekening()
{
    return str_pad(mt_rand(0, 999999999), 9, '0', STR_PAD_LEFT);
}

// Ambil data dari form
$nik = $_POST['nik'];
$nama = $_POST['nama_ktp'];
$ttl = $_POST['tempat_tanggal_lahir'];
$agama = $_POST['agama'];
$alamat = $_POST['alamat_lengkap'];

// Generate nomor rekening unik
$no_rekening = generateNoRekening();

// Pastikan nomor rekening unik
$cekUnik = $conn->prepare("SELECT no_rekening FROM daftar WHERE no_rekening = ?");
$cekUnik->bind_param("s", $no_rekening);
$cekUnik->execute();
$cekUnik->store_result();

// Jika nomor rekening sudah ada, generate ulang
while ($cekUnik->num_rows > 0) {
    $no_rekening = generateNoRekening();
    $cekUnik->execute();
    $cekUnik->store_result();
}
$cekUnik->close();

// Cek apakah NIK sudah ada
$cekNik = $conn->prepare("SELECT nik FROM daftar WHERE nik = ?");
$cekNik->bind_param("s", $nik);
$cekNik->execute();
$cekNik->store_result();

if ($cekNik->num_rows > 0) {
    die("NIK sudah terdaftar, silakan gunakan NIK lain.");
} else {
    // Hapus tujuan_pembukaan jika tidak ada di tabel
    $stmt = $conn->prepare("INSERT INTO daftar 
        (nik, nama, tgl_lahir, agama, alamat, no_rekening, status_konfirmasi) 
        VALUES (?, ?, ?, ?, ?, ?, 'pending')");
    $stmt->bind_param("ssssss", $nik, $nama, $ttl, $agama, $alamat, $no_rekening);

    if ($stmt->execute()) {
        // Jika berhasil, tambahkan ke tabel waktu
        $created_at = date('Y-m-d H:i:s');
        $dt = new DateTime($created_at);
        $dt->modify('+24 hours');
        $timer_end = $dt->format('Y-m-d H:i:s');

        $stmt2 = $conn->prepare("INSERT INTO waktu (nik, timer_end, created_at) VALUES (?, ?, ?)");
        $stmt2->bind_param("sss", $nik, $timer_end, $created_at);

        if ($stmt2->execute()) {
            header("Location: setoran_pertama.php?nik=" . urlencode($nik));
            exit();
        } else {
            die("Gagal menyimpan ke tabel waktu: " . $stmt2->error);
        }
        $stmt2->close();
    } else {
        die("Error saat menyimpan data: " . $stmt->error);
    }
    $stmt->close();
}

$cekNik->close();
$conn->close();
