<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../MONEY_SAVE/config/koneksi.php';

$nik = $_GET['nik'] ?? '';
if (!$nik) {
    echo json_encode(['success' => false, 'message' => 'NIK tidak ditemukan']);
    exit;
}

$stmt = $koneksi->prepare("SELECT timer_end FROM waktu WHERE nik = ?");
$stmt->bind_param("s", $nik);
$stmt->execute();
$stmt->bind_result($timer_end);
if ($stmt->fetch()) {
    echo json_encode(['success' => true, 'timer_end' => $timer_end]);
} else {
    echo json_encode(['success' => false, 'message' => 'Timer tidak ditemukan']);
}
$stmt->close();
?>
