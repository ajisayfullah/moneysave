<!DOCTYPE html>
<html>

<head>
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <meta charset="utf-8" />
  <link rel="stylesheet" href="view/css/bootstrap.min.css" />
  <script src="view/js/bootstrap.min.js"></script>
  <style>
    @import url("https://cdnjs.cloudflare.com/ajax/libs/meyer-reset/2.0/reset.min.css");

    * {
      -webkit-font-smoothing: antialiased;
      box-sizing: border-box;
    }

    html,
    body {
      margin: 0px;
      height: 100%;
    }

    /* a blue color as a generic focus style */
    button:focus-visible {
      outline: 2px solid #4a90e2 !important;
      outline: -webkit-focus-ring-color auto 5px !important;
    }

    a {
      text-decoration: none;
    }

    .phone-frame {
      background-color: #dcdcdc;
      padding: 30px 12px;
      border-radius: 40px;
      box-shadow: 0 0 0 10px #888;
      display: flex;
      justify-content: center;
      align-items: center;
      min-height: 100vh;
    }

    .setoran-selesai {
      background-color: #ffffff;
      display: flex;
      flex-direction: row;
      justify-content: center;
      width: 100%;
    }

    .setoran-selesai .div {
      background-color: #ffffff;
      width: 360px;
      height: 800px;
      position: relative;
    }

    .setoran-selesai .women-holding-phone {
      position: absolute;
      width: 210px;
      height: 210px;
      top: 210px;
      left: 75px;
      object-fit: cover;
    }

    .setoran-selesai .text-wrapper {
      position: absolute;
      top: 549px;
      left: 47px;
      font-family: "ABeeZee-Italic", Helvetica;
      font-weight: 400;
      font-style: italic;
      color: #e16417;
      font-size: 20px;
      letter-spacing: 0;
      line-height: normal;
      white-space: nowrap;
    }

    .setoran-selesai .silahkan-lakukan {
      position: absolute;
      top: 581px;
      left: 47px;
      font-family: "Alatsi-Regular", Helvetica;
      font-weight: 400;
      color: #095f7b;
      font-size: 11px;
      letter-spacing: 0;
      line-height: normal;
    }

    .setoran-selesai .logo-nama-removebg {
      position: absolute;
      width: 150px;
      height: 100px;
      top: 32px;
      left: 105px;
      object-fit: cover;
    }

    .setoran-selesai .overlap-group {
      position: absolute;
      width: 268px;
      height: 52px;
      top: 623px;
      left: 46px;
      background-color: #ffffff;
      border-radius: 5px;
      border: 1px solid;
      border-color: #e16417;
    }

    .setoran-selesai .img {
      position: absolute;
      width: 50px;
      height: 50px;
      top: 1px;
      left: 13px;
      object-fit: cover;
    }

    .setoran-selesai .text-wrapper-2 {
      position: absolute;
      top: 12px;
      left: 67px;
      font-family: "ABeeZee-Regular", Helvetica;
      font-weight: 400;
      color: #e16417;
      font-size: 8px;
      letter-spacing: 0;
      line-height: normal;
      white-space: nowrap;
    }

    .setoran-selesai .text-wrapper-3 {
      position: absolute;
      top: 24px;
      left: 67px;
      font-family: "Alatsi-Regular", Helvetica;
      font-weight: 400;
      color: #095f7b;
      font-size: 7px;
      letter-spacing: 0;
      line-height: normal;
    }

    .setoran-selesai .overlap {
      position: absolute;
      width: 62px;
      height: 22px;
      top: 15px;
      left: 194px;
      background-color: #e16417;
      border-radius: 2px;
      cursor: pointer;
      /* Add cursor pointer */
    }

    .setoran-selesai .text-wrapper-4 {
      position: absolute;
      top: 3px;
      left: 11px;
      font-family: "ABeeZee-Regular", Helvetica;
      font-weight: 400;
      color: #ffffff;
      font-size: 12px;
      letter-spacing: 0;
      line-height: normal;
      white-space: nowrap;
    }

    .setoran-selesai .fi-rr-thumbs-up {
      position: absolute;
      width: 20px;
      height: 20px;
      top: 739px;
      left: 47px;
      object-fit: cover;
    }

    .setoran-selesai .p {
      position: absolute;
      width: 242px;
      top: 739px;
      left: 71px;
      font-family: "Alatsi-Regular", Helvetica;
      font-weight: 400;
      color: #095f7b;
      font-size: 6.5px;
      letter-spacing: 0;
      line-height: normal;
    }

    .setoran-selesai .text-wrapper-5 {
      position: absolute;
      top: 69px;
      left: 28px;
      font-family: "Alatsi-Regular", Helvetica;
      font-weight: 400;
      color: #e16417;
      font-size: 15px;
      letter-spacing: 0;
      line-height: normal;
      text-decoration: underline;
    }
  </style>
</head>

<body>
  <div class="phone-frame">
    <div class="phone-screen">
      <div class="landing-menu">
        <div class="div">
          <div class="setoran-selesai">
            <div class="div">
              <img class="women-holding-phone" src="img/setoran_pertama.png" />
              <div class="text-wrapper">Setoran Awal Dulu Ya!</div>
              <p class="silahkan-lakukan">
                Silahkan lakukan setoran awal sebesar Rp10.000<br />ke virtual
                account dibawah ya!
              </p>
              <img class="logo-nama-removebg" src="img/money_save.png" />
              <div class="overlap-group">
                <img class="img" src="img/money_save.png" />
                <div class="text-wrapper-2">Money Save Virtual Account</div>
                <div class="text-wrapper-3">1232-3826-2932-2029</div>
                <div class="overlap" onclick="redirectToSelesai()">
                  <div class="text-wrapper-4">Selesai</div>
                </div>
              </div>
              <img class="fi-rr-thumbs-up" src="img/fi-rr-thumbs-up-1.png" />
              <p class="p">
                Jika dalam 24 Jam setoran awal belum dilakukan, maka kamu harus
                mengulang proses pendaftaran dari awal ya! pastikan bayar tepat
                waktu😤
              </p>
            </div>
          </div>

          <script>
            // Get NIK from URL parameters
            const urlParams = new URLSearchParams(window.location.search);
            const nik = urlParams.get('nik');

            function redirectToSelesai() {
              if (nik) {
                window.location.href = 'buat_akun.php?nik=' + encodeURIComponent(nik);
              } else {
                alert('NIK tidak ditemukan!');
                console.error('NIK parameter is missing');
              }
            }
          </script>
        </div>
      </div>
    </div>
  </div>
</body>

</html>