<?php
header('Content-Type: application/json');

// Koneksi database
$host = "localhost";
$user = "root";
$pass = "";
$db   = "moneysave";

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    die(json_encode(['success' => false, 'message' => 'Koneksi database gagal']));
}

// var_dump($_POST); // Tambahkan ini untuk debugging

try {
    $nik = $_POST['nik'] ?? '';
    $nama = $_POST['nama_pemilik'] ?? '';
    $cabang = $_POST['cabang'] ?? '';
    $tanggal = $_POST['tgl_pembuatan'] ?? '';

    if (!$nik || !$nama || !$cabang || !$tanggal) {
        throw new Exception("Semua field harus diisi");
    }

    // Ambil no_rekening dari tabel daftar
    $stmt = $conn->prepare("SELECT no_rekening FROM daftar WHERE nik = ?");
    $stmt->bind_param("s", $nik);
    $stmt->execute();
    $stmt->bind_result($noRekening);
    $stmt->fetch();
    $stmt->close();

    if (!$noRekening) {
        throw new Exception("No rekening tidak ditemukan di tabel daftar");
    }

    // Cek apakah sudah ada data untuk NIK ini di rekening_tabungan
    $cek = $conn->prepare("SELECT COUNT(*) FROM rekening_tabungan WHERE nik = ?");
    $cek->bind_param("s", $nik);
    $cek->execute();
    $cek->bind_result($sudahAda);
    $cek->fetch();
    $cek->close();

    if ($sudahAda > 0) {
        throw new Exception("Data rekening untuk NIK ini sudah ada.");
    }

    // Insert ke rekening_tabungan
    $stmt2 = $conn->prepare("INSERT INTO rekening_tabungan (nik, no_rekening, nama_pemilik, cabang, tgl_pembuatan, created_at) VALUES (?, ?, ?, ?, ?, NOW())");
    if (!$stmt2) {
        throw new Exception("Prepare failed:
    }
    $stmt2->bind_param("sssss", $nik, $noRekening, $nama, $cabang, $tanggal);

    if ($stmt2->execute()) {
        echo json_encode([
            'success' => true,
            'message' => 'Data berhasil disimpan',
            'no_rekening' => $noRekening,
            'nik' => $nik
        ]);
    } else {
        throw new Exception("Gagal menyimpan rekening_tabungan: " . $stmt2->error);
    }
    $stmt2->close();
    $conn->close();
} catch (Exception $e) {
    if (isset($conn)) $conn->close();
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
