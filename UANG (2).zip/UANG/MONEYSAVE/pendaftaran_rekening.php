<!DOCTYPE html>
<html>
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta charset="utf-8" />
    <link rel="stylesheet" href="view/css/bootstrap.min.css" />
    <script src="view/js/bootstrap.min.js"></script>
  </head>
  <body>
    <style>
      @import url("https://cdnjs.cloudflare.com/ajax/libs/meyer-reset/2.0/reset.min.css");
      * {
        -webkit-font-smoothing: antialiased;
        box-sizing: border-box;
      }
      html,
      body {
        margin: 0px;
        height: 100%;
      }
      .phone-frame {
        background-color: #dcdcdc;
        padding: 30px 12px;
        border-radius: 40px;
        box-shadow: 0 0 0 10px #888;
        display: flex;
        justify-content: center;
        align-items: center;
        min-height: 100vh;
      }
      /* a blue color as a generic focus style */
      button:focus-visible {
        outline: 2px solid #4a90e2 !important;
        outline: -webkit-focus-ring-color auto 5px !important;
      }
      a {
        text-decoration: none;
      }

      .isi-formulir {
        background-color: #ffffff;
        display: flex;
        flex-direction: row;
        justify-content: center;
        width: 100%;
      }

      .isi-formulir .div {
        background-color: #ffffff;
        width: 360px;
        height: 800px;
        position: relative;
      }

      .isi-formulir .logo-nama-removebg {
        position: absolute;
        width: 150px;
        height: 100px;
        top: 32px;
        left: 105px;
        object-fit: cover;
      }

      .isi-formulir .overlap {
        width: 266px;
        top: 726px;
        left: 46px;
        position: absolute;
        height: 40px;
        border-radius: 5px;
      }

      .isi-formulir .rectangle {
        position: absolute;
        width: 266px;
        height: 40px;
        top: 0;
        left: 0;
        background-color: #e16417;
        border-radius: 5px;
      }

      .isi-formulir .text-wrapper {
        position: absolute;
        top: 11px;
        left: 59px;
        font-family: "ABeeZee-Regular", Helvetica;
        font-weight: 400;
        color: #ffffff;
        font-size: 13px;
        letter-spacing: 0;
        line-height: normal;
        white-space: nowrap;
      }

      .isi-formulir .text-wrapper-2 {
        position: absolute;
        top: 134px;
        left: 28px;
        font-family: "Alatsi-Regular", Helvetica;
        font-weight: 400;
        color: #e16417;
        font-size: 20px;
        letter-spacing: 0;
        line-height: normal;
      }

      .isi-formulir .silahkan-isi-data {
        position: absolute;
        top: 166px;
        left: 28px;
        font-family: "Alatsi-Regular", Helvetica;
        font-weight: 400;
        color: #095f7b;
        font-size: 11px;
        letter-spacing: 0;
        line-height: normal;
      }

      .isi-formulir .text-wrapper-3 {
        position: absolute;
        top: 222px;
        left: 28px;
        font-family: "Qualion-DemiBold", Helvetica;
        font-weight: 700;
        color: #095f7b;
        font-size: 12px;
        letter-spacing: 0;
        line-height: normal;
      }

      .isi-formulir .overlap-group {
        width: 305px;
        top: 246px;
        left: 28px;
        border: 1px solid;
        border-color: #095f7b;
        position: absolute;
        height: 40px;
        border-radius: 5px;
      }

      .isi-formulir .text-wrapper-4 {
        position: absolute;
        top: 10px;
        left: 19px;
        font-family: "Qualion-DemiBold", Helvetica;
        font-weight: 700;
        color: #095f7b;
        font-size: 10px;
        letter-spacing: 0;
        line-height: normal;
      }

      .isi-formulir .text-wrapper-5 {
        position: absolute;
        top: 293px;
        left: 28px;
        font-family: "Qualion-DemiBold", Helvetica;
        font-weight: 700;
        color: #095f7b;
        font-size: 12px;
        letter-spacing: 0;
        line-height: normal;
      }

      .isi-formulir .div-wrapper {
        width: 305px;
        top: 317px;
        left: 28px;
        border: 1px solid;
        border-color: #095f7b;
        position: absolute;
        height: 40px;
        border-radius: 5px;
      }

      .isi-formulir .text-wrapper-6 {
        position: absolute;
        top: 364px;
        left: 28px;
        font-family: "Qualion-DemiBold", Helvetica;
        font-weight: 700;
        color: #095f7b;
        font-size: 12px;
        letter-spacing: 0;
        line-height: normal;
      }

      .isi-formulir .overlap-2 {
        width: 305px;
        top: 388px;
        left: 28px;
        border: 1px solid;
        border-color: #095f7b;
        position: absolute;
        height: 40px;
        border-radius: 5px;
      }

      .isi-formulir .text-wrapper-7 {
        position: absolute;
        top: 435px;
        left: 28px;
        font-family: "Qualion-DemiBold", Helvetica;
        font-weight: 700;
        color: #095f7b;
        font-size: 12px;
        letter-spacing: 0;
        line-height: normal;
      }

      .isi-formulir .text-wrapper-8 {
        position: absolute;
        top: 505px;
        left: 28px;
        font-family: "Qualion-DemiBold", Helvetica;
        font-weight: 700;
        color: #095f7b;
        font-size: 12px;
        letter-spacing: 0;
        line-height: normal;
      }

      .isi-formulir .overlap-3 {
        width: 305px;
        top: 459px;
        left: 28px;
        border: 1px solid;
        border-color: #095f7b;
        position: absolute;
        height: 40px;
        border-radius: 5px;
      }

      .isi-formulir .overlap-4 {
        width: 305px;
        top: 529px;
        left: 28px;
        border: 1px solid;
        border-color: #095f7b;
        position: absolute;
        height: 40px;
        border-radius: 5px;
      }

      .isi-formulir .text-wrapper-9 {
        position: absolute;
        top: 576px;
        left: 28px;
        font-family: "Qualion-DemiBold", Helvetica;
        font-weight: 700;
        color: #095f7b;
        font-size: 12px;
        letter-spacing: 0;
        line-height: normal;
      }

      .isi-formulir .overlap-group-2 {
        width: 305px;
        top: 600px;
        left: 28px;
        border: 1px solid;
        border-color: #095f7b;
        position: absolute;
        height: 40px;
        border-radius: 5px;
      }

      .isi-formulir .group {
        position: absolute;
        width: 264px;
        height: 45px;
        top: 673px;
        left: 48px;
      }

      .isi-formulir .OJK {
        position: absolute;
        width: 60px;
        height: 45px;
        top: 0;
        left: 0;
        object-fit: cover;
      }

      .isi-formulir .logo-lps {
        position: absolute;
        width: 60px;
        height: 36px;
        top: 7px;
        left: 102px;
        object-fit: cover;
      }

      .isi-formulir .logo-bun {
        position: absolute;
        width: 60px;
        height: 21px;
        top: 15px;
        left: 204px;
        object-fit: cover;
      }
    </style>
    <div class="phone-frame">
      <div class="phone-screen">
        <div class="landing-menu">
          <div class="div">
            <div class="isi-formulir">
              <div class="div">
                <img class="logo-nama-removebg" src="img/money_save.png" />
                <form action="pro_pendaftaran_rekening.php" method="POST">
                  <div class="text-wrapper-2">Pendaftaran Rekening</div>
                  <p class="silahkan-isi-data">
                    Silahkan isi data yang masih kosong dan jika ada yang<br />salah
                    silahkan dibetulkan ya!
                  </p>
                  <div class="text-wrapper-3">
                    Nomor Induk Kependudukan (NIK)
                  </div>
                  <div class="overlap-group">
                    <input
                      type="text"
                      required
                      name="nik"
                      style="
                        width: 100%;
                        padding: 8px;
                        font-size: 16px;
                        border: 1px solid #ccc;
                        border-radius: 5px;
                        box-sizing: border-box;
                        outline: none;
                        box-shadow: none;
                        font-family: 'Qualion-DemiBold', Helvetica;
                      "
                    />
                  </div>
                  <div class="text-wrapper-5">Nama Lengkap</div>
                  <div class="div-wrapper">
                    <input
                      type="text"
                      required
                      name="nama_ktp"
                      style="
                        width: 100%;
                        padding: 8px;
                        font-size: 16px;
                        border: 1px solid #ccc;
                        border-radius: 5px;
                        box-sizing: border-box;
                        outline: none;
                        box-shadow: none;
                        font-family: 'Qualion-DemiBold', Helvetica;
                      "
                    />
                  </div>
                  <div class="text-wrapper-6">Tanggal Lahir</div>
                  <div class="overlap-2">
                    <input
                      type="date"
                      required
                      name="tempat_tanggal_lahir"
                      style="
                        width: 100%;
                        padding: 8px;
                        font-size: 15px;
                        border: 1px solid #ccc;
                        border-radius: 5px;
                        box-sizing: border-box;
                        outline: none;
                        box-shadow: none;
                        font-family: 'Qualion-DemiBold', Helvetica;
                      "
                    />
                  </div>
                  <div class="text-wrapper-7">Agama</div>
                  <div class="overlap-3">
                    <input
                      type="text"
                      required
                      name="agama"
                      style="
                        width: 100%;
                        padding: 8px;
                        font-size: 16px;
                        border: 1px solid #ccc;
                        border-radius: 5px;
                        box-sizing: border-box;
                        outline: none;
                        box-shadow: none;
                        font-family: 'Qualion-DemiBold', Helvetica;
                      "
                    />
                  </div>
                  <div class="text-wrapper-8">Alamat Lengkap</div>
                  <div class="overlap-4">
                    <input
                      type="text"
                      required
                      name="alamat_lengkap"
                      style="
                        width: 100%;
                        padding: 8px;
                        font-size: 16px;
                        border: 1px solid #ccc;
                        border-radius: 5px;
                        box-sizing: border-box;
                        outline: none;
                        box-shadow: none;
                        font-family: 'Qualion-DemiBold', Helvetica;
                      "
                    />
                  </div>
                  <div class="text-wrapper-9">Tujuan Pembukaan Rekening</div>
                  <div class="overlap-group-2">
                    <input
                      type="text"
                      required
                      name="tujuan_pembukaan"
                      style="
                        width: 100%;
                        padding: 8px;
                        font-size: 16px;
                        border: 1px solid #ccc;
                        border-radius: 5px;
                        box-sizing: border-box;
                        outline: none;
                        box-shadow: none;
                        font-family: 'Qualion-DemiBold', Helvetica;
                      "
                    />
                  </div>
                  <button
                    onclick="lanjutSetoran()"
                    class="text-decoration-none"
                    style="all: unset; cursor: pointer"
                  >
                    <div class="overlap">
                      <div class="rectangle"></div>
                      <div class="text-wrapper">Lanjut Setoran Pertama</div>
                    </div>
                  </button>
                </form>
                <div class="group">
                  <img class="OJK" src="img/OJK-1.png" />
                  <img class="logo-lps" src="img/logo-lps-1.png" />
                  <img class="logo-bun" src="img/logo-bun-1.png" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </body>
</html>
