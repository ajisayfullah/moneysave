<!DOCTYPE html>
<html>
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta charset="utf-8" />
    <link rel="stylesheet" href="view/css/bootstrap.min.css" />
    <script src="view/js/bootstrap.min.js"></script>
  </head>
  <body>
    <style>
      @import url("https://cdnjs.cloudflare.com/ajax/libs/meyer-reset/2.0/reset.min.css");
      * {
        -webkit-font-smoothing: antialiased;
        box-sizing: border-box;
      }
      html,
      body {
        margin: 0px;
        height: 100%;
      }
      /* a blue color as a generic focus style */
      button:focus-visible {
        outline: 2px solid #4a90e2 !important;
        outline: -webkit-focus-ring-color auto 5px !important;
      }
      a {
        text-decoration: none;
      }
      .login-page-smart {
        background-color: #ffffff;
        display: flex;
        flex-direction: row;
        justify-content: center;
        width: 100%;
      }

      .login-page-smart .div {
        background-color: #ffffff;
        width: 360px;
        height: 800px;
        position: relative;
      }

      .login-page-smart .women-holding-phone {
        position: absolute;
        width: 210px;
        height: 210px;
        top: 234px;
        left: 75px;
        object-fit: cover;
      }

      .login-page-smart .text-wrapper {
        position: absolute;
        top: 541px;
        left: 57px;
        font-family: "ABeeZee-Italic", Helvetica;
        font-weight: 400;
        font-style: italic;
        color: #e16417;
        font-size: 20px;
        letter-spacing: 0;
        line-height: normal;
        white-space: nowrap;
      }

      .login-page-smart .sekarang-kamu-udah {
        position: absolute;
        top: 573px;
        left: 57px;
        font-family: "Alatsi-Regular", Helvetica;
        font-weight: 400;
        color: #095f7b;
        font-size: 11px;
        letter-spacing: 0;
        line-height: normal;
      }

      .login-page-smart .logo-nama-removebg {
        position: absolute;
        width: 150px;
        height: 100px;
        top: 32px;
        left: 105px;
        object-fit: cover;
      }

      .login-page-smart .overlap {
        top: 615px;
        left: 46px;
        position: absolute;
        width: 266px;
        height: 40px;
        border-radius: 5px;
      }

      .login-page-smart .rectangle {
        background-color: #e16417;
        position: absolute;
        width: 266px;
        height: 40px;
        top: 0;
        left: 0;
        border-radius: 5px;
      }

      .login-page-smart .group {
        position: absolute;
        width: 105px;
        height: 20px;
        top: 9px;
        left: 80px;
      }

      .login-page-smart .text-wrapper-2 {
        position: absolute;
        top: 3px;
        left: 28px;
        font-family: "ABeeZee-Regular", Helvetica;
        font-weight: 400;
        color: #ffffff;
        font-size: 13px;
        letter-spacing: 0;
        line-height: normal;
        white-space: nowrap;
      }

      .login-page-smart .fi-rs-fingerprint {
        position: absolute;
        width: 20px;
        height: 20px;
        top: 0;
        left: 0;
        object-fit: cover;
      }

      .login-page-smart .overlap-group {
        top: 668px;
        left: 47px;
        position: absolute;
        width: 266px;
        height: 40px;
        border-radius: 5px;
      }

      .login-page-smart .rectangle-2 {
        background-color: #ffffff;
        border: 1px solid;
        border-color: #e16417;
        position: absolute;
        width: 266px;
        height: 40px;
        top: 0;
        left: 0;
        border-radius: 5px;
      }

      .login-page-smart .div-wrapper {
        position: absolute;
        width: 84px;
        height: 15px;
        top: 12px;
        left: 92px;
      }

      .login-page-smart .text-wrapper-3 {
        position: absolute;
        top: 0;
        left: 0;
        font-family: "ABeeZee-Regular", Helvetica;
        font-weight: 400;
        color: #e16417;
        font-size: 13px;
        letter-spacing: 0;
        line-height: normal;
        white-space: nowrap;
      }

      .login-page-smart .group-2 {
        position: absolute;
        width: 264px;
        height: 45px;
        top: 721px;
        left: 48px;
      }

      .login-page-smart .OJK {
        position: absolute;
        width: 60px;
        height: 45px;
        top: 0;
        left: 0;
        object-fit: cover;
      }

      .login-page-smart .logo-lps {
        position: absolute;
        width: 60px;
        height: 36px;
        top: 7px;
        left: 102px;
        object-fit: cover;
      }

      .login-page-smart .logo-bun {
        position: absolute;
        width: 60px;
        height: 21px;
        top: 15px;
        left: 204px;
        object-fit: cover;
      }
      .phone-frame {
        background-color: #dcdcdc;
        padding: 30px 12px;
        border-radius: 40px;
        box-shadow: 0 0 0 10px #888;
        display: flex;
        justify-content: center;
        align-items: center;
        min-height: 100vh;
      }
    </style>
    <div class="phone-frame">
      <div class="phone-screen">
        <div class="landing-menu">
          <div class="div">
            <div class="login-page-smart">
              <div class="div">
                <img class="women-holding-phone" src="img/login.png" />
                <div class="text-wrapper">Login Money Save MOBILE</div>
                <p class="sekarang-kamu-udah">
                  Sekarang kamu udah bisa nikmatin semua fiturnya,<br />aktifkan
                  smart login di settings ya🔔
                </p>
                <img class="logo-nama-removebg" src="img/money_save.png" />
                <div class="overlap">
                  <div class="rectangle"></div>
                  <div class="group">
                    <div class="text-wrapper-2">Smart Login</div>
                    <img class="fi-rs-fingerprint" src="img/fingerprint.png" />
                  </div>
                </div>
                <div class="overlap-group" onclick="redirectToLogin()">
                  <div class="rectangle-2" style="cursor: pointer;"></div>
                  <div class="div-wrapper">
                    <div class="text-wrapper-3" style="cursor: pointer;">login Manual</div>
                  </div>
                </div>
                <div class="group-2">
                  <img class="OJK" src="img/OJK-1.png" />
                  <img class="logo-lps" src="img/logo-lps-1.png" />
                  <img class="logo-bun" src="img/logo-bun-1.png" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <script>
      // Function to handle redirection with NIK parameter
      function redirectToLogin() {
        const urlParams = new URLSearchParams(window.location.search);
        const nik = urlParams.get("nik");

        if (nik) {
          window.location.href = "login.php?nik=" + encodeURIComponent(nik);
        } else {
          // If no NIK parameter, redirect to regular login page
          window.location.href = "login.php";
        }
      }

      // Optional: You can also add this function for the Smart Login button
      function redirectToSmartLogin() {
        const urlParams = new URLSearchParams(window.location.search);
        const nik = urlParams.get("nik");

        if (nik) {
          window.location.href =
            "persiapan_dokumen.html?nik=" + encodeURIComponent(nik);
        } else {
          alert("NIK tidak ditemukan!");
          console.error("NIK parameter is missing");
        }
      }
    </script>
  </body>
</html>
