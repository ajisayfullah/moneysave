<?php
// Aktifkan error reporting untuk debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Koneksi database
$host = 'localhost';
$user = 'root';
$password = '';
$dbname = 'moneysave';

$conn = new mysqli($host, $user, $password, $dbname);
if ($conn->connect_error) {
  die("Koneksi gagal: " . $conn->connect_error);
}

// Ambil NIK dari URL
$nik = $_GET['nik'] ?? null;

// Validasi parameter NIK
if (empty($nik)) {
  echo "<div style='color:red;padding:20px;text-align:center;'>";
  echo "<h3>Error: Parameter NIK tidak ditemukan</h3>";
  echo "<p>Silahkan akses halaman ini dengan menyertakan parameter NIK di URL</p>";
  echo "<p>Contoh: <strong>verifikasi_ktp.php?nik=1234567890123456</strong></p>";
  echo "<p>Atau masukkan NIK untuk testing: <a href='?nik=1234567890123456'>Klik di sini</a></p>";
  echo "</div>";
  exit();
}

// Query database ke tabel DAFTAR
$query = "SELECT nik, nama AS nama_ktp, tgl_lahir AS tempat_tanggal_lahir, agama, alamat, jenis_kelamin 
          FROM daftar 
          WHERE nik = ?";
$stmt = $conn->prepare($query);

if (!$stmt) {
  die("Error dalam menyiapkan query: " . $conn->error);
}

$stmt->bind_param("s", $nik);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
  echo "<div style='color:red;padding:20px;text-align:center;'>";
  echo "<h3>Data tidak ditemukan</h3>";
  echo "<p>NIK <strong>$nik</strong> tidak ditemukan dalam database.</p>";
  echo "<p>Silahkan cek kembali atau masukkan NIK yang valid.</p>";
  echo "</div>";
  exit();
}

$data = $result->fetch_assoc();
$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html>

<head>
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <meta charset="utf-8" />
  <link rel="stylesheet" href="view/css/bootstrap.min.css" />
  <script src="view/js/bootstrap.min.js"></script>
</head>

<body>
  <style>
    @import url("https://cdnjs.cloudflare.com/ajax/libs/meyer-reset/2.0/reset.min.css");

    * {
      -webkit-font-smoothing: antialiased;
      box-sizing: border-box;
    }

    html,
    body {
      margin: 0px;
      height: 100%;
    }

    /* a blue color as a generic focus style */
    button:focus-visible {
      outline: 2px solid #4a90e2 !important;
      outline: -webkit-focus-ring-color auto 5px !important;
    }

    a {
      text-decoration: none;
    }

    .verifikasi-KTP {
      background-color: #ffffff;
      display: flex;
      flex-direction: row;
      justify-content: center;
      width: 100%;
    }

    .verifikasi-KTP .div {
      background-color: #ffffff;
      width: 360px;
      height: 800px;
      position: relative;
    }

    .verifikasi-KTP .logo-nama-removebg {
      position: absolute;
      width: 150px;
      height: 100px;
      top: 32px;
      left: 105px;
      object-fit: cover;
    }

    .verifikasi-KTP .overlap {
      width: 266px;
      top: 726px;
      left: 46px;
      position: absolute;
      height: 40px;
      border-radius: 5px;
    }

    .verifikasi-KTP .rectangle {
      position: absolute;
      width: 266px;
      height: 40px;
      top: 0;
      left: 0;
      background-color: #e16417;
      border-radius: 5px;
    }

    .verifikasi-KTP .text-wrapper {
      position: absolute;
      top: 11px;
      left: 37px;
      font-family: "ABeeZee-Regular", Helvetica;
      font-weight: 400;
      color: #ffffff;
      font-size: 13px;
      letter-spacing: 0;
      line-height: normal;
      white-space: nowrap;
    }

    .verifikasi-KTP .text-wrapper-2 {
      position: absolute;
      top: 134px;
      left: 28px;
      font-family: "Alatsi-Regular", Helvetica;
      font-weight: 400;
      color: #e16417;
      font-size: 20px;
      letter-spacing: 0;
      line-height: normal;
    }

    .verifikasi-KTP .silahkan-cek-ulang {
      position: absolute;
      top: 166px;
      left: 28px;
      font-family: "Alatsi-Regular", Helvetica;
      font-weight: 400;
      color: #095f7b;
      font-size: 11px;
      letter-spacing: 0;
      line-height: normal;
    }

    .verifikasi-KTP .text-wrapper-3 {
      position: absolute;
      top: 222px;
      left: 28px;
      font-family: "Qualion-DemiBold", Helvetica;
      font-weight: 700;
      color: #095f7b;
      font-size: 12px;
      letter-spacing: 0;
      line-height: normal;
    }

    .verifikasi-KTP .overlap-group {
      width: 305px;
      top: 246px;
      left: 28px;
      border: 1px solid;
      border-color: #095f7b;
      position: absolute;
      height: 40px;
      border-radius: 5px;
    }

    .verifikasi-KTP .text-wrapper-4 {
      position: absolute;
      top: 10px;
      left: 19px;
      font-family: "Alatsi-Regular", Helvetica;
      font-weight: 400;
      color: #777777;
      font-size: 10px;
      letter-spacing: 0;
      line-height: normal;
    }

    .verifikasi-KTP .text-wrapper-5 {
      position: absolute;
      top: 293px;
      left: 28px;
      font-family: "Qualion-DemiBold", Helvetica;
      font-weight: 700;
      color: #095f7b;
      font-size: 12px;
      letter-spacing: 0;
      line-height: normal;
    }

    .verifikasi-KTP .div-wrapper {
      width: 305px;
      top: 317px;
      left: 28px;
      border: 1px solid;
      border-color: #095f7b;
      position: absolute;
      height: 40px;
      border-radius: 5px;
    }

    .verifikasi-KTP .text-wrapper-6 {
      position: absolute;
      top: 364px;
      left: 28px;
      font-family: "Qualion-DemiBold", Helvetica;
      font-weight: 700;
      color: #095f7b;
      font-size: 12px;
      letter-spacing: 0;
      line-height: normal;
    }

    .verifikasi-KTP .overlap-2 {
      width: 305px;
      top: 388px;
      left: 28px;
      border: 1px solid;
      border-color: #095f7b;
      position: absolute;
      height: 40px;
      border-radius: 5px;
    }

    .verifikasi-KTP .text-wrapper-7 {
      position: absolute;
      top: 435px;
      left: 28px;
      font-family: "Qualion-DemiBold", Helvetica;
      font-weight: 700;
      color: #095f7b;
      font-size: 12px;
      letter-spacing: 0;
      line-height: normal;
    }

    .verifikasi-KTP .text-wrapper-8 {
      position: absolute;
      top: 505px;
      left: 28px;
      font-family: "Qualion-DemiBold", Helvetica;
      font-weight: 700;
      color: #095f7b;
      font-size: 12px;
      letter-spacing: 0;
      line-height: normal;
    }

    .verifikasi-KTP .overlap-3 {
      width: 305px;
      top: 459px;
      left: 28px;
      border: 1px solid;
      border-color: #095f7b;
      position: absolute;
      height: 40px;
      border-radius: 5px;
    }

    .verifikasi-KTP .overlap-4 {
      width: 305px;
      top: 529px;
      left: 28px;
      border: 1px solid;
      border-color: #095f7b;
      position: absolute;
      height: 40px;
      border-radius: 5px;
    }

    .verifikasi-KTP .text-wrapper-9 {
      position: absolute;
      top: 575px;
      left: 28px;
      font-family: "Qualion-DemiBold", Helvetica;
      font-weight: 700;
      color: #095f7b;
      font-size: 12px;
      letter-spacing: 0;
      line-height: normal;
    }

    .verifikasi-KTP .laki-perempuan-wrapper {
      width: 305px;
      top: 599px;
      left: 28px;
      border: 1px solid;
      border-color: #095f7b;
      position: absolute;
      height: 40px;
      border-radius: 5px;
    }

    .verifikasi-KTP .group {
      position: absolute;
      width: 264px;
      height: 45px;
      top: 673px;
      left: 48px;
    }

    .verifikasi-KTP .OJK {
      position: absolute;
      width: 60px;
      height: 45px;
      top: 0;
      left: 0;
      object-fit: cover;
    }

    .verifikasi-KTP .logo-lps {
      position: absolute;
      width: 60px;
      height: 36px;
      top: 7px;
      left: 102px;
      object-fit: cover;
    }

    .verifikasi-KTP .logo-bun {
      position: absolute;
      width: 60px;
      height: 21px;
      top: 15px;
      left: 204px;
      object-fit: cover;
    }

    .phone-frame {
      background-color: #dcdcdc;
      padding: 30px 12px;
      border-radius: 40px;
      box-shadow: 0 0 0 10px #888;
      display: flex;
      justify-content: center;
      align-items: center;
      min-height: 100vh;
    }
  </style>
  <div class="phone-frame">
    <div class="phone-screen">
      <div class="landing-menu">
        <div class="div">
          <div class="verifikasi-KTP">
            <div class="div">
              <img class="logo-nama-removebg" src="img/money_save.png" />
              <div class="text-wrapper-2">Verifikasi Data KTP</div>
              <p class="silahkan-cek-ulang">
                Silahkan cek ulang data yang telah kami baca, jika<br />ada
                yang salah silahkan betulkan ya⭐
              </p>
              <form id="form-pendaftaran" action="proses_pendaftaran.php" method="post">
                <div class="text-wrapper-3">Nomor Induk Kependudukan (NIK)</div>
                <div class="overlap-group">
                  <input
                    type="text"
                    name="nik"
                    value="<?= htmlspecialchars($data['nik']) ?>"
                    style="
                      width: 100%;
                      padding: 8px;
                      font-size: 16px;
                      border: none;
                      outline: none;
                      height: 100%;
                      box-sizing: border-box;
                      color: #095f7b;
                      font-weight: 700;
                      font-family: 'Qualion-DemiBold', Helvetica;
                    "
                    disabled />
                </div>
                <div class="text-wrapper-5">Nama Lengkap</div>
                <div class="div-wrapper">
                  <input
                    type="text"
                    value="<?= htmlspecialchars($data['nama_ktp']) ?>"
                    name="nama_ktp"
                    style="
                      width: 100%;
                      padding: 8px;
                      font-size: 16px;
                      border: none;
                      outline: none;
                      height: 100%;
                      box-sizing: border-box;
                      color: #095f7b;
                      font-weight: 700;
                      font-family: 'Qualion-DemiBold', Helvetica;
                    "
                    disabled />
                </div>
                <div class="text-wrapper-6">Tanggal Lahir</div>
                <div class="overlap-2">
                  <input
                    type="text"
                    name="tempat_tanggal_lahir"
                    value="<?= htmlspecialchars($data['tempat_tanggal_lahir']) ?>"
                    style="
                      width: 100%;
                      padding: 8px;
                      font-size: 16px;
                      border: none;
                      outline: none;
                      height: 100%;
                      box-sizing: border-box;
                      color: #095f7b;
                      font-weight: 700;
                      font-family: 'Qualion-DemiBold', Helvetica;
                    "
                    disabled />
                </div>
                <div class="text-wrapper-7">Agama</div>
                <div class="overlap-3">
                  <input
                    type="text"
                    name="agama"
                    value="<?= htmlspecialchars($data['agama']) ?>"
                    style="
                      width: 100%;
                      padding: 8px;
                      font-size: 16px;
                      border: none;
                      outline: none;
                      height: 100%;
                      box-sizing: border-box;
                      color: #095f7b;
                      font-weight: 700;
                      font-family: 'Qualion-DemiBold', Helvetica;
                    "
                    disabled />
                </div>
                <div class="text-wrapper-8">Alamat Lengkap</div>
                <div class="overlap-4">
                  <input
                    type="text"
                    name="alamat_lengkap"
                    value="<?= htmlspecialchars($data['alamat']) ?>"
                    style="
                      width: 100%;
                      padding: 8px;
                      font-size: 16px;
                      border: none;
                      outline: none;
                      height: 100%;
                      box-sizing: border-box;
                      color: #095f7b;
                      font-weight: 700;
                      font-family: 'Qualion-DemiBold', Helvetica;
                    "
                    disabled />
                </div>
                <div class="text-wrapper-9">Jenis Kelamin</div>
                <div class="laki-perempuan-wrapper">
                  <select
                    name="jenis_kelamin"
                    id="jenis_kelamin"
                    required
                    style="width: 100%; height: 100%; border: none; outline: none; padding-left: 10px; font-size: 16px; font-family: 'Qualion-DemiBold', Helvetica; color: #095f7b; font-weight: 700; background-color: transparent; cursor: pointer;">
                    <option value="" disabled selected>Pilih Jenis Kelamin</option>
                    <option value="Laki-laki" <?= ($data['jenis_kelamin'] == 'Laki-laki') ? 'selected' : '' ?>>Laki-laki</option>
                    <option value="Perempuan" <?= ($data['jenis_kelamin'] == 'Perempuan') ? 'selected' : '' ?>>Perempuan</option>
                  </select>
                </div>

                <!-- Ganti div menjadi button submit -->
                <button type="submit" class="overlap" style="cursor: pointer; background: none; border: none; padding: 0;">
                  <div class="rectangle"></div>
                  <div class="text-wrapper" style="cursor: pointer;">Lanjutkan isi Nomor Rekening</div>
                </button>
              </form>

              <div class="group">
                <img class="OJK" src="img/OJK-1.png" />
                <img class="logo-lps" src="img/logo-lps-1.png" />
                <img class="logo-bun" src="img/logo-bun-1.png" />
              </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <script>
    document.getElementById('form-pendaftaran').addEventListener('submit', async function(e) {
      e.preventDefault();

      const jenisKelamin = document.getElementById('jenis_kelamin').value;
      const nik = '<?= htmlspecialchars($data['nik']) ?>';

      // Validasi hanya jenis kelamin
      if (!jenisKelamin) {
        alert('Silakan pilih jenis kelamin');
        document.getElementById('jenis_kelamin').focus();
        return;
      }

      try {
        // Kirim hanya data yang diperlukan
        const formData = new FormData();
        formData.append('nik', nik);
        formData.append('jenis_kelamin', jenisKelamin);

        const response = await fetch('proses_pendaftaran.php', {
          method: 'POST',
          body: formData
        });

        const result = await response.json();

        if (result.success) {
          window.location.href = 'isi_no_req.php?nik=' + encodeURIComponent(nik);
        } else {
          alert(result.message || 'Gagal menyimpan data');
        }
      } catch (error) {
        console.error('Error:', error);
        alert('Terjadi kesalahan saat menyimpan data');
      }
    });
  </script>
</body>

</html>