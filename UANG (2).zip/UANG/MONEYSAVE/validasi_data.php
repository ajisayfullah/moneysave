<?php
// koneksi ke database
$koneksi = new mysqli("localhost", "root", "", "moneysave");

// cek koneksi
if ($koneksi->connect_error) {
  die("Koneksi gagal: " . $koneksi->connect_error);
}

// Ambil NIK dari URL atau request
$nik_param = isset($_GET['nik']) ? $_GET['nik'] : 0;

// Ambil data dari tabel pendaftaran_rekening
$query = "SELECT * FROM pendaftaran_rekening WHERE nik = '$nik_param'";
$result = $koneksi->query($query);

// Inisialisasi variabel
$nik = "";
$nama_ktp = "";
$tempat_tanggal_lahir = "";
$agama = "";
$alamat_lengkap = "";
$jenis_kelamin = "";
$no_rekening = "";

$nama_pemilik = "";
$cabang = "";
$tgl_pembuatan = "";

if ($result->num_rows > 0) {
  $data = $result->fetch_assoc();
  $nik = $data['nik'];
  $nama_ktp = $data['nama_ktp'];
  $tempat_tanggal_lahir = $data['tempat_tanggal_lahir'];
  $agama = $data['agama'];
  $alamat_lengkap = $data['alamat_lengkap'];
  $jenis_kelamin = $data['jenis_kelamin'];
  $no_rekening = $data['no_rekening'];
}

// Ambil data dari rekening_tabungan berdasarkan NIK atau no_rekening
$query_rekening = "SELECT * FROM rekening_tabungan WHERE nik = '$nik_param'";
$result_rekening = $koneksi->query($query_rekening);

if ($result_rekening->num_rows > 0) {
  $data_rekening = $result_rekening->fetch_assoc();
  $nama_pemilik = $data_rekening['nama_pemilik'];
  $cabang = $data_rekening['cabang'];
  $tgl_pembuatan = $data_rekening['tgl_pembuatan'];
}
?>




<!DOCTYPE html>
<html>

<head>
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <meta charset="utf-8" />
  <link rel="stylesheet" href="view/css/bootstrap.min.css" />
  <script src="view/js/bootstrap.min.js"></script>
  <style>
    @import url("https://cdnjs.cloudflare.com/ajax/libs/meyer-reset/2.0/reset.min.css");

    * {
      -webkit-font-smoothing: antialiased;
      box-sizing: border-box;
    }

    html,
    body {
      margin: 0px;
      height: 100%;
    }

    /* a blue color as a generic focus style */
    button:focus-visible {
      outline: 2px solid #4a90e2 !important;
      outline: -webkit-focus-ring-color auto 5px !important;
    }

    a {
      text-decoration: none;
    }

    .validasi-data {
      background-color: #ffffff;
      display: flex;
      flex-direction: row;
      justify-content: center;
      width: 100%;
    }

    .validasi-data .div {
      background-color: #ffffff;
      overflow: hidden;
      width: 360px;
      height: 1217px;
      position: relative;
    }

    .validasi-data .logo-nama-removebg {
      position: absolute;
      width: 150px;
      height: 100px;
      top: 25px;
      left: 105px;
      object-fit: cover;
    }

    .validasi-data .text-wrapper {
      position: absolute;
      top: 128px;
      left: 28px;
      font-family: "Alatsi-Regular", Helvetica;
      font-weight: 400;
      color: #e16417;
      font-size: 20px;
      letter-spacing: 0;
      line-height: normal;
    }

    .validasi-data .lengkapi-data-yang {
      position: absolute;
      width: 219px;
      top: 158px;
      left: 28px;
      font-family: "Alatsi-Regular", Helvetica;
      font-weight: 400;
      color: #095f7b;
      font-size: 11px;
      letter-spacing: 0;
      line-height: normal;
    }

    .validasi-data .group {
      position: absolute;
      width: 355px;
      height: 951px;
      top: 220px;
      left: 28px;
    }

    .validasi-data .text-wrapper-2 {
      position: absolute;
      top: 0;
      left: 0;
      font-family: "Qualion-DemiBold", Helvetica;
      font-weight: 700;
      color: #095f7b;
      font-size: 12px;
      letter-spacing: 0;
      line-height: normal;
    }

    .validasi-data .overlap {
      width: 305px;
      top: 23px;
      left: 0;
      border: 1px solid;
      border-color: #095f7b;
      position: absolute;
      height: 40px;
      border-radius: 5px;
    }

    .validasi-data .text-wrapper-3 {
      position: absolute;
      top: 11px;
      left: 19px;
      font-family: "Alatsi-Regular", Helvetica;
      font-weight: 400;
      color: #777777;
      font-size: 10px;
      letter-spacing: 0;
      line-height: normal;
    }

    .validasi-data .text-wrapper-4 {
      position: absolute;
      top: 71px;
      left: 0;
      font-family: "Qualion-DemiBold", Helvetica;
      font-weight: 700;
      color: #095f7b;
      font-size: 12px;
      letter-spacing: 0;
      line-height: normal;
    }

    .validasi-data .overlap-group {
      width: 305px;
      top: 94px;
      left: 0;
      border: 1px solid;
      border-color: #095f7b;
      position: absolute;
      height: 40px;
      border-radius: 5px;
    }

    .validasi-data .text-wrapper-5 {
      position: absolute;
      top: 142px;
      left: 0;
      font-family: "Qualion-DemiBold", Helvetica;
      font-weight: 700;
      color: #095f7b;
      font-size: 12px;
      letter-spacing: 0;
      line-height: normal;
    }

    .validasi-data .div-wrapper {
      width: 305px;
      top: 165px;
      left: 0;
      border: 1px solid;
      border-color: #095f7b;
      position: absolute;
      height: 40px;
      border-radius: 5px;
    }

    .validasi-data .text-wrapper-6 {
      position: absolute;
      top: 213px;
      left: 0;
      font-family: "Qualion-DemiBold", Helvetica;
      font-weight: 700;
      color: #095f7b;
      font-size: 12px;
      letter-spacing: 0;
      line-height: normal;
    }

    .validasi-data .text-wrapper-7 {
      top: 283px;
      left: 0;
      font-family: "Qualion-DemiBold", Helvetica;
      font-weight: 700;
      color: #095f7b;
      font-size: 12px;
      position: absolute;
      letter-spacing: 0;
      line-height: normal;
    }

    .validasi-data .overlap-2 {
      width: 305px;
      top: 236px;
      left: 0;
      border: 1px solid;
      border-color: #095f7b;
      position: absolute;
      height: 40px;
      border-radius: 5px;
    }

    .validasi-data .overlap-3 {
      width: 305px;
      top: 306px;
      left: 0;
      border: 1px solid;
      border-color: #095f7b;
      position: absolute;
      height: 40px;
      border-radius: 5px;
    }

    .validasi-data .text-wrapper-8 {
      position: absolute;
      top: 353px;
      left: 0;
      font-family: "Qualion-DemiBold", Helvetica;
      font-weight: 700;
      color: #095f7b;
      font-size: 12px;
      letter-spacing: 0;
      line-height: normal;
    }

    .validasi-data .text-wrapper-9 {
      top: 423px;
      left: 0;
      font-family: "Qualion-DemiBold", Helvetica;
      font-weight: 700;
      color: #095f7b;
      font-size: 12px;
      position: absolute;
      letter-spacing: 0;
      line-height: normal;
    }

    .validasi-data .overlap-4 {
      width: 305px;
      top: 376px;
      left: 0;
      border: 1px solid;
      border-color: #095f7b;
      position: absolute;
      height: 40px;
      border-radius: 5px;
    }

    .validasi-data .overlap-5 {
      width: 305px;
      top: 446px;
      left: 0;
      border: 1px solid;
      border-color: #095f7b;
      position: absolute;
      height: 40px;
      border-radius: 5px;
    }

    .validasi-data .text-wrapper-10 {
      top: 493px;
      position: absolute;
      width: 210px;
      left: 0;
      font-family: "Qualion-DemiBold", Helvetica;
      font-weight: 700;
      color: #095f7b;
      font-size: 12px;
      letter-spacing: 0;
      line-height: normal;
    }

    .validasi-data .text-wrapper-11 {
      position: absolute;
      width: 210px;
      top: 564px;
      left: 0;
      font-family: "Qualion-DemiBold", Helvetica;
      font-weight: 700;
      color: #095f7b;
      font-size: 12px;
      letter-spacing: 0;
      line-height: normal;
    }

    .validasi-data .text-wrapper-12 {
      position: absolute;
      width: 210px;
      top: 635px;
      left: 0;
      font-family: "Qualion-DemiBold", Helvetica;
      font-weight: 700;
      color: #095f7b;
      font-size: 12px;
      letter-spacing: 0;
      line-height: normal;
    }

    .validasi-data .text-wrapper-13 {
      position: absolute;
      width: 210px;
      top: 706px;
      left: 0;
      font-family: "Qualion-DemiBold", Helvetica;
      font-weight: 700;
      color: #095f7b;
      font-size: 12px;
      letter-spacing: 0;
      line-height: normal;
    }

    .validasi-data .text-wrapper-14 {
      top: 776px;
      position: absolute;
      width: 210px;
      left: 0;
      font-family: "Qualion-DemiBold", Helvetica;
      font-weight: 700;
      color: #095f7b;
      font-size: 12px;
      letter-spacing: 0;
      line-height: normal;
    }

    .validasi-data .overlap-6 {
      width: 305px;
      top: 516px;
      left: 0;
      border: 1px solid;
      border-color: #095f7b;
      position: absolute;
      height: 40px;
      border-radius: 5px;
    }

    .validasi-data .text-wrapper-15 {
      position: absolute;
      width: 184px;
      top: 11px;
      left: 18px;
      font-family: "Alatsi-Regular", Helvetica;
      font-weight: 400;
      color: #777777;
      font-size: 10px;
      letter-spacing: 0;
      line-height: normal;
    }

    .validasi-data .overlap-7 {
      width: 305px;
      top: 587px;
      left: 0;
      border: 1px solid;
      border-color: #095f7b;
      position: absolute;
      height: 40px;
      border-radius: 5px;
    }

    .validasi-data .overlap-8 {
      width: 305px;
      top: 658px;
      left: 0;
      border: 1px solid;
      border-color: #095f7b;
      position: absolute;
      height: 40px;
      border-radius: 5px;
    }

    .validasi-data .overlap-9 {
      width: 305px;
      top: 729px;
      left: 0;
      border: 1px solid;
      border-color: #095f7b;
      position: absolute;
      height: 40px;
      border-radius: 5px;
    }

    .validasi-data .overlap-10 {
      width: 305px;
      top: 799px;
      left: 0;
      border: 1px solid;
      border-color: #095f7b;
      position: absolute;
      height: 40px;
      border-radius: 5px;
    }

    .validasi-data .overlap-11 {
      width: 266px;
      top: 911px;
      left: 19px;
      position: absolute;
      height: 40px;
      border-radius: 5px;
      cursor: pointer;
    }

    .validasi-data .rectangle {
      position: absolute;
      width: 266px;
      height: 40px;
      top: 0;
      left: 0;
      background-color: #e16417;
      border-radius: 5px;
      display: flex;
      justify-content: center;
      align-items: center;
    }

    .validasi-data .text-wrapper-16 {
      font-family: "Qualion-DemiBold", Helvetica;
      font-weight: 700;
      color: #ffffff;
      font-size: 13px;
      letter-spacing: 0;
      line-height: normal;
    }

    .validasi-data .group-2 {
      position: absolute;
      width: 264px;
      height: 45px;
      top: 858px;
      left: 21px;
    }

    .validasi-data .OJK {
      position: absolute;
      width: 60px;
      height: 45px;
      top: 0;
      left: 0;
      object-fit: cover;
    }

    .validasi-data .logo-lps {
      position: absolute;
      width: 60px;
      height: 36px;
      top: 7px;
      left: 102px;
      object-fit: cover;
    }

    .validasi-data .logo-bun {
      position: absolute;
      width: 60px;
      height: 21px;
      top: 15px;
      left: 204px;
      object-fit: cover;
    }

    .phone-frame {
      background-color: #dcdcdc;
      padding: 30px 12px;
      border-radius: 40px;
      box-shadow: 0 0 0 10px #888;
      display: flex;
      justify-content: center;
      align-items: center;
      min-height: 100vh;
    }
  </style>
</head>

<body>
  <div class="phone-frame">
    <div class="phone-screen">
      <div class="landing-menu">
        <div class="div">
          <div class="validasi-data">
            <div class="div">
              <img class="logo-nama-removebg" src="img/money_save.png" />
              <div class="text-wrapper">Lengkapi Data Yuk</div>
              <p class="lengkapi-data-yang">
                Lengkapi data yang diperlukan ya, isi data yang <br />kosong
                dan benarkan apabila data salah!
              </p>
              <div class="group">
                <div class="text-wrapper-2">
                  Nomor Induk Kependudukan (NIK)
                  <div class="overlap">
                    <input
                      type="text"
                      value="<?php echo htmlspecialchars($nik); ?>"
                      style="
                          width: 100%;
                          padding: 8px;
                          font-size: 16px;
                          border: 1px solid #ccc;
                          border-radius: 5px;
                          box-sizing: border-box;
                          outline: none;
                          box-shadow: none;
                          font-family: 'Qualion-DemiBold', Helvetica;
                        "
                      readonly />
                  </div>
                </div>
                <div class="text-wrapper-4">Nama Sesuai KTP</div>
                <div class="overlap-group">
                  <input
                    type="text"
                    name="name_ktp"
                    value="<?php echo htmlspecialchars($nama_ktp); ?>"
                    style="
                        width: 100%;
                        padding: 8px;
                        font-size: 16px;
                        border: 1px solid #ccc;
                        border-radius: 5px;
                        box-sizing: border-box;
                        outline: none;
                        box-shadow: none;
                        font-family: 'Qualion-DemiBold', Helvetica;
                      "
                    readonly />
                </div>

                <div class="text-wrapper-5">Tempat, Tanggal Lahir</div>
                <div class="div-wrapper">
                  <input
                    type="date"
                    name="tempat_tanggal_lahir"
                    value="<?php echo htmlspecialchars($tempat_tanggal_lahir); ?>"
                    style="
                        width: 100%;
                        padding: 8px;
                        font-size: 14px;
                        border: 1px solid #ccc;
                        border-radius: 5px;
                        box-sizing: border-box;
                        outline: none;
                        box-shadow: none;
                        font-family: 'Qualion-DemiBold', Helvetica;
                      "
                    readonly />
                </div>

                <div class="text-wrapper-6">Agama</div>
                <div class="overlap-2">
                  <input
                    type="text"
                    name="agama"
                    value="<?php echo htmlspecialchars($agama); ?>"
                    style="
                        width: 100%;
                        padding: 8px;
                        font-size: 16px;
                        border: 1px solid #ccc;
                        border-radius: 5px;
                        box-sizing: border-box;
                        outline: none;
                        box-shadow: none;
                        font-family: 'Qualion-DemiBold', Helvetica;
                      "
                    readonly />
                </div>

                <div class="text-wrapper-7">Alamat Lengkap</div>
                <div class="overlap-3">
                  <input
                    type="text"
                    name="alamat_lengkap"
                    value="<?php echo htmlspecialchars($alamat_lengkap); ?>"
                    style="
                        width: 100%;
                        padding: 8px;
                        font-size: 16px;
                        border: 1px solid #ccc;
                        border-radius: 5px;
                        box-sizing: border-box;
                        outline: none;
                        box-shadow: none;
                        font-family: 'Qualion-DemiBold', Helvetica;
                      "
                    readonly />
                </div>

                <div class="text-wrapper-8">Jenis Kelamin</div>
                <div class="overlap-4">
                  <input
                    name="jenis_kelamin"
                    value="<?php echo htmlspecialchars($jenis_kelamin); ?>"
                    style="
                        width: 100%;
                        padding: 8px;
                        font-size: 15 px;
                        border: 1px solid #ccc;
                        border-radius: 5px;
                        box-sizing: border-box;
                        outline: none;
                        box-shadow: none;
                        font-family: 'Qualion-DemiBold', Helvetica;
                      "
                    readonly>
                  </input>
                </div>
                <div class="text-wrapper-10">Nomor Rekening</div>
                <div class="overlap-6">
                  <input
                    type="text"
                    name="no_rekening"
                    value="<?php echo htmlspecialchars($no_rekening); ?>"
                    style="
                        width: 100%;
                        padding: 8px;
                        font-size: 16px;
                        border: 1px solid #ccc;
                        border-radius: 5px;
                        box-sizing: border-box;
                        outline: none;
                        box-shadow: none;
                        font-family: 'Qualion-DemiBold', Helvetica;
                      "
                    readonly />
                </div>
                <div class="text-wrapper-11">Nama Pemilik Rekening</div>
                <div class="overlap-7">
                  <input
                    type="text"
                    name="nama_pemilik"
                    value="<?php echo htmlspecialchars($nama_pemilik); ?>"
                    style="
                        width: 100%;
                        padding: 8px;
                        font-size: 16px;
                        border: 1px solid #ccc;
                        border-radius: 5px;
                        box-sizing: border-box;
                        outline: none;
                        box-shadow: none;
                        font-family: 'Qualion-DemiBold', Helvetica;
                      " />
                </div>
                <div class="text-wrapper-12">Cabang Pembuatan Rekening</div>
                <div class="overlap-8">
                  <input
                    type="text"
                    name="cabang"
                    value="<?php echo htmlspecialchars($cabang); ?>"
                    style="
                        width: 100%;
                        padding: 8px;
                        font-size: 16px;
                        border: 1px solid #ccc;
                        border-radius: 5px;
                        box-sizing: border-box;
                        outline: none;
                        box-shadow: none;
                        font-family: 'Qualion-DemiBold', Helvetica;
                      "
                    readonly />
                </div>

                <div class="text-wrapper-13">Tanggal Pembuatan Rekening</div>
                <div class="overlap-9">
                  <input
                    type="date"
                    name="tgl_pembuatan"
                    value="<?php echo htmlspecialchars($tgl_pembuatan); ?>"
                    style="
                        width: 100%;
                        padding: 8px;
                        font-size: 14px;
                        border: 1px solid #ccc;
                        border-radius: 5px;
                        box-sizing: border-box;
                        outline: none;
                        box-shadow: none;
                        font-family: 'Qualion-DemiBold', Helvetica;
                      "
                    readonly />
                </div>
                <form action="simpan_contact.php" method="post">
                  <input type="hidden" name="nik" value="<?= htmlspecialchars($nik) ?>" />
                  <div class="text-wrapper-14">Nomor Handphone</div>
                  <div class="overlap-10">
                    <input
                      type="number"
                      name="no_hp"
                      style="
                        width: 100%;
                        padding: 8px;
                        font-size: 16px;
                        border: 1px solid #ccc;
                        border-radius: 5px;
                        box-sizing: border-box;
                        outline: none;
                        box-shadow: none;
                        font-family: 'Qualion-DemiBold', Helvetica;
                      " />
                  </div>
                  <div class="text-wrapper-9">Alamat Email</div>
                  <div class="overlap-5">
                    <input
                      type="email"
                      name="email"
                      style="
                        width: 100%;
                        padding: 8px;
                        font-size: 16px;
                        border: 1px solid #ccc;
                        border-radius: 5px;
                        box-sizing: border-box;
                        outline: none;
                        box-shadow: none;
                        font-family: 'Qualion-DemiBold', Helvetica;
                      " />
                  </div>

                  <button type="submit" class="overlap-11" style="border:none; background:none; padding:0; cursor:pointer;">
                    <div class="rectangle">
                      <div class="text-wrapper-16">Verifikasi Data</div>
                    </div>
                  </button>

                </form>
                <div class="group-2">
                  <img class="OJK" src="img/OJK-1.png" />
                  <img class="logo-lps" src="img/logo-lps-1.png" />
                  <img class="logo-bun" src="img/logo-bun-1.png" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- <script>
    function redirectToSmartLogin() {
      const nik = document.getElementById("nik").value;
      if (nik) {
        window.location.href =
          "smart_login.html?nik=" + encodeURIComponent(nik);
      } else {
        alert("Silakan isi NIK terlebih dahulu!");
      }
    }
  </script> -->
</body>

</html>