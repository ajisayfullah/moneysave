<?php
require_once __DIR__ . '/../MONEY_SAVE/config/koneksi.php';

// Proses upload jika ada POST
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['wajah'])) {
    $nik = $_POST['nik'] ?? '';
    $uploadDir = 'uploads/wajah/';
    if (!file_exists($uploadDir)) mkdir($uploadDir, 0777, true);
    $fileName = 'wajah_' . $nik . '_' . time() . '.png';
    $filePath = $uploadDir . $fileName;

    if (move_uploaded_file($_FILES['wajah']['tmp_name'], $filePath)) {
        // Update kolom wajah di tabel foto
        $stmt = $koneksi->prepare("UPDATE foto SET wajah = ?, status = 'pending' WHERE nik = ?");
        $stmt->bind_param("ss", $filePath, $nik);
        $stmt->execute();
        $stmt->close();
        echo "<script>alert('Foto wajah berhasil diupload!'); window.location.href='verifikasi_wajah.php?nik=$nik';</script>";
        exit;
    } else {
        echo "<script>alert('Upload gagal!');</script>";
    }
}
?>
<!DOCTYPE html>
<html lang="id">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="view/css/bootstrap.min.css" />
    <script src="view/js/bootstrap.min.js"></script>
    <title>Ambil Foto KTP</title>
    <style>
      * {
        -webkit-font-smoothing: antialiased;
        box-sizing: border-box;
      }

      html,
      body {
        margin: 0;
        height: 100%;
      }

      .phone-frame {
        background-color: #dcdcdc;
        padding: 30px 12px;
        /* border-radius: 40px;  <-- hapus atau ganti jadi 0 */
        border-radius: 0;
        box-shadow: 0 0 0 10px #888;
        display: flex;
        justify-content: center;
        align-items: center;
        min-height: 100vh;
      }

      .upload-KTP-wrapper {
        width: 360px;
        height: 800px;
      }

      .upload-KTP {
        position: relative;
        height: 800px;
        background-color: #ffffff;
        /* border-radius: 24px;  <-- hapus atau ganti jadi 0 */
        border-radius: 0;
        overflow: hidden;
      }

      .logo-nama-removebg {
        position: absolute;
        width: 150px;
        height: 100px;
        top: 32px;
        left: 105px;
        object-fit: cover;
      }

      .text-wrapper {
        position: absolute;
        top: 144px;
        left: 47px;
        font-family: "Alatsi-Regular", Helvetica;
        font-weight: 400;
        color: #e16417;
        font-size: 19px;
      }

      .camera-preview {
        position: absolute;
        top: 180px;
        left: 47px;
        width: 266px;
        height: 200px;
        background-color: #000;
        border-radius: 12px;
        overflow: hidden;
      }

      video,
      canvas {
        width: 100%;
        height: 100%;
        object-fit: cover;
        display: none;
      }

      .instructions {
        position: absolute;
        top: 395px;
        left: 47px;
        width: 266px;
        font-size: 10px;
        color: #444;
        font-family: "Alatsi-Regular", Helvetica;
        line-height: 1.5;
      }

      .btn-container {
        position: absolute;
        top: 510px;
        left: 47px;
        width: 266px;
        display: flex;
        justify-content: center;
        gap: 12px;
      }

      .btn-camera,
      .btn-aksi {
        background-color: #e16417;
        border: none;
        color: white;
        padding: 8px 16px;
        font-size: 13px;
        font-weight: bold;
        border-radius: 8px;
        cursor: pointer;
        width: 100px;
      }

      .btn-aksi.cancel {
        background-color: #999;
      }

      .btn-camera:hover,
      .btn-aksi:hover {
        opacity: 0.9;
      }

      .group {
        position: absolute;
        top: 680px;
        left: 48px;
        width: auto; /* biarkan auto agar fleksibel */
        max-width: 90%; /* optional, supaya tidak melebar keluar frame */
        height: 45px;

        display: flex;
        align-items: center;
        gap: 24px; /* jarak antar logo */
      }
      .group img {
        height: 34px;
        width: auto;
        margin-right: 0;
        object-fit: contain;
      }
    </style>
  </head>
  <body>
    <div class="phone-frame">
      <div class="upload-KTP-wrapper">
        <div class="upload-KTP">
          <img class="logo-nama-removebg" src="img/money_save.png" />
          <div class="text-wrapper">Ambil Foto KTP</div>

          <div class="camera-preview">
            <video id="video" autoplay></video>
            <canvas id="canvas"></canvas>
          </div>

          <div class="instructions">
            • Pastikan E-KTP berada dalam frame kamera.<br />
            • Ambil langsung dari kamera, hindari foto lama/fotokopi.<br />
            • Cari tempat terang agar tulisan terlihat jelas.
          </div>

          <div class="btn-container" id="controls">
            <button class="btn-camera" onclick="takePhoto()">Ambil Foto</button>
          </div>

          <div class="group">
            <img src="img/OJK-1.png" />
            <img src="img/logo-lps-1.png" />
            <img src="img/logo-bun-1.png" />
          </div>
        </div>
      </div>
    </div>

    <script>
      const video = document.getElementById("video");
      const canvas = document.getElementById("canvas");
      const ctx = canvas.getContext("2d");
      const controls = document.getElementById("controls");
      let capturedPhoto = null;

      // Get NIK from URL or session
      const urlParams = new URLSearchParams(window.location.search);
      const nik = urlParams.get("nik");

      navigator.mediaDevices
        .getUserMedia({ video: true })
        .then((stream) => {
          video.srcObject = stream;
          video.style.display = "block";
        })
        .catch((err) => {
          console.error("Gagal mengakses kamera:", err);
          alert("Gagal mengakses kamera. Pastikan Anda memberikan izin.");
        });

      function takePhoto() {
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        video.style.display = "none";
        canvas.style.display = "block";

        // Stop camera stream
        const stream = video.srcObject;
        const tracks = stream.getTracks();
        tracks.forEach((track) => track.stop());

        controls.innerHTML = `
          <button class="btn-aksi cancel" onclick="cancelPhoto()">ulang</button>
          <button class="btn-aksi" onclick="savePhoto()">benar</button>
        `;
      }

      function cancelPhoto() {
        canvas.style.display = "none";
        video.style.display = "block";
        controls.innerHTML = `
          <button class="btn-camera" onclick="takePhoto()">Ambil Foto</button>
        `;

        // Restart camera
        navigator.mediaDevices.getUserMedia({ video: true }).then((stream) => {
          video.srcObject = stream;
        });
      }

      async function savePhoto() {
        // Convert canvas to Blob
        canvas.toBlob(
          async (blob) => {
            const formData = new FormData();
            formData.append("nik", nik);
            formData.append("kartu", blob, "ktp_photo.png");

            try {
              // Show loading state
              const benarBtn = document.querySelector(".btn-aksi:not(.cancel)");
              benarBtn.disabled = true;
              benarBtn.textContent = "Mengunggah...";

              // Send to server
              const response = await fetch("save_ktp_photo.php", {
                method: "POST",
                body: formData,
              });

              const result = await response.json();

              if (result.success) {
                // Redirect to face verification page
                window.location.href = `verifikasi_wajah.php?nik=${nik}`;
              } else {
                alert("Gagal menyimpan foto: " + result.message);
                cancelPhoto();
              }
            } catch (error) {
              console.error("Error:", error);
              alert("Terjadi kesalahan saat mengunggah foto");
              cancelPhoto();
            }
          },
          "image/png",
          0.9
        );
      }
    </script>
  </body>
</html>
