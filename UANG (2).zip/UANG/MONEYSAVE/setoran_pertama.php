<?php
// Koneksi ke database
$host = 'localhost';
$user = 'root';
$password = '';
$dbname = 'moneysave';

$conn = new mysqli($host, $user, $password, $dbname);

if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Ambil NIK dari URL
$nik = $_GET['nik'] ?? null;

if (!$nik) {
    die("Parameter NIK tidak ditemukan");
}

// Cek status konfirmasi
$query = "SELECT status_konfirmasi FROM daftar WHERE nik = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("s", $nik);
$stmt->execute();
$result = $stmt->get_result();
$userData = $result->fetch_assoc();
$stmt->close();

// Jika sudah dikonfirmasi, redirect ke halaman selesai
if ($userData && $userData['status_konfirmasi'] === 'approved') {
    header("Location: setoran_selesai.php?nik=" . urlencode($nik));
    exit();
}

$conn->close();
?>

<!DOCTYPE html>
<html>
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta charset="utf-8" />
    <link rel="stylesheet" href="view/css/bootstrap.min.css" />
    <script src="view/js/bootstrap.min.js"></script>
  </head>
  <body>
    <style>
      @import url("https://cdnjs.cloudflare.com/ajax/libs/meyer-reset/2.0/reset.min.css");
      * {
        -webkit-font-smoothing: antialiased;
        box-sizing: border-box;
      }
      html,
      body {
        margin: 0px;
        height: 100%;
      }
      /* a blue color as a generic focus style */
      button:focus-visible {
        outline: 2px solid #4a90e2 !important;
        outline: -webkit-focus-ring-color auto 5px !important;
      }
      a {
        text-decoration: none;
      }

      .setoran-pertama {
        background-color: #ffffff;
        display: flex;
        flex-direction: row;
        justify-content: center;
        width: 100%;
      }

      .setoran-pertama .div {
        background-color: #ffffff;
        width: 360px;
        height: 800px;
        position: relative;
      }

      .setoran-pertama .women-holding-phone {
        position: absolute;
        width: 210px;
        height: 210px;
        top: 210px;
        left: 75px;
        object-fit: cover;
      }

      .setoran-pertama .text-wrapper {
        position: absolute;
        top: 549px;
        left: 47px;
        font-family: "ABeeZee-Italic", Helvetica;
        font-weight: 400;
        font-style: italic;
        color: #e16417;
        font-size: 20px;
        letter-spacing: 0;
        line-height: normal;
        white-space: nowrap;
      }

      .setoran-pertama .silahkan-lakukan {
        position: absolute;
        top: 581px;
        left: 47px;
        font-family: "Alatsi-Regular", Helvetica;
        font-weight: 400;
        color: #095f7b;
        font-size: 11px;
        letter-spacing: 0;
        line-height: normal;
      }

      .setoran-pertama .logo-nama-removebg {
        position: absolute;
        width: 150px;
        height: 100px;
        top: 32px;
        left: 105px;
        object-fit: cover;
      }

      .setoran-pertama .overlap-group {
        position: absolute;
        width: 268px;
        height: 52px;
        top: 623px;
        left: 46px;
        background-color: #ffffff;
        border-radius: 5px;
        border: 1px solid;
        border-color: #e16417;
      }

      .setoran-pertama .img {
        position: absolute;
        width: 50px;
        height: 50px;
        top: 1px;
        left: 13px;
        object-fit: cover;
      }

      .setoran-pertama .text-wrapper-2 {
        position: absolute;
        top: 12px;
        left: 67px;
        font-family: "ABeeZee-Regular", Helvetica;
        font-weight: 400;
        color: #e16417;
        font-size: 8px;
        letter-spacing: 0;
        line-height: normal;
        white-space: nowrap;
      }

      .setoran-pertama .text-wrapper-3 {
        top: 24px;
        left: 67px;
        font-family: "Alatsi-Regular", Helvetica;
        font-weight: 400;
        color: #095f7b;
        font-size: 7px;
        position: absolute;
        letter-spacing: 0;
        line-height: normal;
      }

      .setoran-pertama .text-wrapper-4 {
        top: 16px;
        left: 187px;
        font-family: "Qualion-DemiBold", Helvetica;
        font-weight: 700;
        color: #000000;
        font-size: 12px;
        position: absolute;
        letter-spacing: 0;
        line-height: normal;
      }

      .setoran-pertama .fi-rr-thumbs-up {
        position: absolute;
        width: 20px;
        height: 20px;
        top: 739px;
        left: 47px;
        object-fit: cover;
      }

      .setoran-pertama .p {
        position: absolute;
        width: 242px;
        top: 739px;
        left: 71px;
        font-family: "Alatsi-Regular", Helvetica;
        font-weight: 400;
        color: #095f7b;
        font-size: 6.5px;
        letter-spacing: 0;
        line-height: normal;
      }

      .setoran-pertama .text-wrapper-5 {
        position: absolute;
        top: 69px;
        left: 28px;
        font-family: "Alatsi-Regular", Helvetica;
        font-weight: 400;
        color: #e16417;
        font-size: 15px;
        letter-spacing: 0;
        line-height: normal;
        text-decoration: underline;
      }
      .phone-frame {
        background-color: #dcdcdc;
        padding: 30px 12px;
        border-radius: 40px;
        box-shadow: 0 0 0 10px #888;
        display: flex;
        justify-content: center;
        align-items: center;
        min-height: 100vh;
      }
    </style>
    <div class="phone-frame">
      <div class="phone-screen">
        <div class="landing-menu">
          <div class="div">
            <div class="setoran-pertama">
              <div class="div">
                <img
                  class="women-holding-phone"
                  src="img/setoran_pertama.png"
                />
                <div class="text-wrapper">Setoran Awal Dulu Ya!</div>
                <p class="silahkan-lakukan">
                  Silahkan lakukan setoran awal sebesar Rp100.000<br />ke
                  virtual account dibawah ya!
                </p>
                <img class="logo-nama-removebg" src="img/money_save.png" />
                <div class="overlap-group">
                  <img class="img" src="img/money_save.png" />
                  <div class="text-wrapper-2">Money Save Virtual Account</div>
                  <div class="text-wrapper-3">1232-3826-2932-2029</div>
                  <div class="text-wrapper-4">23:59:50</div>
                </div>
                <img class="fi-rr-thumbs-up" src="img/fi-rr-thumbs-up-1.png" />
                <p class="p">
                  Jika dalam 24 Jam setoran awal belum dilakukan, maka kamu
                  harus mengulang proses pendaftaran dari awal ya! pastikan
                  bayar tepat waktu😤
                </p>
                <!-- <div class="text-wrapper-5">Kembali</div> -->
              </div>
            </div>
            <script>
              // Ambil nik dari URL
              function getQueryParam(param) {
                const urlParams = new URLSearchParams(window.location.search);
                return urlParams.get(param);
              }

              const nik = getQueryParam("nik");
              if (!nik) {
                alert(
                  "NIK tidak ditemukan! Halaman tidak bisa menampilkan timer."
                );
              } else {
                fetch(`get_timer.php?nik=${nik}`)
                  .then((response) => {
                    if (!response.ok)
                      throw new Error("Data timer tidak ditemukan");
                    return response.json();
                  })
                  .then((data) => {
                    const timerEnd = new Date(data.timer_end).getTime();

                    function updateCountdown() {
                      const now = new Date().getTime();
                      const distance = timerEnd - now;

                      if (distance <= 0) {
                        document.querySelector(".text-wrapper-4").innerHTML =
                          "00:00:00";
                        return;
                      }

                      const hours = Math.floor(
                        (distance / (1000 * 60 * 60)) % 24
                      );
                      const minutes = Math.floor((distance / (1000 * 60)) % 60);
                      const seconds = Math.floor((distance / 1000) % 60);

                      const formattedTime =
                        String(hours).padStart(2, "0") +
                        ":" +
                        String(minutes).padStart(2, "0") +
                        ":" +
                        String(seconds).padStart(2, "0");

                      document.querySelector(".text-wrapper-4").innerHTML =
                        formattedTime;
                    }

                    setInterval(updateCountdown, 1000);
                    updateCountdown();
                  })
                  .catch((err) => {
                    alert("Gagal mendapatkan data timer: " + err.message);
                  });
              }
            </script>
          </div>
        </div>
      </div>
    </div>
  </body>
</html>
