<?php
header('Content-Type: application/json');

// Konfigurasi database
$host = 'localhost';
$user = 'root';
$password = '';
$dbname = 'moneysave';

// Koneksi
$conn = new mysqli($host, $user, $password, $dbname);
if ($conn->connect_error) {
    echo json_encode(['success' => false, 'message' => 'Koneksi database gagal']);
    exit;
}

// Ambil NIK
$nik = $_POST['nik'] ?? null;
if (!$nik) {
    echo json_encode(['success' => false, 'message' => 'NIK tidak ditemukan']);
    exit;
}

// Pastikan file ada
if (!isset($_FILES['wajah'])) {
    echo json_encode(['success' => false, 'message' => 'File wajah tidak dikirim']);
    exit;
}

// Lokasi folder upload
$uploadDir = 'uploads/wajah/';
if (!file_exists($uploadDir)) {
    mkdir($uploadDir, 0777, true);
}

// Buat nama file
$fileName = 'wajah_' . $nik . '_' . time() . '.png';
$filePath = $uploadDir . $fileName;

// Pindahkan file
if (move_uploaded_file($_FILES['wajah']['tmp_name'], $filePath)) {
    // Simpan ke database
    $stmt = $conn->prepare("UPDATE foto SET wajah = ?, status = 'pending' WHERE nik = ?");
    if (!$stmt) {
        unlink($filePath);
        echo json_encode(['success' => false, 'message' => 'Prepare statement gagal']);
        exit;
    }

    $stmt->bind_param("ss", $filePath, $nik);
    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'message' => 'Foto wajah berhasil disimpan']);
    } else {
        unlink($filePath);
        echo json_encode(['success' => false, 'message' => 'Gagal menyimpan ke database']);
    }
    $stmt->close();
} else {
    echo json_encode(['success' => false, 'message' => 'Gagal mengunggah file wajah']);
}

$conn->close();
